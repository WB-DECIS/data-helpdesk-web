$(".mega-menu-dropdown input[type=text],.mega-menu-dropdown input[type=search]").focusin(function() {
    $('head').append('<style class="dynamic-style">.showIt {display: block!important;opacity:1!important;visibility: visible!important;}</style>');
    $(this).closest(".mega-menu-dropdown").addClass("showIt");
}).focusout(function() {
    $(this).closest(".mega-menu-dropdown").removeClass("showIt");
    $(".dynamic-style").remove();
});
jQuery(document).ready(function() {
    $(".mega-menu").hover(function() {
        $(".dropdown-toggle", this).addClass("activeMegaMenu"), $(".mega-menu-dropdown", this).stop().show()
    }, function() {
        if ($("#mega-menu-global-search .mega-menu-dropdown").find(".search-input-field-1").is(":focus")) {
            return 0
        }
        $(".dropdown-toggle", this).removeClass("activeMegaMenu"), $(".mega-menu-dropdown", this).stop().hide()
    });
    $(".dropdown-menu.mega-menu-dropdown").prepend('<span class="close-this-megamenu">X</span>');
    $(document).on("click", ".close-this-megamenu", function(c) {
        $(this).closest(".mega-menu-dropdown").hide()
    })
});
jQuery(document).ready(function() {
    if ($(window).width() >= 991) {}
    $(".tt-menu").find("li.tt-suggestion").removeAttr("style");
    $(".dropdown-toggle.arrow-down.search-submit-icon").click(function(b) {
        if (!$("#search11").val().length > 0) {
            $(".tt-menu").find("li.tt-suggestion").removeAttr("style")
        }
        $(".tt-menu").toggleClass("show-tt-menu")
    });
    $("#search11").keyup(function() {
        var b = $(this).val().length;
        if (b > 0) {
            if (!$(".tt-menu").hasClass("show-tt-menu")) {
                $(".tt-menu").addClass("show-tt-menu")
            }
        } else {
            $(".tt-menu").removeClass("show-tt-menu")
        }
        return true
    });
    $("#search11").on("keydown keyup keypress", function(c) {
        var b = c.keyCode || c.which;
        if (c.keyCode == 13) {
            c.preventDefault();
            return false
        }
    })
});
$(".mega-menu > a").on("click touchend", function() {
    var b = $(this);
    var c = b.attr("href");
    window.location = c
});

function submit_search_form() { 

    var global_qvalue = document.getElementById('qterm_id').value;

    if(global_qvalue==""){

        global_qvalue = document.getElementById('qterm_idmob').value;

    }

    if(global_qvalue==""){
        return false;
    }
    document.getElementById("hiddensearchId").action = "http://www.worldbank.org/en/search" + "?q=" + global_qvalue;
    document.getElementById("hiddensearch_id_txt").value = global_qvalue;
    document.getElementById("hiddensearchId").submit();
    return false;
}

function submit_search_form_upoverty() {


    event.preventDefault();
    var global_qvalue1 = document.getElementById('qterm_id1').value;

    if(global_qvalue1==""){
        return false;
    }
    document.getElementById("hiddensearchId1").action = "http://documents.worldbank.org/curated/en/docsearch" + "?query=" + global_qvalue1;
    document.getElementById("hiddensearch_id_txt1").value = global_qvalue1;
    document.getElementById("hiddensearchId1").submit();
}

function clearField(field) {
    if (field.value == field.defaultValue)
        field.value = '';
}

//cookie function starts
function WriteCookie() {}

function wb_survey_yes(url) {
    wb_note_setcookie('wb_note','1',1);
    $('#survey').hide();
    window.open(url,'_blank');
}

function wb_note_setcookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
} 

//cookie 



$(window).load(function() {


    $("#csearch").submit(function(event) {
        event.preventDefault();
        window.location = $(this).data('csearch');
    });

    //to highlight mega menu items
    var pathname = window.location.pathname;

    //to handle recent search
    var cookieVal = "";
    try {
        cookieVal = $.cookie("recentsearch");
    } catch (e) {
        console.log(e.message);
    }

    var ulEle = $('.no-mega-menu-sublist');
    $('.no-mega-menu-sublist').empty();
    if (typeof cookieVal != 'undefined') {
        var valueArray = cookieVal.split("|");
        var length = valueArray.length;
        if (length > 4) {
            valueArray.pop();

        }
        for (var i = 0; i < valueArray.length; i++) {
            var dataArr = valueArray[i].split("=");
            var newEle = $('<li><a href=\"' + dataArr[1] + '\">' + ((i == (valueArray.length - 1)) ? dataArr[0].replace(",", "...") : dataArr[0]) + '</a></li>');
            ulEle.append(newEle);

        }
    }

    $('.country-search').on('click', function(e) {
        var href = $(this).attr('href');
        var text = $(this).text() + ",";
        var data = text + "=" + href;
        var finalData = data;
        var cookieVal = $.cookie("recentsearch");
        if (typeof cookieVal != 'undefined') {
            var valueArray = cookieVal.split("|");
            var length = valueArray.length;
            if (length > 3) {
                length = 3;
            }
            for (var i = 0; i < length; i++) {
                var checkData = valueArray[i].replace("...", ",");
                if (finalData != checkData) {
                    if (i == (length - 1)) {
                        valueArray[i] = valueArray[i].replace(",", "...");
                    }
                    data = data + "|" + valueArray[i];
                }
            }
        }
        if (data.split("|")[data.split("|").length - 1].split("=")[0].endsWith(",")) {
            data = data.replace(/,([^,]*)$/, '...' + '$1');

        }
        valueArray = data.split("|");
        var length = valueArray.length;
        if (length > 4) {
            valueArray.pop();

        }
        $('.no-mega-menu-sublist').empty();
        for (var i = 0; i < valueArray.length; i++) {
            var dataArr = valueArray[i].split("=");
            var newEle = $('<li><a href=\"' + dataArr[1] + '\">' + ((i == (valueArray.length - 1)) ? dataArr[0].replace(",", "...") : dataArr[0]) + '</a></li>');
            ulEle.append(newEle);
        }
        $.cookie("recentsearch", data, {
            expires: 10,
            path: '/'
        });
    });
    //script to hanlde recent search ends


    $(".search-sub-link").each(function(i) {

        
        var liElement=$(this).next();
        var liTagElement=liElement.get(0);
        
        
        if (typeof liTagElement == 'undefined' ) {
            
            
            if($(this).children().get(0).tagName == 'UL' || $(this).children().get(0).tagName == 'ul'){
                
                $(this).children().css("border-bottom","0px solid #e5e5e5");
                
            }
        }
    });
});


$(document).ready(function(){
    $('.no-mega-menu-sublist').empty();
    //search function
    $("#search11").keyup(function(){
        var value = $(this).val();
        $(".dropdown-menu>li span .firstLevel").each(function(){
            var length = value.length;
            var substring = $(this).text().toLowerCase().substring(0,length);
            //if($(this).text().toLowerCase().search(value.toLowerCase()) > -1)
            if(length!=0 && value.toLowerCase()===substring)
            {
                $(this).parent().parent().show();
            }else
            {
                $(this).parent().parent().hide();   
            }
        });
    });
});



    $(document).ready(function() {

        $(".indicator_data_topics ").each(function(i){                  
            var eachTable = $(this);               
            console.log(i);
            if(i!=0){

               eachTable.css({'visibility': 'hidden'});    
                 eachTable.css({'height': '0px'});    

            }
            
        });
/*
        $("tab").each(function(idx, tab) { 
            
            $(document).on("click", $(tab).find("tab-nav ul li"), function(e) {
                var target = e.target;
                var thisVar = ($(tab).find("tab-content ul._loop_tab_content_list>li").eq($(target).parent().index()).find($('.indicator_data_topics'))); 
                
                thisVar.css("visibility", "visible");
                thisVar.css("height", "auto");
                thisVar.css("opacity", "1");
                thisVar.addClass("activediv");
                
                
                
                
            });

        });

        $('#indicator_rank,#indicator_dtf').DataTable({  

            "dom": '<"wrapper"flipt>',
            scrollY:        "600px",
            scrollX:        true,
            scrollCollapse: true,
            paging:         false,  
            fixedColumns:   {
                leftColumns: 1
            }, 
            columnDefs: [
                {targets: "_all", width: 127}           
            ],
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search records"
            }
        });
         */
    });
