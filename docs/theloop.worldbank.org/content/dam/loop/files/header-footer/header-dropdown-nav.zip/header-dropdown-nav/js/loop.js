// @codekit-prepend "util.js"
// @codekit-prepend "dropdown.js"
 $(document).ready(function() { 

     $('.lp__dropdown_menu li a').click(function(){
         var countryName = $(this).text();
         $(this).parent().parent().parent().find(".lp__filter_option").html(countryName);
         var option = $(this).a('href');
         if(option !== "") {
             if(option.indexOf('worldbank.org')>-1 || option.indexOf('bancomundial.org')>-1 || 
                 option.indexOf('albankaldawli.org')>-1 || option.indexOf('banquemondiale.org')>-1 || 
                 option.indexOf('shihang.org')>-1) {
                 window.location = option;
             } else {
                 var newWindow = window.open(option,"_blank");
                 newWindow.location = option;
             }
         } z

     });

 });