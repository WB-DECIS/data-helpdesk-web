$(".mega-menu-dropdown input[type=text],.mega-menu-dropdown input[type=search]").focusin(function() {
    $('head').append('<style class="dynamic-style">.showIt {display: block!important;}</style>');
    $(this).closest(".mega-menu-dropdown").addClass("showIt")
}).focusout(function() {
    $(this).closest(".mega-menu-dropdown").removeClass("showIt");
    $(".dynamic-style").remove();
});
jQuery(document).ready(function() {
    if ($(window).width() >= 991) {

    }
    $(".dropdown-menu.mega-menu-dropdown").prepend('<span class="close-this-megamenu">X</span>');
    $(".close-this-megamenu").click(function(e) {
        $(this).closest(".mega-menu-dropdown").hide();
    });

    $(".tt-menu").find("li.tt-suggestion").removeAttr("style");
    $(".dropdown-toggle.arrow-down.search-submit-icon").click(function(e) {
        if(!$("#search11").val().length>0)
			//$(".tt-menu li.tt-suggestion").show();
            $(".tt-menu").find("li.tt-suggestion").removeAttr("style");

        	$(".tt-menu").toggleClass("show-tt-menu");
    });

    $("#search11").keyup(function() {
        var len = $(this).val().length
        if (len > 0) {
            if (!$(".tt-menu").hasClass("show-tt-menu"))
                $(".tt-menu").addClass("show-tt-menu");
        } else
            $(".tt-menu").removeClass("show-tt-menu");
        return true;
    });
});

//End  Megamenu Jquery 


$('.mega-menu > a').on('click touchend', function() {
    var linkToAffect = $(this);
    var linkToAffectHref = linkToAffect.attr('href');
    window.location = linkToAffectHref;
});

