(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
// -----------Begin Accordion JS ------------- //

var select = require('../utils/select');

function showPanelListener (el, ev) {
  var expanded = el.getAttribute('aria-expanded') === 'true';
  this.hideAll();
  if (!expanded) {
    this.show(el);
  }
  return false;
}

function Accordion (el) {
  var self = this;
  this.root = el;

  // delegate click events on each <button>
  var buttons = select('button', this.root);
  buttons.forEach(function (el) {
    if (el.attachEvent) {
      el.attachEvent('onclick', showPanelListener.bind(self, el));
    } else {
      el.addEventListener('click', showPanelListener.bind(self, el));
    }
  });

  // find the first expanded button
  var expanded = this.$('button[aria-expanded=true]')[ 0 ];
  this.hideAll();
  if (expanded !== undefined) {
    this.show(expanded);
  }
}

Accordion.prototype.$ = function (selector) {
  return select(selector, this.root);
};


Accordion.prototype.hide = function (button) {
  var selector = button.getAttribute('aria-controls'),
    content = this.$('#' + selector)[ 0 ];

  button.setAttribute('aria-expanded', false);
  content.setAttribute('aria-hidden', true);
  return this;
};

/**
 * @param {HTMLElement} button
 * @return {Accordion}
 */
Accordion.prototype.show = function (button) {
  var selector = button.getAttribute('aria-controls'),
    content = this.$('#' + selector)[ 0 ];

  button.setAttribute('aria-expanded', true);
  content.setAttribute('aria-hidden', false);
  return this;
};

Accordion.prototype.hideAll = function () {
  var self = this;
  var buttons = this.$('ul > li > button, .usa-accordion-button');
  buttons.forEach(function (button) {
    self.hide(button);
  });
  return this;
};

module.exports = Accordion;
// -----------End Accordion JS ------------- //
},{"../utils/select":23}],2:[function(require,module,exports){

/**
*
*  Base64 encode / decode
*  http://www.webtoolkit.info/
*
**/

var Base64 = {

	// private property
	_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",

	// public method for encoding
	encode : function (input) {
		var output = "";
		var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
		var i = 0;

		input = Base64._utf8_encode(input);

		while (i < input.length) {

			chr1 = input.charCodeAt(i++);
			chr2 = input.charCodeAt(i++);
			chr3 = input.charCodeAt(i++);

			enc1 = chr1 >> 2;
			enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
			enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
			enc4 = chr3 & 63;

			if (isNaN(chr2)) {
				enc3 = enc4 = 64;
			} else if (isNaN(chr3)) {
				enc4 = 64;
			}

			output = output +
			this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
			this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

		}

		return output;
	},

	// public method for decoding
	decode : function (input) {
		var output = "";
		var chr1, chr2, chr3;
		var enc1, enc2, enc3, enc4;
		var i = 0;

		input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

		while (i < input.length) {

			enc1 = this._keyStr.indexOf(input.charAt(i++));
			enc2 = this._keyStr.indexOf(input.charAt(i++));
			enc3 = this._keyStr.indexOf(input.charAt(i++));
			enc4 = this._keyStr.indexOf(input.charAt(i++));

			chr1 = (enc1 << 2) | (enc2 >> 4);
			chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
			chr3 = ((enc3 & 3) << 6) | enc4;

			output = output + String.fromCharCode(chr1);

			if (enc3 != 64) {
				output = output + String.fromCharCode(chr2);
			}
			if (enc4 != 64) {
				output = output + String.fromCharCode(chr3);
			}

		}

		output = Base64._utf8_decode(output);

		return output;

	},

	// private method for UTF-8 encoding
	_utf8_encode : function (string) {
		string = string.replace(/\r\n/g,"\n");
		var utftext = "";

		for (var n = 0; n < string.length; n++) {

			var c = string.charCodeAt(n);

			if (c < 128) {
				utftext += String.fromCharCode(c);
			}
			else if((c > 127) && (c < 2048)) {
				utftext += String.fromCharCode((c >> 6) | 192);
				utftext += String.fromCharCode((c & 63) | 128);
			}
			else {
				utftext += String.fromCharCode((c >> 12) | 224);
				utftext += String.fromCharCode(((c >> 6) & 63) | 128);
				utftext += String.fromCharCode((c & 63) | 128);
			}

		}

		return utftext;
	},

	// private method for UTF-8 decoding
	_utf8_decode : function (utftext) {
		var string = "";
		var i = 0;
		var c = c1 = c2 = 0;

		while ( i < utftext.length ) {

			c = utftext.charCodeAt(i);

			if (c < 128) {
				string += String.fromCharCode(c);
				i++;
			}
			else if((c > 191) && (c < 224)) {
				c2 = utftext.charCodeAt(i+1);
				string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
				i += 2;
			}
			else {
				c2 = utftext.charCodeAt(i+1);
				c3 = utftext.charCodeAt(i+2);
				string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
				i += 3;
			}

		}

		return string;
	}

}

},{}],3:[function(require,module,exports){
// -----------Begin Button JS ------------- //
+function ($) {
  'use strict';

  // BUTTON PUBLIC CLASS DEFINITION
  // ==============================

  var Button = function (element, options) {
    this.$element  = $(element)
    this.options   = $.extend({}, Button.DEFAULTS, options)
    this.isLoading = false
  }

  Button.VERSION  = '1.0.0'

  Button.DEFAULTS = {
    loadingText: 'loading...'
  }

  Button.prototype.setState = function (state) {
    var d    = 'disabled'
    var $el  = this.$element
    var val  = $el.is('input') ? 'val' : 'html'
    var data = $el.data()

    state += 'Text'

    if (data.resetText == null) $el.data('resetText', $el[val]())

    // push to event loop to allow forms to submit
    setTimeout($.proxy(function () {
      $el[val](data[state] == null ? this.options[state] : data[state])

      if (state == 'loadingText') {
        this.isLoading = true
        $el.addClass(d).attr(d, d).prop(d, true)
      } else if (this.isLoading) {
        this.isLoading = false
        $el.removeClass(d).removeAttr(d).prop(d, false)
      }
    }, this), 0)
  }

  Button.prototype.toggle = function () {
    var changed = true
    var $parent = this.$element.closest('[data-toggle="buttons"]')

    if ($parent.length) {
      var $input = this.$element.find('input')
      if ($input.prop('type') == 'radio') {
        if ($input.prop('checked')) changed = false
        $parent.find('.active').removeClass('active')
        this.$element.addClass('active')
      } else if ($input.prop('type') == 'checkbox') {
        if (($input.prop('checked')) !== this.$element.hasClass('active')) changed = false
        this.$element.toggleClass('active')
      }
      $input.prop('checked', this.$element.hasClass('active'))
      if (changed) $input.trigger('change')
    } else {
      this.$element.attr('aria-pressed', !this.$element.hasClass('active'))
      this.$element.toggleClass('active')
    }
  }


  // BUTTON PLUGIN DEFINITION
  // ========================

  function Plugin(option) {
    return this.each(function () {
      var $this   = $(this)
      var data    = $this.data('bs.button')
      var options = typeof option == 'object' && option

      if (!data) $this.data('bs.button', (data = new Button(this, options)))

      if (option == 'toggle') data.toggle()
      else if (option) data.setState(option)
    })
  }

  var old = $.fn.button

  $.fn.button             = Plugin
  $.fn.button.Constructor = Button


  // BUTTON NO CONFLICT
  // ==================

  $.fn.button.noConflict = function () {
    $.fn.button = old
    return this
  }


  // BUTTON DATA-API
  // ===============

  $(document)
    .on('click.bs.button.data-api', '[data-toggle^="button"]', function (e) {
      var $btn = $(e.target).closest('.btn')
      Plugin.call($btn, 'toggle')
      if (!($(e.target).is('input[type="radio"], input[type="checkbox"]'))) {
        // Prevent double click on radios, and the double selections (so cancellation) on checkboxes
        e.preventDefault()
        // The target component still receive the focus
        if ($btn.is('input,button')) $btn.trigger('focus')
        else $btn.find('input:visible,button:visible').first().trigger('focus')
      }
    })
    .on('focus.bs.button.data-api blur.bs.button.data-api', '[data-toggle^="button"]', function (e) {
      $(e.target).closest('.btn').toggleClass('focus', /^focus(in)?$/.test(e.type))
    })

}(jQuery);

},{}],4:[function(require,module,exports){
// -----------Begin Card JS ------------- //
var screenWidth = 768;
// Equal hight for card
if ($(window).width() > screenWidth) {
    function equalHeight(group) {
        tallest = 0;
        var mySelecter = group.selector;
        $(mySelecter).closest(".lp__card-section").each(function(index, thisGroup) {
            var selectedContainer = $(thisGroup).find(mySelecter);
            selectedContainer.each(function() {
                thisHeight = $(this).height();
                if (thisHeight > tallest) {
                    tallest = thisHeight;
                }
            });
            selectedContainer.height(tallest);
        });
    }
    $(window).load(function() {
        equalHeight($(".loop_card_photo_title_text .lp__card_wrapper")); 
        equalHeight($(".loop_card_photo_title_text_links .lp__card_wrapper"));   
        equalHeight($(".loop_card_hammer_title .lp__card_wrapper"));    
    });
}
// -----------End Card JS ------------- //
},{}],5:[function(require,module,exports){
/* ========================================================================
 * Bootstrap: collapse.js v3.3.7
 * http://getbootstrap.com/javascript/#collapse
 * ========================================================================
 * Copyright 2011-2016 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */

/* jshint latedef: false */

+function ($) {
  'use strict';

  // COLLAPSE PUBLIC CLASS DEFINITION
  // ================================

  var Collapse = function (element, options) {
    this.$element      = $(element)
    this.options       = $.extend({}, Collapse.DEFAULTS, options)
    this.$trigger      = $('[data-toggle="collapse"][href="#' + element.id + '"],' +
                           '[data-toggle="collapse"][data-target="#' + element.id + '"]')
    this.transitioning = null

    if (this.options.parent) {
      this.$parent = this.getParent()
    } else {
      this.addAriaAndCollapsedClass(this.$element, this.$trigger)
    }

    if (this.options.toggle) this.toggle()
  }

  Collapse.VERSION  = '3.3.7'

  Collapse.TRANSITION_DURATION = 350

  Collapse.DEFAULTS = {
    toggle: true
  }

  Collapse.prototype.dimension = function () {
    var hasWidth = this.$element.hasClass('width')
    return hasWidth ? 'width' : 'height'
  }

  Collapse.prototype.show = function () {
    if (this.transitioning || this.$element.hasClass('in')) return

    var activesData
    var actives = this.$parent && this.$parent.children('.panel').children('.in, .collapsing')

    if (actives && actives.length) {
      activesData = actives.data('bs.collapse')
      if (activesData && activesData.transitioning) return
    }

    var startEvent = $.Event('show.bs.collapse')
    this.$element.trigger(startEvent)
    if (startEvent.isDefaultPrevented()) return

    if (actives && actives.length) {
      Plugin.call(actives, 'hide')
      activesData || actives.data('bs.collapse', null)
    }

    var dimension = this.dimension()

    this.$element
      .removeClass('collapse')
      .addClass('collapsing')[dimension](0)
      .attr('aria-expanded', true)

    this.$trigger
      .removeClass('collapsed')
      .attr('aria-expanded', true)

    this.transitioning = 1

    var complete = function () {
      this.$element
        .removeClass('collapsing')
        .addClass('collapse in')[dimension]('')
      this.transitioning = 0
      this.$element
        .trigger('shown.bs.collapse')
    }

    if (!$.support.transition) return complete.call(this)

    var scrollSize = $.camelCase(['scroll', dimension].join('-'))

    this.$element
      .one('bsTransitionEnd', $.proxy(complete, this))
      .emulateTransitionEnd(Collapse.TRANSITION_DURATION)[dimension](this.$element[0][scrollSize])
  }

  Collapse.prototype.hide = function () {
    if (this.transitioning || !this.$element.hasClass('in')) return

    var startEvent = $.Event('hide.bs.collapse')
    this.$element.trigger(startEvent)
    if (startEvent.isDefaultPrevented()) return

    var dimension = this.dimension()

    this.$element[dimension](this.$element[dimension]())[0].offsetHeight

    this.$element
      .addClass('collapsing')
      .removeClass('collapse in')
      .attr('aria-expanded', false)

    this.$trigger
      .addClass('collapsed')
      .attr('aria-expanded', false)

    this.transitioning = 1

    var complete = function () {
      this.transitioning = 0
      this.$element
        .removeClass('collapsing')
        .addClass('collapse')
        .trigger('hidden.bs.collapse')
    }

    if (!$.support.transition) return complete.call(this)

    this.$element
      [dimension](0)
      .one('bsTransitionEnd', $.proxy(complete, this))
      .emulateTransitionEnd(Collapse.TRANSITION_DURATION)
  }

  Collapse.prototype.toggle = function () {
    this[this.$element.hasClass('in') ? 'hide' : 'show']()
  }

  Collapse.prototype.getParent = function () {
    return $(this.options.parent)
      .find('[data-toggle="collapse"][data-parent="' + this.options.parent + '"]')
      .each($.proxy(function (i, element) {
        var $element = $(element)
        this.addAriaAndCollapsedClass(getTargetFromTrigger($element), $element)
      }, this))
      .end()
  }

  Collapse.prototype.addAriaAndCollapsedClass = function ($element, $trigger) {
    var isOpen = $element.hasClass('in')

    $element.attr('aria-expanded', isOpen)
    $trigger
      .toggleClass('collapsed', !isOpen)
      .attr('aria-expanded', isOpen)
  }

  function getTargetFromTrigger($trigger) {
    var href
    var target = $trigger.attr('data-target')
      || (href = $trigger.attr('href')) && href.replace(/.*(?=#[^\s]+$)/, '') // strip for ie7

    return $(target)
  }


  // COLLAPSE PLUGIN DEFINITION
  // ==========================

  function Plugin(option) {
    return this.each(function () {
      var $this   = $(this)
      var data    = $this.data('bs.collapse')
      var options = $.extend({}, Collapse.DEFAULTS, $this.data(), typeof option == 'object' && option)

      if (!data && options.toggle && /show|hide/.test(option)) options.toggle = false
      if (!data) $this.data('bs.collapse', (data = new Collapse(this, options)))
      if (typeof option == 'string') data[option]()
    })
  }

  var old = $.fn.collapse

  $.fn.collapse             = Plugin
  $.fn.collapse.Constructor = Collapse


  // COLLAPSE NO CONFLICT
  // ====================

  $.fn.collapse.noConflict = function () {
    $.fn.collapse = old
    return this
  }


  // COLLAPSE DATA-API
  // =================

  $(document).on('click.bs.collapse.data-api', '[data-toggle="collapse"]', function (e) {
    var $this   = $(this)

    if (!$this.attr('data-target')) e.preventDefault()

    var $target = getTargetFromTrigger($this)
    var data    = $target.data('bs.collapse')
    var option  = data ? 'toggle' : $this.data()

    Plugin.call($target, option)
  })

}(jQuery);

},{}],6:[function(require,module,exports){
// -----------Begin DROPDOWN JS ------------- //

+function ($) {
  'use strict';

  var backdrop = '.dropdown-backdrop'
  var toggle   = '[data-toggle="dropdown"]'
  var Dropdown = function (element) {
    $(element).on('click.dropdown', this.toggle)
  }

  Dropdown.VERSION = '1.0.0'

  function getParent($this) {
    var selector = $this.attr('data-target')

    if (!selector) {
      selector = $this.attr('href')
      selector = selector && /#[A-Za-z]/.test(selector) && selector.replace(/.*(?=#[^\s]*$)/, '') // strip for ie7
    }

    var $parent = selector && $(selector)

    return $parent && $parent.length ? $parent : $this.parent()
  }

  function clearMenus(e) {
    if (e && e.which === 3) return
    $(backdrop).remove()
    $(toggle).each(function () {
      var $this         = $(this)
      var $parent       = getParent($this)
      var relatedTarget = { relatedTarget: this }

      if (!$parent.hasClass('open')) return

      if (e && e.type == 'click' && /input|textarea/i.test(e.target.tagName) && $.contains($parent[0], e.target)) return

      $parent.trigger(e = $.Event('hide.dropdown', relatedTarget))

      if (e.isDefaultPrevented()) return

      $this.attr('aria-expanded', 'false')
      $parent.removeClass('open').trigger($.Event('hidden.dropdown', relatedTarget))
    })
  }

  Dropdown.prototype.toggle = function (e) {
    var $this = $(this)

    if ($this.is('.disabled, :disabled')) return

    var $parent  = getParent($this)
    var isActive = $parent.hasClass('open')

    clearMenus()

    if (!isActive) {
      if ('ontouchstart' in document.documentElement && !$parent.closest('.navbar-nav').length) {
        // if mobile we use a backdrop because click events don't delegate
        $(document.createElement('div'))
          .addClass('dropdown-backdrop')
          .insertAfter($(this))
          .on('click', clearMenus)
      }

      var relatedTarget = { relatedTarget: this }
      $parent.trigger(e = $.Event('show.dropdown', relatedTarget))

      if (e.isDefaultPrevented()) return

      $this
        .trigger('focus')
        .attr('aria-expanded', 'true')

      $parent
        .toggleClass('open')
        .trigger($.Event('shown.dropdown', relatedTarget))
    }

    return false
  }

  Dropdown.prototype.keydown = function (e) {
    if (!/(38|40|27|32)/.test(e.which) || /input|textarea/i.test(e.target.tagName)) return

    var $this = $(this)

    e.preventDefault()
    e.stopPropagation()

    if ($this.is('.disabled, :disabled')) return

    var $parent  = getParent($this)
    var isActive = $parent.hasClass('open')

    if (!isActive && e.which != 27 || isActive && e.which == 27) {
      if (e.which == 27) $parent.find(toggle).trigger('focus')
      return $this.trigger('click')
    }

    var desc = ' li:not(.disabled):visible a'
    var $items = $parent.find('.lp__dropdown_menu' + desc)

    if (!$items.length) return

    var index = $items.index(e.target)

    if (e.which == 38 && index > 0)                 index--         // up
    if (e.which == 40 && index < $items.length - 1) index++         // down
    if (!~index)                                    index = 0

    $items.eq(index).trigger('focus')
  }


  // DROPDOWN PLUGIN DEFINITION
  // ==========================

  function Plugin(option) {
    return this.each(function () {
      var $this = $(this)
      var data  = $this.data('.dropdown')

      if (!data) $this.data('.dropdown', (data = new Dropdown(this)))
      if (typeof option == 'string') data[option].call($this)
    })
  }

  var old = $.fn.dropdown

  $.fn.dropdown             = Plugin
  $.fn.dropdown.Constructor = Dropdown


  // DROPDOWN NO CONFLICT
  // ====================

  $.fn.dropdown.noConflict = function () {
    $.fn.dropdown = old
    return this
  }
  // APPLY TO STANDARD DROPDOWN ELEMENTS
  // ===================================

  $(document)
    .on('click.dropdown.data-api', clearMenus)
    .on('click.dropdown.data-api', '.dropdown form', function (e) { e.stopPropagation() })
    .on('click.dropdown.data-api', toggle, Dropdown.prototype.toggle)
    .on('keydown.dropdown.data-api', toggle, Dropdown.prototype.keydown)
    .on('keydown.dropdown.data-api', '.lp__dropdown_menu', Dropdown.prototype.keydown)

}(jQuery);

// Begin dropdown url
 $(document).ready(function() { 

     $('.lp__dropdown_menu li a').click(function(){
         var countryName = $(this).text();
         $(this).parent().parent().parent().find(".lp__filter_option").html(countryName);
         var option = $(this).a('href');
         if(option !== "") {
             if(option.indexOf('worldbank.org')>-1 || option.indexOf('bancomundial.org')>-1 || 
                 option.indexOf('albankaldawli.org')>-1 || option.indexOf('banquemondiale.org')>-1 || 
                 option.indexOf('shihang.org')>-1) {
                 window.location = option;
             } else {
                 var newWindow = window.open(option,"_blank");
                 newWindow.location = option;
             }
         } 

     });

 }); 
// Begin country-dropdown-search-text
    $(document).ready(function(){
$(".lp__form_control").keyup(function(){
var value = $(this).val();
$(".lp__dropdown_menu>li span .countryfirstLevel").each(function(){

   var length = value.length;
   var substring = $(this).text().toLowerCase().substring(0,length);
   //if($(this).text().toLowerCase().search(value.toLowerCase()) > -1)
   if(value===substring)
   {
   $(this).parent().parent().show();
   }else
   {
   $(this).parent().parent().hide();
   
   }
});
});
});

 $( document ).ready(function() {
  $(".lp__form_control").click(function(){
    $(".select-item").addClass("active-state");
   
  });
  $(".lp__search_section").click(function(){
    $(".select-item").removeClass("active-state");
  });
 $(".lp__search_section").click(function(){
    $(".select-item").removeClass("active-state");
  });
 }); 
// Begin country-dropdown-search-text

// -----------End DROPDOWN JS ------------- //

},{}],7:[function(require,module,exports){
/*
  html2canvas 0.4.1 <http://html2canvas.hertzen.com>
  Copyright (c) 2013 Niklas von Hertzen

  Released under MIT License
*/

(function(window, document, undefined){

//"use strict";

var _html2canvas = {},
previousElement,
computedCSS,
html2canvas;

_html2canvas.Util = {};

_html2canvas.Util.log = function(a) {
  if (_html2canvas.logging && window.console && window.console.log) {
    window.console.log(a);
  }
};

_html2canvas.Util.trimText = (function(isNative){
  return function(input) {
    return isNative ? isNative.apply(input) : ((input || '') + '').replace( /^\s+|\s+$/g , '' );
  };
})(String.prototype.trim);

_html2canvas.Util.asFloat = function(v) {
  return parseFloat(v);
};

(function() {
  // TODO: support all possible length values
  var TEXT_SHADOW_PROPERTY = /((rgba|rgb)\([^\)]+\)(\s-?\d+px){0,})/g;
  var TEXT_SHADOW_VALUES = /(-?\d+px)|(#.+)|(rgb\(.+\))|(rgba\(.+\))/g;
  _html2canvas.Util.parseTextShadows = function (value) {
    if (!value || value === 'none') {
      return [];
    }

    // find multiple shadow declarations
    var shadows = value.match(TEXT_SHADOW_PROPERTY),
      results = [];
    for (var i = 0; shadows && (i < shadows.length); i++) {
      var s = shadows[i].match(TEXT_SHADOW_VALUES);
      results.push({
        color: s[0],
        offsetX: s[1] ? s[1].replace('px', '') : 0,
        offsetY: s[2] ? s[2].replace('px', '') : 0,
        blur: s[3] ? s[3].replace('px', '') : 0
      });
    }
    return results;
  };
})();

_html2canvas.Util.parseBackgroundImage = function (value) {
    var whitespace = ' \r\n\t',
        method, definition, prefix, prefix_i, block, results = [],
        c, mode = 0, numParen = 0, quote, args;

    var appendResult = function(){
        if(method) {
            if(definition.substr( 0, 1 ) === '"') {
                definition = definition.substr( 1, definition.length - 2 );
            }
            if(definition) {
                args.push(definition);
            }
            if(method.substr( 0, 1 ) === '-' &&
                    (prefix_i = method.indexOf( '-', 1 ) + 1) > 0) {
                prefix = method.substr( 0, prefix_i);
                method = method.substr( prefix_i );
            }
            results.push({
                prefix: prefix,
                method: method.toLowerCase(),
                value: block,
                args: args
            });
        }
        args = []; //for some odd reason, setting .length = 0 didn't work in safari
        method =
            prefix =
            definition =
            block = '';
    };

    appendResult();
    for(var i = 0, ii = value.length; i<ii; i++) {
        c = value[i];
        if(mode === 0 && whitespace.indexOf( c ) > -1){
            continue;
        }
        switch(c) {
            case '"':
                if(!quote) {
                    quote = c;
                }
                else if(quote === c) {
                    quote = null;
                }
                break;

            case '(':
                if(quote) { break; }
                else if(mode === 0) {
                    mode = 1;
                    block += c;
                    continue;
                } else {
                    numParen++;
                }
                break;

            case ')':
                if(quote) { break; }
                else if(mode === 1) {
                    if(numParen === 0) {
                        mode = 0;
                        block += c;
                        appendResult();
                        continue;
                    } else {
                        numParen--;
                    }
                }
                break;

            case ',':
                if(quote) { break; }
                else if(mode === 0) {
                    appendResult();
                    continue;
                }
                else if (mode === 1) {
                    if(numParen === 0 && !method.match(/^url$/i)) {
                        args.push(definition);
                        definition = '';
                        block += c;
                        continue;
                    }
                }
                break;
        }

        block += c;
        if(mode === 0) { method += c; }
        else { definition += c; }
    }
    appendResult();

    return results;
};

_html2canvas.Util.Bounds = function (element) {
  var clientRect, bounds = {};

  if (element.getBoundingClientRect){
    clientRect = element.getBoundingClientRect();

    // TODO add scroll position to bounds, so no scrolling of window necessary
    bounds.top = clientRect.top;
    bounds.bottom = clientRect.bottom || (clientRect.top + clientRect.height);
    bounds.left = clientRect.left;

    bounds.width = element.offsetWidth;
    bounds.height = element.offsetHeight;
  }

  return bounds;
};

// TODO ideally, we'd want everything to go through this function instead of Util.Bounds,
// but would require further work to calculate the correct positions for elements with offsetParents
_html2canvas.Util.OffsetBounds = function (element) {
  var parent = element.offsetParent ? _html2canvas.Util.OffsetBounds(element.offsetParent) : {top: 0, left: 0};

  return {
    top: element.offsetTop + parent.top,
    bottom: element.offsetTop + element.offsetHeight + parent.top,
    left: element.offsetLeft + parent.left,
    width: element.offsetWidth,
    height: element.offsetHeight
  };
};

function toPX(element, attribute, value ) {
    var rsLeft = element.runtimeStyle && element.runtimeStyle[attribute],
        left,
        style = element.style;

    // Check if we are not dealing with pixels, (Opera has issues with this)
    // Ported from jQuery css.js
    // From the awesome hack by Dean Edwards
    // http://erik.eae.net/archives/2007/07/27/18.54.15/#comment-102291

    // If we're not dealing with a regular pixel number
    // but a number that has a weird ending, we need to convert it to pixels

    if ( !/^-?[0-9]+\.?[0-9]*(?:px)?$/i.test( value ) && /^-?\d/.test(value) ) {
        // Remember the original values
        left = style.left;

        // Put in the new values to get a computed value out
        if (rsLeft) {
            element.runtimeStyle.left = element.currentStyle.left;
        }
        style.left = attribute === "fontSize" ? "1em" : (value || 0);
        value = style.pixelLeft + "px";

        // Revert the changed values
        style.left = left;
        if (rsLeft) {
            element.runtimeStyle.left = rsLeft;
        }
    }

    if (!/^(thin|medium|thick)$/i.test(value)) {
        return Math.round(parseFloat(value)) + "px";
    }

    return value;
}

function asInt(val) {
    return parseInt(val, 10);
}

function isPercentage(value) {
  return value.toString().indexOf("%") !== -1;
}

function parseBackgroundSizePosition(value, element, attribute, index) {
    value = (value || '').split(',');
    value = value[index || 0] || value[0] || 'auto';
    value = _html2canvas.Util.trimText(value).split(' ');
    if(attribute === 'backgroundSize' && (value[0] && value[0].match(/^(cover|contain|auto)$/))) {
        return value;
    } else {
        value[0] = (value[0].indexOf( "%" ) === -1) ? toPX(element, attribute + "X", value[0]) : value[0];
        if(value[1] === undefined) {
            if(attribute === 'backgroundSize') {
                value[1] = 'auto';
                return value;
            } else {
                // IE 9 doesn't return double digit always
                value[1] = value[0];
            }
        }
        value[1] = (value[1].indexOf("%") === -1) ? toPX(element, attribute + "Y", value[1]) : value[1];
    }
    return value;
}

_html2canvas.Util.getCSS = function (element, attribute, index) {
    if (previousElement !== element) {
      computedCSS = document.defaultView.getComputedStyle(element, null);
    }

    var value = computedCSS[attribute];

    if (/^background(Size|Position)$/.test(attribute)) {
        return parseBackgroundSizePosition(value, element, attribute, index);
    } else if (/border(Top|Bottom)(Left|Right)Radius/.test(attribute)) {
      var arr = value.split(" ");
      if (arr.length <= 1) {
          arr[1] = arr[0];
      }
      return arr.map(asInt);
    }

  return value;
};

_html2canvas.Util.resizeBounds = function( current_width, current_height, target_width, target_height, stretch_mode ){
  var target_ratio = target_width / target_height,
    current_ratio = current_width / current_height,
    output_width, output_height;

  if(!stretch_mode || stretch_mode === 'auto') {
    output_width = target_width;
    output_height = target_height;
  } else if(target_ratio < current_ratio ^ stretch_mode === 'contain') {
    output_height = target_height;
    output_width = target_height * current_ratio;
  } else {
    output_width = target_width;
    output_height = target_width / current_ratio;
  }

  return {
    width: output_width,
    height: output_height
  };
};

_html2canvas.Util.BackgroundPosition = function(element, bounds, image, imageIndex, backgroundSize ) {
    var backgroundPosition =  _html2canvas.Util.getCSS(element, 'backgroundPosition', imageIndex),
        leftPosition,
        topPosition;
    if (backgroundPosition.length === 1){
        backgroundPosition = [backgroundPosition[0], backgroundPosition[0]];
    }

    if (isPercentage(backgroundPosition[0])){
        leftPosition = (bounds.width - (backgroundSize || image).width) * (parseFloat(backgroundPosition[0]) / 100);
    } else {
        leftPosition = parseInt(backgroundPosition[0], 10);
    }

    if (backgroundPosition[1] === 'auto') {
        topPosition = leftPosition / image.width * image.height;
    } else if (isPercentage(backgroundPosition[1])){
        topPosition =  (bounds.height - (backgroundSize || image).height) * parseFloat(backgroundPosition[1]) / 100;
    } else {
        topPosition = parseInt(backgroundPosition[1], 10);
    }

    if (backgroundPosition[0] === 'auto') {
        leftPosition = topPosition / image.height * image.width;
    }

    return {left: leftPosition, top: topPosition};
};

_html2canvas.Util.BackgroundSize = function(element, bounds, image, imageIndex) {
  var backgroundSize =  _html2canvas.Util.getCSS(element, 'backgroundSize', imageIndex), width, height;

  if (backgroundSize.length === 1) {
    backgroundSize = [backgroundSize[0], backgroundSize[0]];
  }

  if (isPercentage(backgroundSize[0])) {
    width = bounds.width * parseFloat(backgroundSize[0]) / 100;
  } else if (/contain|cover/.test(backgroundSize[0])) {
    return _html2canvas.Util.resizeBounds(image.width, image.height, bounds.width, bounds.height, backgroundSize[0]);
  } else {
    width = parseInt(backgroundSize[0], 10);
  }

  if (backgroundSize[0] === 'auto' && backgroundSize[1] === 'auto') {
    height = image.height;
  } else if (backgroundSize[1] === 'auto') {
    height = width / image.width * image.height;
  } else if (isPercentage(backgroundSize[1])) {
    height =  bounds.height * parseFloat(backgroundSize[1]) / 100;
  } else {
    height = parseInt(backgroundSize[1], 10);
  }

  if (backgroundSize[0] === 'auto') {
    width = height / image.height * image.width;
  }

  return {width: width, height: height};
};

_html2canvas.Util.BackgroundRepeat = function(element, imageIndex) {
  var backgroundRepeat = _html2canvas.Util.getCSS(element, "backgroundRepeat").split(",").map(_html2canvas.Util.trimText);
  return backgroundRepeat[imageIndex] || backgroundRepeat[0];
};

_html2canvas.Util.Extend = function (options, defaults) {
  for (var key in options) {
    if (options.hasOwnProperty(key)) {
      defaults[key] = options[key];
    }
  }
  return defaults;
};


/*
 * Derived from jQuery.contents()
 * Copyright 2010, John Resig
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 */
_html2canvas.Util.Children = function( elem ) {
  var children;
  try {
    children = (elem.nodeName && elem.nodeName.toUpperCase() === "IFRAME") ? elem.contentDocument || elem.contentWindow.document : (function(array) {
      var ret = [];
      if (array !== null) {
        (function(first, second ) {
          var i = first.length,
          j = 0;

          if (typeof second.length === "number") {
            for (var l = second.length; j < l; j++) {
              first[i++] = second[j];
            }
          } else {
            while (second[j] !== undefined) {
              first[i++] = second[j++];
            }
          }

          first.length = i;

          return first;
        })(ret, array);
      }
      return ret;
    })(elem.childNodes);

  } catch (ex) {
    _html2canvas.Util.log("html2canvas.Util.Children failed with exception: " + ex.message);
    children = [];
  }
  return children;
};

_html2canvas.Util.isTransparent = function(backgroundColor) {
  return (!backgroundColor || backgroundColor === "transparent" || backgroundColor === "rgba(0, 0, 0, 0)");
};

_html2canvas.Util.Font = (function () {

  var fontData = {};

  return function(font, fontSize, doc) {
    if (fontData[font + "-" + fontSize] !== undefined) {
      return fontData[font + "-" + fontSize];
    }

    var container = doc.createElement('div'),
    img = doc.createElement('img'),
    span = doc.createElement('span'),
    sampleText = 'Hidden Text',
    baseline,
    middle,
    metricsObj;

    container.style.visibility = "hidden";
    container.style.fontFamily = font;
    container.style.fontSize = fontSize;
    container.style.margin = 0;
    container.style.padding = 0;

    doc.body.appendChild(container);

    // http://probablyprogramming.com/2009/03/15/the-tiniest-gif-ever (handtinywhite.gif)
    img.src = "data:image/gif;base64,R0lGODlhAQABAIABAP///wAAACwAAAAAAQABAAACAkQBADs=";
    img.width = 1;
    img.height = 1;

    img.style.margin = 0;
    img.style.padding = 0;
    img.style.verticalAlign = "baseline";

    span.style.fontFamily = font;
    span.style.fontSize = fontSize;
    span.style.margin = 0;
    span.style.padding = 0;

    span.appendChild(doc.createTextNode(sampleText));
    container.appendChild(span);
    container.appendChild(img);
    baseline = (img.offsetTop - span.offsetTop) + 1;

    container.removeChild(span);
    container.appendChild(doc.createTextNode(sampleText));

    container.style.lineHeight = "normal";
    img.style.verticalAlign = "super";

    middle = (img.offsetTop-container.offsetTop) + 1;
    metricsObj = {
      baseline: baseline,
      lineWidth: 1,
      middle: middle
    };

    fontData[font + "-" + fontSize] = metricsObj;

    doc.body.removeChild(container);

    return metricsObj;
  };
})();

(function(){
  var Util = _html2canvas.Util,
    Generate = {};

  _html2canvas.Generate = Generate;

  var reGradients = [
  /^(-webkit-linear-gradient)\(([a-z\s]+)([\w\d\.\s,%\(\)]+)\)$/,
  /^(-o-linear-gradient)\(([a-z\s]+)([\w\d\.\s,%\(\)]+)\)$/,
  /^(-webkit-gradient)\((linear|radial),\s((?:\d{1,3}%?)\s(?:\d{1,3}%?),\s(?:\d{1,3}%?)\s(?:\d{1,3}%?))([\w\d\.\s,%\(\)\-]+)\)$/,
  /^(-moz-linear-gradient)\(((?:\d{1,3}%?)\s(?:\d{1,3}%?))([\w\d\.\s,%\(\)]+)\)$/,
  /^(-webkit-radial-gradient)\(((?:\d{1,3}%?)\s(?:\d{1,3}%?)),\s(\w+)\s([a-z\-]+)([\w\d\.\s,%\(\)]+)\)$/,
  /^(-moz-radial-gradient)\(((?:\d{1,3}%?)\s(?:\d{1,3}%?)),\s(\w+)\s?([a-z\-]*)([\w\d\.\s,%\(\)]+)\)$/,
  /^(-o-radial-gradient)\(((?:\d{1,3}%?)\s(?:\d{1,3}%?)),\s(\w+)\s([a-z\-]+)([\w\d\.\s,%\(\)]+)\)$/
  ];

  /*
 * TODO: Add IE10 vendor prefix (-ms) support
 * TODO: Add W3C gradient (linear-gradient) support
 * TODO: Add old Webkit -webkit-gradient(radial, ...) support
 * TODO: Maybe some RegExp optimizations are possible ;o)
 */
  Generate.parseGradient = function(css, bounds) {
    var gradient, i, len = reGradients.length, m1, stop, m2, m2Len, step, m3, tl,tr,br,bl;

    for(i = 0; i < len; i+=1){
      m1 = css.match(reGradients[i]);
      if(m1) {
        break;
      }
    }

    if(m1) {
      switch(m1[1]) {
        case '-webkit-linear-gradient':
        case '-o-linear-gradient':

          gradient = {
            type: 'linear',
            x0: null,
            y0: null,
            x1: null,
            y1: null,
            colorStops: []
          };

          // get coordinates
          m2 = m1[2].match(/\w+/g);
          if(m2){
            m2Len = m2.length;
            for(i = 0; i < m2Len; i+=1){
              switch(m2[i]) {
                case 'top':
                  gradient.y0 = 0;
                  gradient.y1 = bounds.height;
                  break;

                case 'right':
                  gradient.x0 = bounds.width;
                  gradient.x1 = 0;
                  break;

                case 'bottom':
                  gradient.y0 = bounds.height;
                  gradient.y1 = 0;
                  break;

                case 'left':
                  gradient.x0 = 0;
                  gradient.x1 = bounds.width;
                  break;
              }
            }
          }
          if(gradient.x0 === null && gradient.x1 === null){ // center
            gradient.x0 = gradient.x1 = bounds.width / 2;
          }
          if(gradient.y0 === null && gradient.y1 === null){ // center
            gradient.y0 = gradient.y1 = bounds.height / 2;
          }

          // get colors and stops
          m2 = m1[3].match(/((?:rgb|rgba)\(\d{1,3},\s\d{1,3},\s\d{1,3}(?:,\s[0-9\.]+)?\)(?:\s\d{1,3}(?:%|px))?)+/g);
          if(m2){
            m2Len = m2.length;
            step = 1 / Math.max(m2Len - 1, 1);
            for(i = 0; i < m2Len; i+=1){
              m3 = m2[i].match(/((?:rgb|rgba)\(\d{1,3},\s\d{1,3},\s\d{1,3}(?:,\s[0-9\.]+)?\))\s*(\d{1,3})?(%|px)?/);
              if(m3[2]){
                stop = parseFloat(m3[2]);
                if(m3[3] === '%'){
                  stop /= 100;
                } else { // px - stupid opera
                  stop /= bounds.width;
                }
              } else {
                stop = i * step;
              }
              gradient.colorStops.push({
                color: m3[1],
                stop: stop
              });
            }
          }
          break;

        case '-webkit-gradient':

          gradient = {
            type: m1[2] === 'radial' ? 'circle' : m1[2], // TODO: Add radial gradient support for older mozilla definitions
            x0: 0,
            y0: 0,
            x1: 0,
            y1: 0,
            colorStops: []
          };

          // get coordinates
          m2 = m1[3].match(/(\d{1,3})%?\s(\d{1,3})%?,\s(\d{1,3})%?\s(\d{1,3})%?/);
          if(m2){
            gradient.x0 = (m2[1] * bounds.width) / 100;
            gradient.y0 = (m2[2] * bounds.height) / 100;
            gradient.x1 = (m2[3] * bounds.width) / 100;
            gradient.y1 = (m2[4] * bounds.height) / 100;
          }

          // get colors and stops
          m2 = m1[4].match(/((?:from|to|color-stop)\((?:[0-9\.]+,\s)?(?:rgb|rgba)\(\d{1,3},\s\d{1,3},\s\d{1,3}(?:,\s[0-9\.]+)?\)\))+/g);
          if(m2){
            m2Len = m2.length;
            for(i = 0; i < m2Len; i+=1){
              m3 = m2[i].match(/(from|to|color-stop)\(([0-9\.]+)?(?:,\s)?((?:rgb|rgba)\(\d{1,3},\s\d{1,3},\s\d{1,3}(?:,\s[0-9\.]+)?\))\)/);
              stop = parseFloat(m3[2]);
              if(m3[1] === 'from') {
                stop = 0.0;
              }
              if(m3[1] === 'to') {
                stop = 1.0;
              }
              gradient.colorStops.push({
                color: m3[3],
                stop: stop
              });
            }
          }
          break;

        case '-moz-linear-gradient':

          gradient = {
            type: 'linear',
            x0: 0,
            y0: 0,
            x1: 0,
            y1: 0,
            colorStops: []
          };

          // get coordinates
          m2 = m1[2].match(/(\d{1,3})%?\s(\d{1,3})%?/);

          // m2[1] == 0%   -> left
          // m2[1] == 50%  -> center
          // m2[1] == 100% -> right

          // m2[2] == 0%   -> top
          // m2[2] == 50%  -> center
          // m2[2] == 100% -> bottom

          if(m2){
            gradient.x0 = (m2[1] * bounds.width) / 100;
            gradient.y0 = (m2[2] * bounds.height) / 100;
            gradient.x1 = bounds.width - gradient.x0;
            gradient.y1 = bounds.height - gradient.y0;
          }

          // get colors and stops
          m2 = m1[3].match(/((?:rgb|rgba)\(\d{1,3},\s\d{1,3},\s\d{1,3}(?:,\s[0-9\.]+)?\)(?:\s\d{1,3}%)?)+/g);
          if(m2){
            m2Len = m2.length;
            step = 1 / Math.max(m2Len - 1, 1);
            for(i = 0; i < m2Len; i+=1){
              m3 = m2[i].match(/((?:rgb|rgba)\(\d{1,3},\s\d{1,3},\s\d{1,3}(?:,\s[0-9\.]+)?\))\s*(\d{1,3})?(%)?/);
              if(m3[2]){
                stop = parseFloat(m3[2]);
                if(m3[3]){ // percentage
                  stop /= 100;
                }
              } else {
                stop = i * step;
              }
              gradient.colorStops.push({
                color: m3[1],
                stop: stop
              });
            }
          }
          break;

        case '-webkit-radial-gradient':
        case '-moz-radial-gradient':
        case '-o-radial-gradient':

          gradient = {
            type: 'circle',
            x0: 0,
            y0: 0,
            x1: bounds.width,
            y1: bounds.height,
            cx: 0,
            cy: 0,
            rx: 0,
            ry: 0,
            colorStops: []
          };

          // center
          m2 = m1[2].match(/(\d{1,3})%?\s(\d{1,3})%?/);
          if(m2){
            gradient.cx = (m2[1] * bounds.width) / 100;
            gradient.cy = (m2[2] * bounds.height) / 100;
          }

          // size
          m2 = m1[3].match(/\w+/);
          m3 = m1[4].match(/[a-z\-]*/);
          if(m2 && m3){
            switch(m3[0]){
              case 'farthest-corner':
              case 'cover': // is equivalent to farthest-corner
              case '': // mozilla removes "cover" from definition :(
                tl = Math.sqrt(Math.pow(gradient.cx, 2) + Math.pow(gradient.cy, 2));
                tr = Math.sqrt(Math.pow(gradient.cx, 2) + Math.pow(gradient.y1 - gradient.cy, 2));
                br = Math.sqrt(Math.pow(gradient.x1 - gradient.cx, 2) + Math.pow(gradient.y1 - gradient.cy, 2));
                bl = Math.sqrt(Math.pow(gradient.x1 - gradient.cx, 2) + Math.pow(gradient.cy, 2));
                gradient.rx = gradient.ry = Math.max(tl, tr, br, bl);
                break;
              case 'closest-corner':
                tl = Math.sqrt(Math.pow(gradient.cx, 2) + Math.pow(gradient.cy, 2));
                tr = Math.sqrt(Math.pow(gradient.cx, 2) + Math.pow(gradient.y1 - gradient.cy, 2));
                br = Math.sqrt(Math.pow(gradient.x1 - gradient.cx, 2) + Math.pow(gradient.y1 - gradient.cy, 2));
                bl = Math.sqrt(Math.pow(gradient.x1 - gradient.cx, 2) + Math.pow(gradient.cy, 2));
                gradient.rx = gradient.ry = Math.min(tl, tr, br, bl);
                break;
              case 'farthest-side':
                if(m2[0] === 'circle'){
                  gradient.rx = gradient.ry = Math.max(
                    gradient.cx,
                    gradient.cy,
                    gradient.x1 - gradient.cx,
                    gradient.y1 - gradient.cy
                    );
                } else { // ellipse

                  gradient.type = m2[0];

                  gradient.rx = Math.max(
                    gradient.cx,
                    gradient.x1 - gradient.cx
                    );
                  gradient.ry = Math.max(
                    gradient.cy,
                    gradient.y1 - gradient.cy
                    );
                }
                break;
              case 'closest-side':
              case 'contain': // is equivalent to closest-side
                if(m2[0] === 'circle'){
                  gradient.rx = gradient.ry = Math.min(
                    gradient.cx,
                    gradient.cy,
                    gradient.x1 - gradient.cx,
                    gradient.y1 - gradient.cy
                    );
                } else { // ellipse

                  gradient.type = m2[0];

                  gradient.rx = Math.min(
                    gradient.cx,
                    gradient.x1 - gradient.cx
                    );
                  gradient.ry = Math.min(
                    gradient.cy,
                    gradient.y1 - gradient.cy
                    );
                }
                break;

            // TODO: add support for "30px 40px" sizes (webkit only)
            }
          }

          // color stops
          m2 = m1[5].match(/((?:rgb|rgba)\(\d{1,3},\s\d{1,3},\s\d{1,3}(?:,\s[0-9\.]+)?\)(?:\s\d{1,3}(?:%|px))?)+/g);
          if(m2){
            m2Len = m2.length;
            step = 1 / Math.max(m2Len - 1, 1);
            for(i = 0; i < m2Len; i+=1){
              m3 = m2[i].match(/((?:rgb|rgba)\(\d{1,3},\s\d{1,3},\s\d{1,3}(?:,\s[0-9\.]+)?\))\s*(\d{1,3})?(%|px)?/);
              if(m3[2]){
                stop = parseFloat(m3[2]);
                if(m3[3] === '%'){
                  stop /= 100;
                } else { // px - stupid opera
                  stop /= bounds.width;
                }
              } else {
                stop = i * step;
              }
              gradient.colorStops.push({
                color: m3[1],
                stop: stop
              });
            }
          }
          break;
      }
    }

    return gradient;
  };

  function addScrollStops(grad) {
    return function(colorStop) {
      try {
        grad.addColorStop(colorStop.stop, colorStop.color);
      }
      catch(e) {
        Util.log(['failed to add color stop: ', e, '; tried to add: ', colorStop]);
      }
    };
  }

  Generate.Gradient = function(src, bounds) {
    if(bounds.width === 0 || bounds.height === 0) {
      return;
    }

    var canvas = document.createElement('canvas'),
    ctx = canvas.getContext('2d'),
    gradient, grad;

    canvas.width = bounds.width;
    canvas.height = bounds.height;

    // TODO: add support for multi defined background gradients
    gradient = _html2canvas.Generate.parseGradient(src, bounds);

    if(gradient) {
      switch(gradient.type) {
        case 'linear':
          grad = ctx.createLinearGradient(gradient.x0, gradient.y0, gradient.x1, gradient.y1);
          gradient.colorStops.forEach(addScrollStops(grad));
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, bounds.width, bounds.height);
          break;

        case 'circle':
          grad = ctx.createRadialGradient(gradient.cx, gradient.cy, 0, gradient.cx, gradient.cy, gradient.rx);
          gradient.colorStops.forEach(addScrollStops(grad));
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, bounds.width, bounds.height);
          break;

        case 'ellipse':
          var canvasRadial = document.createElement('canvas'),
            ctxRadial = canvasRadial.getContext('2d'),
            ri = Math.max(gradient.rx, gradient.ry),
            di = ri * 2;

          canvasRadial.width = canvasRadial.height = di;

          grad = ctxRadial.createRadialGradient(gradient.rx, gradient.ry, 0, gradient.rx, gradient.ry, ri);
          gradient.colorStops.forEach(addScrollStops(grad));

          ctxRadial.fillStyle = grad;
          ctxRadial.fillRect(0, 0, di, di);

          ctx.fillStyle = gradient.colorStops[gradient.colorStops.length - 1].color;
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(canvasRadial, gradient.cx - gradient.rx, gradient.cy - gradient.ry, 2 * gradient.rx, 2 * gradient.ry);
          break;
      }
    }

    return canvas;
  };

  Generate.ListAlpha = function(number) {
    var tmp = "",
    modulus;

    do {
      modulus = number % 26;
      tmp = String.fromCharCode((modulus) + 64) + tmp;
      number = number / 26;
    }while((number*26) > 26);

    return tmp;
  };

  Generate.ListRoman = function(number) {
    var romanArray = ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"],
    decimal = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1],
    roman = "",
    v,
    len = romanArray.length;

    if (number <= 0 || number >= 4000) {
      return number;
    }

    for (v=0; v < len; v+=1) {
      while (number >= decimal[v]) {
        number -= decimal[v];
        roman += romanArray[v];
      }
    }

    return roman;
  };
})();
function h2cRenderContext(width, height) {
  var storage = [];
  return {
    storage: storage,
    width: width,
    height: height,
    clip: function() {
      storage.push({
        type: "function",
        name: "clip",
        'arguments': arguments
      });
    },
    translate: function() {
      storage.push({
        type: "function",
        name: "translate",
        'arguments': arguments
      });
    },
    fill: function() {
      storage.push({
        type: "function",
        name: "fill",
        'arguments': arguments
      });
    },
    save: function() {
      storage.push({
        type: "function",
        name: "save",
        'arguments': arguments
      });
    },
    restore: function() {
      storage.push({
        type: "function",
        name: "restore",
        'arguments': arguments
      });
    },
    fillRect: function () {
      storage.push({
        type: "function",
        name: "fillRect",
        'arguments': arguments
      });
    },
    createPattern: function() {
      storage.push({
        type: "function",
        name: "createPattern",
        'arguments': arguments
      });
    },
    drawShape: function() {

      var shape = [];

      storage.push({
        type: "function",
        name: "drawShape",
        'arguments': shape
      });

      return {
        moveTo: function() {
          shape.push({
            name: "moveTo",
            'arguments': arguments
          });
        },
        lineTo: function() {
          shape.push({
            name: "lineTo",
            'arguments': arguments
          });
        },
        arcTo: function() {
          shape.push({
            name: "arcTo",
            'arguments': arguments
          });
        },
        bezierCurveTo: function() {
          shape.push({
            name: "bezierCurveTo",
            'arguments': arguments
          });
        },
        quadraticCurveTo: function() {
          shape.push({
            name: "quadraticCurveTo",
            'arguments': arguments
          });
        }
      };

    },
    drawImage: function () {
      storage.push({
        type: "function",
        name: "drawImage",
        'arguments': arguments
      });
    },
    fillText: function () {
      storage.push({
        type: "function",
        name: "fillText",
        'arguments': arguments
      });
    },
    setVariable: function (variable, value) {
      storage.push({
        type: "variable",
        name: variable,
        'arguments': value
      });
      return value;
    }
  };
}
_html2canvas.Parse = function (images, options, cb) {
  window.scroll(0,0);

  var element = (( options.elements === undefined ) ? document.body : options.elements[0]), // select body by default
  numDraws = 0,
  doc = element.ownerDocument,
  Util = _html2canvas.Util,
  support = Util.Support(options, doc),
  ignoreElementsRegExp = new RegExp("(" + options.ignoreElements + ")"),
  body = doc.body,
  getCSS = Util.getCSS,
  pseudoHide = "___html2canvas___pseudoelement",
  hidePseudoElementsStyles = doc.createElement('style');

  hidePseudoElementsStyles.innerHTML = '.' + pseudoHide +
  '-parent:before { content: "" !important; display: none !important; }' +
  '.' + pseudoHide + '-parent:after { content: "" !important; display: none !important; }';

  body.appendChild(hidePseudoElementsStyles);

  images = images || {};

  init();

  function init() {
    var background = getCSS(document.documentElement, "backgroundColor"),
      transparentBackground = (Util.isTransparent(background) && element === document.body),
      stack = renderElement(element, null, false, transparentBackground);

    // create pseudo elements in a single pass to prevent synchronous layouts
    addPseudoElements(element);

    parseChildren(element, stack, function() {
      if (transparentBackground) {
        background = stack.backgroundColor;
      }

      removePseudoElements();

      Util.log('Done parsing, moving to Render.');

      cb({
        backgroundColor: background,
        stack: stack
      });
    });
  }

  // Given a root element, find all pseudo elements below, create elements mocking pseudo element styles
  // so we can process them as normal elements, and hide the original pseudo elements so they don't interfere
  // with layout.
  function addPseudoElements(el) {
    // These are done in discrete steps to prevent a relayout loop caused by addClass() invalidating
    // layouts & getPseudoElement calling getComputedStyle.
    var jobs = [], classes = [];
    getPseudoElementClasses();
    findPseudoElements(el);
    runJobs();

    function getPseudoElementClasses(){
      var findPsuedoEls = /:before|:after/;
      var sheets = document.styleSheets;
      for (var i = 0, j = sheets.length; i < j; i++) {
        try {
          var rules = sheets[i].cssRules;
          for (var k = 0, l = rules.length; k < l; k++) {
            if(findPsuedoEls.test(rules[k].selectorText)) {
              classes.push(rules[k].selectorText);
            }
          }
        }
        catch(e) { // will throw security exception for style sheets loaded from external domains
        }
      }

      // Trim off the :after and :before (or ::after and ::before)
      for (i = 0, j = classes.length; i < j; i++) {
        classes[i] = classes[i].match(/(^[^:]*)/)[1];
      }
    }

    // Using the list of elements we know how pseudo el styles, create fake pseudo elements.
    function findPseudoElements(el) {
      var els = document.querySelectorAll(classes.join(','));
      for(var i = 0, j = els.length; i < j; i++) {
        createPseudoElements(els[i]);
      }
    }

    // Create pseudo elements & add them to a job queue.
    function createPseudoElements(el) {
      var before = getPseudoElement(el, ':before'),
      after = getPseudoElement(el, ':after');

      if(before) {
        jobs.push({type: 'before', pseudo: before, el: el});
      }

      if (after) {
        jobs.push({type: 'after', pseudo: after, el: el});
      }
    }

    // Adds a class to the pseudo's parent to prevent the original before/after from messing
    // with layouts.
    // Execute the inserts & addClass() calls in a batch to prevent relayouts.
    function runJobs() {
      // Add Class
      jobs.forEach(function(job){
        addClass(job.el, pseudoHide + "-parent");
      });

      // Insert el
      jobs.forEach(function(job){
        if(job.type === 'before'){
          job.el.insertBefore(job.pseudo, job.el.firstChild);
        } else {
          job.el.appendChild(job.pseudo);
        }
      });
    }
  }



  // Delete our fake pseudo elements from the DOM. This will remove those actual elements
  // and the classes on their parents that hide the actual pseudo elements.
  // Note that NodeLists are 'live' collections so you can't use a for loop here. They are
  // actually deleted from the NodeList after each iteration.
  function removePseudoElements(){
    // delete pseudo elements
    body.removeChild(hidePseudoElementsStyles);
    var pseudos = document.getElementsByClassName(pseudoHide + "-element");
    while (pseudos.length) {
      pseudos[0].parentNode.removeChild(pseudos[0]);
    }

    // Remove pseudo hiding classes
    var parents = document.getElementsByClassName(pseudoHide + "-parent");
    while(parents.length) {
      removeClass(parents[0], pseudoHide + "-parent");
    }
  }

  function addClass (el, className) {
    if (el.classList) {
      el.classList.add(className);
    } else {
      el.className = el.className + " " + className;
    }
  }

  function removeClass (el, className) {
    if (el.classList) {
      el.classList.remove(className);
    } else {
      el.className = el.className.replace(className, "").trim();
    }
  }

  function hasClass (el, className) {
    return el.className.indexOf(className) > -1;
  }

  // Note that this doesn't work in < IE8, but we don't support that anyhow
  function nodeListToArray (nodeList) {
    return Array.prototype.slice.call(nodeList);
  }

  function documentWidth () {
    return Math.max(
      Math.max(doc.body.scrollWidth, doc.documentElement.scrollWidth),
      Math.max(doc.body.offsetWidth, doc.documentElement.offsetWidth),
      Math.max(doc.body.clientWidth, doc.documentElement.clientWidth)
      );
  }

  function documentHeight () {
    return Math.max(
      Math.max(doc.body.scrollHeight, doc.documentElement.scrollHeight),
      Math.max(doc.body.offsetHeight, doc.documentElement.offsetHeight),
      Math.max(doc.body.clientHeight, doc.documentElement.clientHeight)
      );
  }

  function getCSSInt(element, attribute) {
    var val = parseInt(getCSS(element, attribute), 10);
    return (isNaN(val)) ? 0 : val; // borders in old IE are throwing 'medium' for demo.html
  }

  function renderRect (ctx, x, y, w, h, bgcolor) {
    if (bgcolor !== "transparent"){
      ctx.setVariable("fillStyle", bgcolor);
      ctx.fillRect(x, y, w, h);
      numDraws+=1;
    }
  }

  function capitalize(m, p1, p2) {
    if (m.length > 0) {
      return p1 + p2.toUpperCase();
    }
  }

  function textTransform (text, transform) {
    switch(transform){
      case "lowercase":
        return text.toLowerCase();
      case "capitalize":
        return text.replace( /(^|\s|:|-|\(|\))([a-z])/g, capitalize);
      case "uppercase":
        return text.toUpperCase();
      default:
        return text;
    }
  }

  function noLetterSpacing(letter_spacing) {
    return (/^(normal|none|0px)$/.test(letter_spacing));
  }

  function drawText(currentText, x, y, ctx){
    if (currentText !== null && Util.trimText(currentText).length > 0) {
      ctx.fillText(currentText, x, y);
      numDraws+=1;
    }
  }

  function setTextVariables(ctx, el, text_decoration, color) {
    var align = false,
    bold = getCSS(el, "fontWeight"),
    family = getCSS(el, "fontFamily"),
    size = getCSS(el, "fontSize"),
    shadows = Util.parseTextShadows(getCSS(el, "textShadow"));

    switch(parseInt(bold, 10)){
      case 401:
        bold = "bold";
        break;
      case 400:
        bold = "normal";
        break;
    }

    ctx.setVariable("fillStyle", color);
    ctx.setVariable("font", [getCSS(el, "fontStyle"), getCSS(el, "fontVariant"), bold, size, family].join(" "));
    ctx.setVariable("textAlign", (align) ? "right" : "left");

    if (shadows.length) {
      // TODO: support multiple text shadows
      // apply the first text shadow
      ctx.setVariable("shadowColor", shadows[0].color);
      ctx.setVariable("shadowOffsetX", shadows[0].offsetX);
      ctx.setVariable("shadowOffsetY", shadows[0].offsetY);
      ctx.setVariable("shadowBlur", shadows[0].blur);
    }

    if (text_decoration !== "none"){
      return Util.Font(family, size, doc);
    }
  }

  function renderTextDecoration(ctx, text_decoration, bounds, metrics, color) {
    switch(text_decoration) {
      case "underline":
        // Draws a line at the baseline of the font
        // TODO As some browsers display the line as more than 1px if the font-size is big, need to take that into account both in position and size
        renderRect(ctx, bounds.left, Math.round(bounds.top + metrics.baseline + metrics.lineWidth), bounds.width, 1, color);
        break;
      case "overline":
        renderRect(ctx, bounds.left, Math.round(bounds.top), bounds.width, 1, color);
        break;
      case "line-through":
        // TODO try and find exact position for line-through
        renderRect(ctx, bounds.left, Math.ceil(bounds.top + metrics.middle + metrics.lineWidth), bounds.width, 1, color);
        break;
    }
  }

  function getTextBounds(state, text, textDecoration, isLast, transform) {
    var bounds;
    if (support.rangeBounds && !transform) {
      if (textDecoration !== "none" || Util.trimText(text).length !== 0) {
        bounds = textRangeBounds(text, state.node, state.textOffset);
      }
      state.textOffset += text.length;
    } else if (state.node && typeof state.node.nodeValue === "string" ){
      var newTextNode = (isLast) ? state.node.splitText(text.length) : null;
      bounds = textWrapperBounds(state.node, transform);
      state.node = newTextNode;
    }
    return bounds;
  }

  function textRangeBounds(text, textNode, textOffset) {
    var range = doc.createRange();
    range.setStart(textNode, textOffset);
    range.setEnd(textNode, textOffset + text.length);
    return range.getBoundingClientRect();
  }

  function textWrapperBounds(oldTextNode, transform) {
    var parent = oldTextNode.parentNode,
    wrapElement = doc.createElement('wrapper'),
    backupText = oldTextNode.cloneNode(true);

    wrapElement.appendChild(oldTextNode.cloneNode(true));
    parent.replaceChild(wrapElement, oldTextNode);

    var bounds = transform ? Util.OffsetBounds(wrapElement) : Util.Bounds(wrapElement);
    parent.replaceChild(backupText, wrapElement);
    return bounds;
  }

  function renderText(el, textNode, stack) {
    var ctx = stack.ctx,
    color = getCSS(el, "color"),
    textDecoration = getCSS(el, "textDecoration"),
    textAlign = getCSS(el, "textAlign"),
    metrics,
    textList,
    state = {
      node: textNode,
      textOffset: 0
    };

    if (Util.trimText(textNode.nodeValue).length > 0) {
      textNode.nodeValue = textTransform(textNode.nodeValue, getCSS(el, "textTransform"));
      textAlign = textAlign.replace(["-webkit-auto"],["auto"]);

      textList = (!options.letterRendering && /^(left|right|justify|auto)$/.test(textAlign) && noLetterSpacing(getCSS(el, "letterSpacing"))) ?
      textNode.nodeValue.split(/(\b| )/)
      : textNode.nodeValue.split("");

      metrics = setTextVariables(ctx, el, textDecoration, color);

      if (options.chinese) {
        textList.forEach(function(word, index) {
          if (/.*[\u4E00-\u9FA5].*$/.test(word)) {
            word = word.split("");
            word.unshift(index, 1);
            textList.splice.apply(textList, word);
          }
        });
      }

      textList.forEach(function(text, index) {
        var bounds = getTextBounds(state, text, textDecoration, (index < textList.length - 1), stack.transform.matrix);
        if (bounds) {
          drawText(text, bounds.left, bounds.bottom, ctx);
          renderTextDecoration(ctx, textDecoration, bounds, metrics, color);
        }
      });
    }
  }

  function listPosition (element, val) {
    var boundElement = doc.createElement( "boundelement" ),
    originalType,
    bounds;

    boundElement.style.display = "inline";

    originalType = element.style.listStyleType;
    element.style.listStyleType = "none";

    boundElement.appendChild(doc.createTextNode(val));

    element.insertBefore(boundElement, element.firstChild);

    bounds = Util.Bounds(boundElement);
    element.removeChild(boundElement);
    element.style.listStyleType = originalType;
    return bounds;
  }

  function elementIndex(el) {
    var i = -1,
    count = 1,
    childs = el.parentNode.childNodes;

    if (el.parentNode) {
      while(childs[++i] !== el) {
        if (childs[i].nodeType === 1) {
          count++;
        }
      }
      return count;
    } else {
      return -1;
    }
  }

  function listItemText(element, type) {
    var currentIndex = elementIndex(element), text;
    switch(type){
      case "decimal":
        text = currentIndex;
        break;
      case "decimal-leading-zero":
        text = (currentIndex.toString().length === 1) ? currentIndex = "0" + currentIndex.toString() : currentIndex.toString();
        break;
      case "upper-roman":
        text = _html2canvas.Generate.ListRoman( currentIndex );
        break;
      case "lower-roman":
        text = _html2canvas.Generate.ListRoman( currentIndex ).toLowerCase();
        break;
      case "lower-alpha":
        text = _html2canvas.Generate.ListAlpha( currentIndex ).toLowerCase();
        break;
      case "upper-alpha":
        text = _html2canvas.Generate.ListAlpha( currentIndex );
        break;
    }

    return text + ". ";
  }

  function renderListItem(element, stack, elBounds) {
    var x,
    text,
    ctx = stack.ctx,
    type = getCSS(element, "listStyleType"),
    listBounds;

    if (/^(decimal|decimal-leading-zero|upper-alpha|upper-latin|upper-roman|lower-alpha|lower-greek|lower-latin|lower-roman)$/i.test(type)) {
      text = listItemText(element, type);
      listBounds = listPosition(element, text);
      setTextVariables(ctx, element, "none", getCSS(element, "color"));

      if (getCSS(element, "listStylePosition") === "inside") {
        ctx.setVariable("textAlign", "left");
        x = elBounds.left;
      } else {
        return;
      }

      drawText(text, x, listBounds.bottom, ctx);
    }
  }

  function loadImage (src){
    var img = images[src];
    return (img && img.succeeded === true) ? img.img : false;
  }

  function clipBounds(src, dst){
    var x = Math.max(src.left, dst.left),
    y = Math.max(src.top, dst.top),
    x2 = Math.min((src.left + src.width), (dst.left + dst.width)),
    y2 = Math.min((src.top + src.height), (dst.top + dst.height));

    return {
      left:x,
      top:y,
      width:x2-x,
      height:y2-y
    };
  }

  function setZ(element, stack, parentStack){
    var newContext,
    isPositioned = stack.cssPosition !== 'static',
    zIndex = isPositioned ? getCSS(element, 'zIndex') : 'auto',
    opacity = getCSS(element, 'opacity'),
    isFloated = getCSS(element, 'cssFloat') !== 'none';

    // https://developer.mozilla.org/en-US/docs/Web/Guide/CSS/Understanding_z_index/The_stacking_context
    // When a new stacking context should be created:
    // the root element (HTML),
    // positioned (absolutely or relatively) with a z-index value other than "auto",
    // elements with an opacity value less than 1. (See the specification for opacity),
    // on mobile WebKit and Chrome 22+, position: fixed always creates a new stacking context, even when z-index is "auto" (See this post)

    stack.zIndex = newContext = h2czContext(zIndex);
    newContext.isPositioned = isPositioned;
    newContext.isFloated = isFloated;
    newContext.opacity = opacity;
    newContext.ownStacking = (zIndex !== 'auto' || opacity < 1);
    newContext.depth = parentStack ? (parentStack.zIndex.depth + 1) : 0;

    if (parentStack) {
      parentStack.zIndex.children.push(stack);
    }
  }

  function h2czContext(zindex) {
    return {
      depth: 0,
      zindex: zindex,
      children: []
    };
  }

  function renderImage(ctx, element, image, bounds, borders) {

    var paddingLeft = getCSSInt(element, 'paddingLeft'),
    paddingTop = getCSSInt(element, 'paddingTop'),
    paddingRight = getCSSInt(element, 'paddingRight'),
    paddingBottom = getCSSInt(element, 'paddingBottom');

    drawImage(
      ctx,
      image,
      0, //sx
      0, //sy
      image.width, //sw
      image.height, //sh
      bounds.left + paddingLeft + borders[3].width, //dx
      bounds.top + paddingTop + borders[0].width, // dy
      bounds.width - (borders[1].width + borders[3].width + paddingLeft + paddingRight), //dw
      bounds.height - (borders[0].width + borders[2].width + paddingTop + paddingBottom) //dh
      );
  }

  function getBorderData(element) {
    return ["Top", "Right", "Bottom", "Left"].map(function(side) {
      return {
        width: getCSSInt(element, 'border' + side + 'Width'),
        color: getCSS(element, 'border' + side + 'Color')
      };
    });
  }

  function getBorderRadiusData(element) {
    return ["TopLeft", "TopRight", "BottomRight", "BottomLeft"].map(function(side) {
      return getCSS(element, 'border' + side + 'Radius');
    });
  }

  function getCurvePoints(x, y, r1, r2) {
    var kappa = 4 * ((Math.sqrt(2) - 1) / 3);
    var ox = (r1) * kappa, // control point offset horizontal
    oy = (r2) * kappa, // control point offset vertical
    xm = x + r1, // x-middle
    ym = y + r2; // y-middle
    return {
      topLeft: bezierCurve({
        x:x,
        y:ym
      }, {
        x:x,
        y:ym - oy
      }, {
        x:xm - ox,
        y:y
      }, {
        x:xm,
        y:y
      }),
      topRight: bezierCurve({
        x:x,
        y:y
      }, {
        x:x + ox,
        y:y
      }, {
        x:xm,
        y:ym - oy
      }, {
        x:xm,
        y:ym
      }),
      bottomRight: bezierCurve({
        x:xm,
        y:y
      }, {
        x:xm,
        y:y + oy
      }, {
        x:x + ox,
        y:ym
      }, {
        x:x,
        y:ym
      }),
      bottomLeft: bezierCurve({
        x:xm,
        y:ym
      }, {
        x:xm - ox,
        y:ym
      }, {
        x:x,
        y:y + oy
      }, {
        x:x,
        y:y
      })
    };
  }

  function bezierCurve(start, startControl, endControl, end) {

    var lerp = function (a, b, t) {
      return {
        x:a.x + (b.x - a.x) * t,
        y:a.y + (b.y - a.y) * t
      };
    };

    return {
      start: start,
      startControl: startControl,
      endControl: endControl,
      end: end,
      subdivide: function(t) {
        var ab = lerp(start, startControl, t),
        bc = lerp(startControl, endControl, t),
        cd = lerp(endControl, end, t),
        abbc = lerp(ab, bc, t),
        bccd = lerp(bc, cd, t),
        dest = lerp(abbc, bccd, t);
        return [bezierCurve(start, ab, abbc, dest), bezierCurve(dest, bccd, cd, end)];
      },
      curveTo: function(borderArgs) {
        borderArgs.push(["bezierCurve", startControl.x, startControl.y, endControl.x, endControl.y, end.x, end.y]);
      },
      curveToReversed: function(borderArgs) {
        borderArgs.push(["bezierCurve", endControl.x, endControl.y, startControl.x, startControl.y, start.x, start.y]);
      }
    };
  }

  function parseCorner(borderArgs, radius1, radius2, corner1, corner2, x, y) {
    if (radius1[0] > 0 || radius1[1] > 0) {
      borderArgs.push(["line", corner1[0].start.x, corner1[0].start.y]);
      corner1[0].curveTo(borderArgs);
      corner1[1].curveTo(borderArgs);
    } else {
      borderArgs.push(["line", x, y]);
    }

    if (radius2[0] > 0 || radius2[1] > 0) {
      borderArgs.push(["line", corner2[0].start.x, corner2[0].start.y]);
    }
  }

  function drawSide(borderData, radius1, radius2, outer1, inner1, outer2, inner2) {
    var borderArgs = [];

    if (radius1[0] > 0 || radius1[1] > 0) {
      borderArgs.push(["line", outer1[1].start.x, outer1[1].start.y]);
      outer1[1].curveTo(borderArgs);
    } else {
      borderArgs.push([ "line", borderData.c1[0], borderData.c1[1]]);
    }

    if (radius2[0] > 0 || radius2[1] > 0) {
      borderArgs.push(["line", outer2[0].start.x, outer2[0].start.y]);
      outer2[0].curveTo(borderArgs);
      borderArgs.push(["line", inner2[0].end.x, inner2[0].end.y]);
      inner2[0].curveToReversed(borderArgs);
    } else {
      borderArgs.push([ "line", borderData.c2[0], borderData.c2[1]]);
      borderArgs.push([ "line", borderData.c3[0], borderData.c3[1]]);
    }

    if (radius1[0] > 0 || radius1[1] > 0) {
      borderArgs.push(["line", inner1[1].end.x, inner1[1].end.y]);
      inner1[1].curveToReversed(borderArgs);
    } else {
      borderArgs.push([ "line", borderData.c4[0], borderData.c4[1]]);
    }

    return borderArgs;
  }

  function calculateCurvePoints(bounds, borderRadius, borders) {

    var x = bounds.left,
    y = bounds.top,
    width = bounds.width,
    height = bounds.height,

    tlh = borderRadius[0][0],
    tlv = borderRadius[0][1],
    trh = borderRadius[1][0],
    trv = borderRadius[1][1],
    brh = borderRadius[2][0],
    brv = borderRadius[2][1],
    blh = borderRadius[3][0],
    blv = borderRadius[3][1],

    topWidth = width - trh,
    rightHeight = height - brv,
    bottomWidth = width - brh,
    leftHeight = height - blv;

    return {
      topLeftOuter: getCurvePoints(
        x,
        y,
        tlh,
        tlv
        ).topLeft.subdivide(0.5),

      topLeftInner: getCurvePoints(
        x + borders[3].width,
        y + borders[0].width,
        Math.max(0, tlh - borders[3].width),
        Math.max(0, tlv - borders[0].width)
        ).topLeft.subdivide(0.5),

      topRightOuter: getCurvePoints(
        x + topWidth,
        y,
        trh,
        trv
        ).topRight.subdivide(0.5),

      topRightInner: getCurvePoints(
        x + Math.min(topWidth, width + borders[3].width),
        y + borders[0].width,
        (topWidth > width + borders[3].width) ? 0 :trh - borders[3].width,
        trv - borders[0].width
        ).topRight.subdivide(0.5),

      bottomRightOuter: getCurvePoints(
        x + bottomWidth,
        y + rightHeight,
        brh,
        brv
        ).bottomRight.subdivide(0.5),

      bottomRightInner: getCurvePoints(
        x + Math.min(bottomWidth, width + borders[3].width),
        y + Math.min(rightHeight, height + borders[0].width),
        Math.max(0, brh - borders[1].width),
        Math.max(0, brv - borders[2].width)
        ).bottomRight.subdivide(0.5),

      bottomLeftOuter: getCurvePoints(
        x,
        y + leftHeight,
        blh,
        blv
        ).bottomLeft.subdivide(0.5),

      bottomLeftInner: getCurvePoints(
        x + borders[3].width,
        y + leftHeight,
        Math.max(0, blh - borders[3].width),
        Math.max(0, blv - borders[2].width)
        ).bottomLeft.subdivide(0.5)
    };
  }

  function getBorderClip(element, borderPoints, borders, radius, bounds) {
    var backgroundClip = getCSS(element, 'backgroundClip'),
    borderArgs = [];

    switch(backgroundClip) {
      case "content-box":
      case "padding-box":
        parseCorner(borderArgs, radius[0], radius[1], borderPoints.topLeftInner, borderPoints.topRightInner, bounds.left + borders[3].width, bounds.top + borders[0].width);
        parseCorner(borderArgs, radius[1], radius[2], borderPoints.topRightInner, borderPoints.bottomRightInner, bounds.left + bounds.width - borders[1].width, bounds.top + borders[0].width);
        parseCorner(borderArgs, radius[2], radius[3], borderPoints.bottomRightInner, borderPoints.bottomLeftInner, bounds.left + bounds.width - borders[1].width, bounds.top + bounds.height - borders[2].width);
        parseCorner(borderArgs, radius[3], radius[0], borderPoints.bottomLeftInner, borderPoints.topLeftInner, bounds.left + borders[3].width, bounds.top + bounds.height - borders[2].width);
        break;

      default:
        parseCorner(borderArgs, radius[0], radius[1], borderPoints.topLeftOuter, borderPoints.topRightOuter, bounds.left, bounds.top);
        parseCorner(borderArgs, radius[1], radius[2], borderPoints.topRightOuter, borderPoints.bottomRightOuter, bounds.left + bounds.width, bounds.top);
        parseCorner(borderArgs, radius[2], radius[3], borderPoints.bottomRightOuter, borderPoints.bottomLeftOuter, bounds.left + bounds.width, bounds.top + bounds.height);
        parseCorner(borderArgs, radius[3], radius[0], borderPoints.bottomLeftOuter, borderPoints.topLeftOuter, bounds.left, bounds.top + bounds.height);
        break;
    }

    return borderArgs;
  }

  function parseBorders(element, bounds, borders){
    var x = bounds.left,
    y = bounds.top,
    width = bounds.width,
    height = bounds.height,
    borderSide,
    bx,
    by,
    bw,
    bh,
    borderArgs,
    // http://www.w3.org/TR/css3-background/#the-border-radius
    borderRadius = getBorderRadiusData(element),
    borderPoints = calculateCurvePoints(bounds, borderRadius, borders),
    borderData = {
      clip: getBorderClip(element, borderPoints, borders, borderRadius, bounds),
      borders: []
    };

    for (borderSide = 0; borderSide < 4; borderSide++) {

      if (borders[borderSide].width > 0) {
        bx = x;
        by = y;
        bw = width;
        bh = height - (borders[2].width);

        switch(borderSide) {
          case 0:
            // top border
            bh = borders[0].width;

            borderArgs = drawSide({
              c1: [bx, by],
              c2: [bx + bw, by],
              c3: [bx + bw - borders[1].width, by + bh],
              c4: [bx + borders[3].width, by + bh]
            }, borderRadius[0], borderRadius[1],
            borderPoints.topLeftOuter, borderPoints.topLeftInner, borderPoints.topRightOuter, borderPoints.topRightInner);
            break;
          case 1:
            // right border
            bx = x + width - (borders[1].width);
            bw = borders[1].width;

            borderArgs = drawSide({
              c1: [bx + bw, by],
              c2: [bx + bw, by + bh + borders[2].width],
              c3: [bx, by + bh],
              c4: [bx, by + borders[0].width]
            }, borderRadius[1], borderRadius[2],
            borderPoints.topRightOuter, borderPoints.topRightInner, borderPoints.bottomRightOuter, borderPoints.bottomRightInner);
            break;
          case 2:
            // bottom border
            by = (by + height) - (borders[2].width);
            bh = borders[2].width;

            borderArgs = drawSide({
              c1: [bx + bw, by + bh],
              c2: [bx, by + bh],
              c3: [bx + borders[3].width, by],
              c4: [bx + bw - borders[3].width, by]
            }, borderRadius[2], borderRadius[3],
            borderPoints.bottomRightOuter, borderPoints.bottomRightInner, borderPoints.bottomLeftOuter, borderPoints.bottomLeftInner);
            break;
          case 3:
            // left border
            bw = borders[3].width;

            borderArgs = drawSide({
              c1: [bx, by + bh + borders[2].width],
              c2: [bx, by],
              c3: [bx + bw, by + borders[0].width],
              c4: [bx + bw, by + bh]
            }, borderRadius[3], borderRadius[0],
            borderPoints.bottomLeftOuter, borderPoints.bottomLeftInner, borderPoints.topLeftOuter, borderPoints.topLeftInner);
            break;
        }

        borderData.borders.push({
          args: borderArgs,
          color: borders[borderSide].color
        });

      }
    }

    return borderData;
  }

  function createShape(ctx, args) {
    var shape = ctx.drawShape();
    args.forEach(function(border, index) {
      shape[(index === 0) ? "moveTo" : border[0] + "To" ].apply(null, border.slice(1));
    });
    return shape;
  }

  function renderBorders(ctx, borderArgs, color) {
    if (color !== "transparent") {
      ctx.setVariable( "fillStyle", color);
      createShape(ctx, borderArgs);
      ctx.fill();
      numDraws+=1;
    }
  }

  function renderFormValue (el, bounds, stack){

    var valueWrap = doc.createElement('valuewrap'),
    cssPropertyArray = ['lineHeight','textAlign','fontFamily','color','fontSize','paddingLeft','paddingTop','width','height','border','borderLeftWidth','borderTopWidth'],
    textValue,
    textNode;

    cssPropertyArray.forEach(function(property) {
      try {
        valueWrap.style[property] = getCSS(el, property);
      } catch(e) {
        // Older IE has issues with "border"
        Util.log("html2canvas: Parse: Exception caught in renderFormValue: " + e.message);
      }
    });

    valueWrap.style.borderColor = "black";
    valueWrap.style.borderStyle = "solid";
    valueWrap.style.display = "block";
    valueWrap.style.position = "absolute";

    if (/^(submit|reset|button|text|password)$/.test(el.type) || el.nodeName === "SELECT"){
      valueWrap.style.lineHeight = getCSS(el, "height");
    }

    valueWrap.style.top = bounds.top + "px";
    valueWrap.style.left = bounds.left + "px";

    textValue = (el.nodeName === "SELECT") ? (el.options[el.selectedIndex] || 0).text : el.value;
    if(!textValue) {
      textValue = el.placeholder;
    }

    textNode = doc.createTextNode(textValue);

    valueWrap.appendChild(textNode);
    body.appendChild(valueWrap);

    renderText(el, textNode, stack);
    body.removeChild(valueWrap);
  }

  function drawImage (ctx) {
    ctx.drawImage.apply(ctx, Array.prototype.slice.call(arguments, 1));
    numDraws+=1;
  }

  function getPseudoElement(el, which) {
    var elStyle = window.getComputedStyle(el, which);
    var parentStyle = window.getComputedStyle(el);
    // If no content attribute is present, the pseudo element is hidden,
    // or the parent has a content property equal to the content on the pseudo element,
    // move along.
    if(!elStyle || !elStyle.content || elStyle.content === "none" || elStyle.content === "-moz-alt-content" ||
       elStyle.display === "none" || parentStyle.content === elStyle.content) {
      return;
    }
    var content = elStyle.content + '';

    // Strip inner quotes
    if(content[0] === "'" || content[0] === "\"") {
      content = content.replace(/(^['"])|(['"]$)/g, '');
    }

    var isImage = content.substr( 0, 3 ) === 'url',
    elps = document.createElement( isImage ? 'img' : 'span' );

    elps.className = pseudoHide + "-element ";

    Object.keys(elStyle).filter(indexedProperty).forEach(function(prop) {
      // Prevent assigning of read only CSS Rules, ex. length, parentRule
      try {
        elps.style[prop] = elStyle[prop];
      } catch (e) {
        Util.log(['Tried to assign readonly property ', prop, 'Error:', e]);
      }
    });

    if(isImage) {
      elps.src = Util.parseBackgroundImage(content)[0].args[0];
    } else {
      elps.innerHTML = content;
    }
    return elps;
  }

  function indexedProperty(property) {
    return (isNaN(window.parseInt(property, 10)));
  }

  function renderBackgroundRepeat(ctx, image, backgroundPosition, bounds) {
    var offsetX = Math.round(bounds.left + backgroundPosition.left),
    offsetY = Math.round(bounds.top + backgroundPosition.top);

    ctx.createPattern(image);
    ctx.translate(offsetX, offsetY);
    ctx.fill();
    ctx.translate(-offsetX, -offsetY);
  }

  function backgroundRepeatShape(ctx, image, backgroundPosition, bounds, left, top, width, height) {
    var args = [];
    args.push(["line", Math.round(left), Math.round(top)]);
    args.push(["line", Math.round(left + width), Math.round(top)]);
    args.push(["line", Math.round(left + width), Math.round(height + top)]);
    args.push(["line", Math.round(left), Math.round(height + top)]);
    createShape(ctx, args);
    ctx.save();
    ctx.clip();
    renderBackgroundRepeat(ctx, image, backgroundPosition, bounds);
    ctx.restore();
  }

  function renderBackgroundColor(ctx, backgroundBounds, bgcolor) {
    renderRect(
      ctx,
      backgroundBounds.left,
      backgroundBounds.top,
      backgroundBounds.width,
      backgroundBounds.height,
      bgcolor
      );
  }

  function renderBackgroundRepeating(el, bounds, ctx, image, imageIndex) {
    var backgroundSize = Util.BackgroundSize(el, bounds, image, imageIndex),
    backgroundPosition = Util.BackgroundPosition(el, bounds, image, imageIndex, backgroundSize),
    backgroundRepeat = Util.BackgroundRepeat(el, imageIndex);

    image = resizeImage(image, backgroundSize);

    switch (backgroundRepeat) {
      case "repeat-x":
      case "repeat no-repeat":
        backgroundRepeatShape(ctx, image, backgroundPosition, bounds,
          bounds.left, bounds.top + backgroundPosition.top, 99999, image.height);
        break;
      case "repeat-y":
      case "no-repeat repeat":
        backgroundRepeatShape(ctx, image, backgroundPosition, bounds,
          bounds.left + backgroundPosition.left, bounds.top, image.width, 99999);
        break;
      case "no-repeat":
        backgroundRepeatShape(ctx, image, backgroundPosition, bounds,
          bounds.left + backgroundPosition.left, bounds.top + backgroundPosition.top, image.width, image.height);
        break;
      default:
        renderBackgroundRepeat(ctx, image, backgroundPosition, {
          top: bounds.top,
          left: bounds.left,
          width: image.width,
          height: image.height
        });
        break;
    }
  }

  function renderBackgroundImage(element, bounds, ctx) {
    var backgroundImage = getCSS(element, "backgroundImage"),
    backgroundImages = Util.parseBackgroundImage(backgroundImage),
    image,
    imageIndex = backgroundImages.length;

    while(imageIndex--) {
      backgroundImage = backgroundImages[imageIndex];

      if (!backgroundImage.args || backgroundImage.args.length === 0) {
        continue;
      }

      var key = backgroundImage.method === 'url' ?
      backgroundImage.args[0] :
      backgroundImage.value;

      image = loadImage(key);

      // TODO add support for background-origin
      if (image) {
        renderBackgroundRepeating(element, bounds, ctx, image, imageIndex);
      } else {
        Util.log("html2canvas: Error loading background:", backgroundImage);
      }
    }
  }

  function resizeImage(image, bounds) {
    if(image.width === bounds.width && image.height === bounds.height) {
      return image;
    }

    var ctx, canvas = doc.createElement('canvas');
    canvas.width = bounds.width;
    canvas.height = bounds.height;
    ctx = canvas.getContext("2d");
    drawImage(ctx, image, 0, 0, image.width, image.height, 0, 0, bounds.width, bounds.height );
    return canvas;
  }

  function setOpacity(ctx, element, parentStack) {
    return ctx.setVariable("globalAlpha", getCSS(element, "opacity") * ((parentStack) ? parentStack.opacity : 1));
  }

  function removePx(str) {
    return str.replace("px", "");
  }

  function getTransform(element, parentStack) {
    var transformRegExp = /(matrix)\((.+)\)/;
    var transform = getCSS(element, "transform") || getCSS(element, "-webkit-transform") || getCSS(element, "-moz-transform") || getCSS(element, "-ms-transform") || getCSS(element, "-o-transform");
    var transformOrigin = getCSS(element, "transform-origin") || getCSS(element, "-webkit-transform-origin") || getCSS(element, "-moz-transform-origin") || getCSS(element, "-ms-transform-origin") || getCSS(element, "-o-transform-origin") || "0px 0px";

    transformOrigin = transformOrigin.split(" ").map(removePx).map(Util.asFloat);

    var matrix;
    if (transform && transform !== "none") {
      var match = transform.match(transformRegExp);
      if (match) {
        switch(match[1]) {
          case "matrix":
            matrix = match[2].split(",").map(Util.trimText).map(Util.asFloat);
            break;
        }
      }
    }

    return {
      origin: transformOrigin,
      matrix: matrix
    };
  }

  function createStack(element, parentStack, bounds, transform) {
    var ctx = h2cRenderContext((!parentStack) ? documentWidth() : bounds.width , (!parentStack) ? documentHeight() : bounds.height),
    stack = {
      ctx: ctx,
      opacity: setOpacity(ctx, element, parentStack),
      cssPosition: getCSS(element, "position"),
      borders: getBorderData(element),
      transform: transform,
      clip: (parentStack && parentStack.clip) ? Util.Extend( {}, parentStack.clip ) : null
    };

    setZ(element, stack, parentStack);

    // TODO correct overflow for absolute content residing under a static position
    if (options.useOverflow === true && /(hidden|scroll|auto)/.test(getCSS(element, "overflow")) === true && /(BODY)/i.test(element.nodeName) === false){
      stack.clip = (stack.clip) ? clipBounds(stack.clip, bounds) : bounds;
    }

    return stack;
  }

  function getBackgroundBounds(borders, bounds, clip) {
    var backgroundBounds = {
      left: bounds.left + borders[3].width,
      top: bounds.top + borders[0].width,
      width: bounds.width - (borders[1].width + borders[3].width),
      height: bounds.height - (borders[0].width + borders[2].width)
    };

    if (clip) {
      backgroundBounds = clipBounds(backgroundBounds, clip);
    }

    return backgroundBounds;
  }

  function getBounds(element, transform) {
    var bounds = (transform.matrix) ? Util.OffsetBounds(element) : Util.Bounds(element);
    transform.origin[0] += bounds.left;
    transform.origin[1] += bounds.top;
    return bounds;
  }

  function renderElement(element, parentStack, ignoreBackground) {
    var transform = getTransform(element, parentStack),
    bounds = getBounds(element, transform),
    image,
    stack = createStack(element, parentStack, bounds, transform),
    borders = stack.borders,
    ctx = stack.ctx,
    backgroundBounds = getBackgroundBounds(borders, bounds, stack.clip),
    borderData = parseBorders(element, bounds, borders),
    backgroundColor = (ignoreElementsRegExp.test(element.nodeName)) ? "#efefef" : getCSS(element, "backgroundColor");


    createShape(ctx, borderData.clip);

    ctx.save();
    ctx.clip();

    if (backgroundBounds.height > 0 && backgroundBounds.width > 0 && !ignoreBackground) {
      renderBackgroundColor(ctx, bounds, backgroundColor);
      renderBackgroundImage(element, backgroundBounds, ctx);
    } else if (ignoreBackground) {
      stack.backgroundColor =  backgroundColor;
    }

    ctx.restore();

    borderData.borders.forEach(function(border) {
      renderBorders(ctx, border.args, border.color);
    });

    switch(element.nodeName){
      case "IMG":
        if ((image = loadImage(element.getAttribute('src')))) {
          renderImage(ctx, element, image, bounds, borders);
        } else {
          Util.log("html2canvas: Error loading <img>:" + element.getAttribute('src'));
        }
        break;
      case "INPUT":
        // TODO add all relevant type's, i.e. HTML5 new stuff
        // todo add support for placeholder attribute for browsers which support it
        if (/^(text|url|email|submit|button|reset)$/.test(element.type) && (element.value || element.placeholder || "").length > 0){
          renderFormValue(element, bounds, stack);
        }
        break;
      case "TEXTAREA":
        if ((element.value || element.placeholder || "").length > 0){
          renderFormValue(element, bounds, stack);
        }
        break;
      case "SELECT":
        if ((element.options||element.placeholder || "").length > 0){
          renderFormValue(element, bounds, stack);
        }
        break;
      case "LI":
        renderListItem(element, stack, backgroundBounds);
        break;
      case "CANVAS":
        renderImage(ctx, element, element, bounds, borders);
        break;
    }

    return stack;
  }

  function isElementVisible(element) {
    return (getCSS(element, 'display') !== "none" && getCSS(element, 'visibility') !== "hidden" && !element.hasAttribute("data-html2canvas-ignore"));
  }

  function parseElement (element, stack, cb) {
    if (!cb) {
      cb = function(){};
    }
    if (isElementVisible(element)) {
      stack = renderElement(element, stack, false) || stack;
      if (!ignoreElementsRegExp.test(element.nodeName)) {
        return parseChildren(element, stack, cb);
      }
    }
    cb();
  }

  function parseChildren(element, stack, cb) {
    var children = Util.Children(element);
    // After all nodes have processed, finished() will call the cb.
    // We add one and kick it off so this will still work when children.length === 0.
    // Note that unless async is true, this will happen synchronously, just will callbacks.
    var jobs = children.length + 1;
    finished();

    if (options.async) {
      children.forEach(function(node) {
        // Don't block the page from rendering
        setTimeout(function(){ parseNode(node); }, 0);
      });
    } else {
      children.forEach(parseNode);
    }

    function parseNode(node) {
      if (node.nodeType === node.ELEMENT_NODE) {
        parseElement(node, stack, finished);
      } else if (node.nodeType === node.TEXT_NODE) {
        renderText(element, node, stack);
        finished();
      } else {
        finished();
      }
    }
    function finished(el) {
      if (--jobs <= 0){
        Util.log("finished rendering " + children.length + " children.");
        cb();
      }
    }
  }
};
_html2canvas.Preload = function( options ) {

  var images = {
    numLoaded: 0,   // also failed are counted here
    numFailed: 0,
    numTotal: 0,
    cleanupDone: false
  },
  pageOrigin,
  Util = _html2canvas.Util,
  methods,
  i,
  count = 0,
  element = options.elements[0] || document.body,
  doc = element.ownerDocument,
  domImages = element.getElementsByTagName('img'), // Fetch images of the present element only
  imgLen = domImages.length,
  link = doc.createElement("a"),
  supportCORS = (function( img ){
    return (img.crossOrigin !== undefined);
  })(new Image()),
  timeoutTimer;

  link.href = window.location.href;
  pageOrigin  = link.protocol + link.host;

  function isSameOrigin(url){
    link.href = url;
    link.href = link.href; // YES, BELIEVE IT OR NOT, that is required for IE9 - http://jsfiddle.net/niklasvh/2e48b/
    var origin = link.protocol + link.host;
    return (origin === pageOrigin);
  }

  function start(){
    Util.log("html2canvas: start: images: " + images.numLoaded + " / " + images.numTotal + " (failed: " + images.numFailed + ")");
    if (!images.firstRun && images.numLoaded >= images.numTotal){
      Util.log("Finished loading images: # " + images.numTotal + " (failed: " + images.numFailed + ")");

      if (typeof options.complete === "function"){
        options.complete(images);
      }

    }
  }

  // TODO modify proxy to serve images with CORS enabled, where available
  function proxyGetImage(url, img, imageObj){
    var callback_name,
    scriptUrl = options.proxy,
    script;

    link.href = url;
    url = link.href; // work around for pages with base href="" set - WARNING: this may change the url

    callback_name = 'html2canvas_' + (count++);
    imageObj.callbackname = callback_name;

    if (scriptUrl.indexOf("?") > -1) {
      scriptUrl += "&";
    } else {
      scriptUrl += "?";
    }
    scriptUrl += 'url=' + encodeURIComponent(url) + '&callback=' + callback_name;
    script = doc.createElement("script");

    window[callback_name] = function(a){
      if (a.substring(0,6) === "error:"){
        imageObj.succeeded = false;
        images.numLoaded++;
        images.numFailed++;
        start();
      } else {
        setImageLoadHandlers(img, imageObj);
        img.src = a;
      }
      window[callback_name] = undefined; // to work with IE<9  // NOTE: that the undefined callback property-name still exists on the window object (for IE<9)
      try {
        delete window[callback_name];  // for all browser that support this
      } catch(ex) {}
      script.parentNode.removeChild(script);
      script = null;
      delete imageObj.script;
      delete imageObj.callbackname;
    };

    script.setAttribute("type", "text/javascript");
    script.setAttribute("src", scriptUrl);
    imageObj.script = script;
    window.document.body.appendChild(script);

  }

  function loadPseudoElement(element, type) {
    var style = window.getComputedStyle(element, type),
    content = style.content;
    if (content.substr(0, 3) === 'url') {
      methods.loadImage(_html2canvas.Util.parseBackgroundImage(content)[0].args[0]);
    }
    loadBackgroundImages(style.backgroundImage, element);
  }

  function loadPseudoElementImages(element) {
    loadPseudoElement(element, ":before");
    loadPseudoElement(element, ":after");
  }

  function loadGradientImage(backgroundImage, bounds) {
    var img = _html2canvas.Generate.Gradient(backgroundImage, bounds);

    if (img !== undefined){
      images[backgroundImage] = {
        img: img,
        succeeded: true
      };
      images.numTotal++;
      images.numLoaded++;
      start();
    }
  }

  function invalidBackgrounds(background_image) {
    return (background_image && background_image.method && background_image.args && background_image.args.length > 0 );
  }

  function loadBackgroundImages(background_image, el) {
    var bounds;

    _html2canvas.Util.parseBackgroundImage(background_image).filter(invalidBackgrounds).forEach(function(background_image) {
      if (background_image.method === 'url') {
        methods.loadImage(background_image.args[0]);
      } else if(background_image.method.match(/\-?gradient$/)) {
        if(bounds === undefined) {
          bounds = _html2canvas.Util.Bounds(el);
        }
        loadGradientImage(background_image.value, bounds);
      }
    });
  }

  function getImages (el) {
    var elNodeType = false;

    // Firefox fails with permission denied on pages with iframes
    try {
      Util.Children(el).forEach(getImages);
    }
    catch( e ) {}

    try {
      elNodeType = el.nodeType;
    } catch (ex) {
      elNodeType = false;
      Util.log("html2canvas: failed to access some element's nodeType - Exception: " + ex.message);
    }

    if (elNodeType === 1 || elNodeType === undefined) {
      loadPseudoElementImages(el);
      try {
        loadBackgroundImages(Util.getCSS(el, 'backgroundImage'), el);
      } catch(e) {
        Util.log("html2canvas: failed to get background-image - Exception: " + e.message);
      }
      loadBackgroundImages(el);
    }
  }

  function setImageLoadHandlers(img, imageObj) {
    img.onload = function() {
      if ( imageObj.timer !== undefined ) {
        // CORS succeeded
        window.clearTimeout( imageObj.timer );
      }

      images.numLoaded++;
      imageObj.succeeded = true;
      img.onerror = img.onload = null;
      start();
    };
    img.onerror = function() {
      if (img.crossOrigin === "anonymous") {
        // CORS failed
        window.clearTimeout( imageObj.timer );

        // let's try with proxy instead
        if ( options.proxy ) {
          var src = img.src;
          img = new Image();
          imageObj.img = img;
          img.src = src;

          proxyGetImage( img.src, img, imageObj );
          return;
        }
      }

      images.numLoaded++;
      images.numFailed++;
      imageObj.succeeded = false;
      img.onerror = img.onload = null;
      start();
    };
  }

  methods = {
    loadImage: function( src ) {
      var img, imageObj;
      if ( src && images[src] === undefined ) {
        img = new Image();
        if ( src.match(/data:image\/.*;base64,/i) ) {
          img.src = src.replace(/url\(['"]{0,}|['"]{0,}\)$/ig, '');
          imageObj = images[src] = {
            img: img
          };
          images.numTotal++;
          setImageLoadHandlers(img, imageObj);
        } else if ( isSameOrigin( src ) || options.allowTaint ===  true ) {
          imageObj = images[src] = {
            img: img
          };
          images.numTotal++;
          setImageLoadHandlers(img, imageObj);
          img.src = src;
        } else if ( supportCORS && !options.allowTaint && options.useCORS ) {
          // attempt to load with CORS

          img.crossOrigin = "anonymous";
          imageObj = images[src] = {
            img: img
          };
          images.numTotal++;
          setImageLoadHandlers(img, imageObj);
          img.src = src;
        } else if ( options.proxy ) {
          imageObj = images[src] = {
            img: img
          };
          images.numTotal++;
          proxyGetImage( src, img, imageObj );
        }
      }

    },
    cleanupDOM: function(cause) {
      var img, src;
      if (!images.cleanupDone) {
        if (cause && typeof cause === "string") {
          Util.log("html2canvas: Cleanup because: " + cause);
        } else {
          Util.log("html2canvas: Cleanup after timeout: " + options.timeout + " ms.");
        }

        for (src in images) {
          if (images.hasOwnProperty(src)) {
            img = images[src];
            if (typeof img === "object" && img.callbackname && img.succeeded === undefined) {
              // cancel proxy image request
              window[img.callbackname] = undefined; // to work with IE<9  // NOTE: that the undefined callback property-name still exists on the window object (for IE<9)
              try {
                delete window[img.callbackname];  // for all browser that support this
              } catch(ex) {}
              if (img.script && img.script.parentNode) {
                img.script.setAttribute("src", "about:blank");  // try to cancel running request
                img.script.parentNode.removeChild(img.script);
              }
              images.numLoaded++;
              images.numFailed++;
              Util.log("html2canvas: Cleaned up failed img: '" + src + "' Steps: " + images.numLoaded + " / " + images.numTotal);
            }
          }
        }

        // cancel any pending requests
        if(window.stop !== undefined) {
          window.stop();
        } else if(document.execCommand !== undefined) {
          document.execCommand("Stop", false);
        }
        if (document.close !== undefined) {
          document.close();
        }
        images.cleanupDone = true;
        if (!(cause && typeof cause === "string")) {
          start();
        }
      }
    },

    renderingDone: function() {
      if (timeoutTimer) {
        window.clearTimeout(timeoutTimer);
      }
    }
  };

  if (options.timeout > 0) {
    timeoutTimer = window.setTimeout(methods.cleanupDOM, options.timeout);
  }

  Util.log('html2canvas: Preload starts: finding background-images');
  images.firstRun = true;

  getImages(element);

  Util.log('html2canvas: Preload: Finding images');
  // load <img> images
  for (i = 0; i < imgLen; i+=1){
    methods.loadImage( domImages[i].getAttribute( "src" ) );
  }

  images.firstRun = false;
  Util.log('html2canvas: Preload: Done.');
  if (images.numTotal === images.numLoaded) {
    start();
  }

  return methods;
};

_html2canvas.Renderer = function(parseQueue, options){
  function sortZindex(a, b) {
    if (a === 'children') {
      return -1;
    } else if (b === 'children') {
      return 1;
    } else {
      return a - b;
    }
  }

  // http://www.w3.org/TR/CSS21/zindex.html
  function createRenderQueue(parseQueue) {
    var queue = [],
    rootContext;

    rootContext = (function buildStackingContext(rootNode) {
      var rootContext = {};
      function insert(context, node, specialParent) {
        var zi = (node.zIndex.zindex === 'auto') ? 0 : Number(node.zIndex.zindex),
        contextForChildren = context, // the stacking context for children
        isPositioned = node.zIndex.isPositioned,
        isFloated = node.zIndex.isFloated,
        stub = {node: node},
        childrenDest = specialParent; // where children without z-index should be pushed into

        if (node.zIndex.ownStacking) {
          contextForChildren = stub.context = {
              children: [{node:node, children: []}]
          };
          childrenDest = undefined;
        } else if (isPositioned || isFloated) {
          childrenDest = stub.children = [];
        }

        if (zi === 0 && specialParent) {
          specialParent.push(stub);
        } else {
          if (!context[zi]) { context[zi] = []; }
          context[zi].push(stub);
        }

        node.zIndex.children.forEach(function(childNode) {
          insert(contextForChildren, childNode, childrenDest);
        });
      }
      insert(rootContext, rootNode);
      return rootContext;
    })(parseQueue);

    function sortZ(context) {
      Object.keys(context).sort(sortZindex).forEach(function(zi) {
        var nonPositioned = [],
        floated = [],
        positioned = [],
        list = [];

        // positioned after static
        context[zi].forEach(function(v) {
          if (v.node.zIndex.isPositioned || v.node.zIndex.opacity < 1) {
            // http://www.w3.org/TR/css3-color/#transparency
            // non-positioned element with opactiy < 1 should be stacked as if it were a positioned element with ‘z-index: 0’ and ‘opacity: 1’.
            positioned.push(v);
          } else if (v.node.zIndex.isFloated) {
            floated.push(v);
          } else {
            nonPositioned.push(v);
          }
        });

        (function walk(arr) {
          arr.forEach(function(v) {
            list.push(v);
            if (v.children) { walk(v.children); }
          });
        })(nonPositioned.concat(floated, positioned));

        list.forEach(function(v) {
          if (v.context) {
            sortZ(v.context);
          } else {
            queue.push(v.node);
          }
        });
      });
    }

    sortZ(rootContext);

    return queue;
  }

  function getRenderer(rendererName) {
    var renderer;

    if (typeof options.renderer === "string" && _html2canvas.Renderer[rendererName] !== undefined) {
      renderer = _html2canvas.Renderer[rendererName](options);
    } else if (typeof rendererName === "function") {
      renderer = rendererName(options);
    } else {
      throw new Error("Unknown renderer");
    }

    if ( typeof renderer !== "function" ) {
      throw new Error("Invalid renderer defined");
    }
    return renderer;
  }

  return getRenderer(options.renderer)(parseQueue, options, document, createRenderQueue(parseQueue.stack), _html2canvas);
};

_html2canvas.Util.Support = function (options, doc) {

  function supportSVGRendering() {
    var img = new Image(),
    canvas = doc.createElement("canvas"),
    ctx = (canvas.getContext === undefined) ? false : canvas.getContext("2d");
    if (ctx === false) {
      return false;
    }
    canvas.width = canvas.height = 10;
    img.src = [
    "data:image/svg+xml,",
    "<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10'>",
    "<foreignObject width='10' height='10'>",
    "<div xmlns='http://www.w3.org/1999/xhtml' style='width:10;height:10;'>",
    "sup",
    "</div>",
    "</foreignObject>",
    "</svg>"
    ].join("");
    try {
      ctx.drawImage(img, 0, 0);
      canvas.toDataURL();
    } catch(e) {
      return false;
    }
    _html2canvas.Util.log('html2canvas: Parse: SVG powered rendering available');
    return true;
  }

  // Test whether we can use ranges to measure bounding boxes
  // Opera doesn't provide valid bounds.height/bottom even though it supports the method.

  function supportRangeBounds() {
    var r, testElement, rangeBounds, rangeHeight, support = false;

    if (doc.createRange) {
      r = doc.createRange();
      if (r.getBoundingClientRect) {
        testElement = doc.createElement('boundtest');
        testElement.style.height = "123px";
        testElement.style.display = "block";
        doc.body.appendChild(testElement);

        r.selectNode(testElement);
        rangeBounds = r.getBoundingClientRect();
        rangeHeight = rangeBounds.height;

        if (rangeHeight === 123) {
          support = true;
        }
        doc.body.removeChild(testElement);
      }
    }

    return support;
  }

  return {
    rangeBounds: supportRangeBounds(),
    svgRendering: options.svgRendering && supportSVGRendering()
  };
};
window.html2canvas = function(elements, opts) {
  elements = (elements.length) ? elements : [elements];
  var queue,
  canvas,
  options = {
    // general
    logging: false,
    elements: elements,
    background: "#fff",

    // preload options
    proxy: null,
    timeout: 0,    // no timeout
    useCORS: false, // try to load images as CORS (where available), before falling back to proxy
    allowTaint: false, // whether to allow images to taint the canvas, won't need proxy if set to true

    // parse options
    svgRendering: false, // use svg powered rendering where available (FF11+)
    ignoreElements: "IFRAME|OBJECT|PARAM",
    useOverflow: true,
    letterRendering: false,
    chinese: false,
    async: false, // If true, parsing will not block, but if the user scrolls during parse the image can get weird

    // render options
    width: null,
    height: null,
    taintTest: true, // do a taint test with all images before applying to canvas
    renderer: "Canvas"
  };

  options = _html2canvas.Util.Extend(opts, options);

  _html2canvas.logging = options.logging;
  options.complete = function( images ) {

    if (typeof options.onpreloaded === "function") {
      if ( options.onpreloaded( images ) === false ) {
        return;
      }
    }
    _html2canvas.Parse( images, options, function(queue) {
      if (typeof options.onparsed === "function") {
        if ( options.onparsed( queue ) === false ) {
          return;
        }
      }

      canvas = _html2canvas.Renderer( queue, options );

      if (typeof options.onrendered === "function") {
        options.onrendered( canvas );
      }
    });
  };

  // for pages without images, we still want this to be async, i.e. return methods before executing
  window.setTimeout( function(){
    _html2canvas.Preload( options );
  }, 0 );

  return {
    render: function( queue, opts ) {
      return _html2canvas.Renderer( queue, _html2canvas.Util.Extend(opts, options) );
    },
    parse: function( images, opts ) {
      return _html2canvas.Parse( images, _html2canvas.Util.Extend(opts, options) );
    },
    preload: function( opts ) {
      return _html2canvas.Preload( _html2canvas.Util.Extend(opts, options) );
    },
    log: _html2canvas.Util.log
  };
};

window.html2canvas.log = _html2canvas.Util.log; // for renderers
window.html2canvas.Renderer = {
  Canvas: undefined // We are assuming this will be used
};
_html2canvas.Renderer.Canvas = function(options) {
  options = options || {};

  var doc = document,
  safeImages = [],
  testCanvas = document.createElement("canvas"),
  testctx = testCanvas.getContext("2d"),
  Util = _html2canvas.Util,
  canvas = options.canvas || doc.createElement('canvas');

  function createShape(ctx, args) {
    ctx.beginPath();
    args.forEach(function(arg) {
      ctx[arg.name].apply(ctx, arg['arguments']);
    });
    ctx.closePath();
  }

  function safeImage(item) {
    if (safeImages.indexOf(item['arguments'][0].src) === -1) {
      testctx.drawImage(item['arguments'][0], 0, 0);
      try {
        testctx.getImageData(0, 0, 1, 1);
      } catch(e) {
        testCanvas = doc.createElement("canvas");
        testctx = testCanvas.getContext("2d");
        return false;
      }
      safeImages.push(item['arguments'][0].src);
    }
    return true;
  }

  function renderItem(ctx, item) {
    switch(item.type){
      case "variable":
        ctx[item.name] = item['arguments'];
        break;
      case "function":
        switch(item.name) {
          case "createPattern":
            if (item['arguments'][0].width > 0 && item['arguments'][0].height > 0) {
              try {
                ctx.fillStyle = ctx.createPattern(item['arguments'][0], "repeat");
              } catch(e) {
                Util.log("html2canvas: Renderer: Error creating pattern", e.message);
              }
            }
            break;
          case "drawShape":
            createShape(ctx, item['arguments']);
            break;
          case "drawImage":
            if (item['arguments'][8] > 0 && item['arguments'][7] > 0) {
              if (!options.taintTest || (options.taintTest && safeImage(item))) {
                ctx.drawImage.apply( ctx, item['arguments'] );
              }
            }
            break;
          default:
            ctx[item.name].apply(ctx, item['arguments']);
        }
        break;
    }
  }

  return function(parsedData, options, document, queue, _html2canvas) {
    var ctx = canvas.getContext("2d"),
    newCanvas,
    bounds,
    fstyle,
    zStack = parsedData.stack;

    canvas.width = canvas.style.width =  options.width || zStack.ctx.width;
    canvas.height = canvas.style.height = options.height || zStack.ctx.height;

    fstyle = ctx.fillStyle;
    ctx.fillStyle = (Util.isTransparent(parsedData.backgroundColor) && options.background !== undefined) ? options.background : parsedData.backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = fstyle;
    queue.forEach(function(storageContext) {
      // set common settings for canvas
      ctx.textBaseline = "bottom";
      ctx.save();

      if (storageContext.transform.matrix) {
        ctx.translate(storageContext.transform.origin[0], storageContext.transform.origin[1]);
        ctx.transform.apply(ctx, storageContext.transform.matrix);
        ctx.translate(-storageContext.transform.origin[0], -storageContext.transform.origin[1]);
      }

      if (storageContext.clip){
        ctx.beginPath();
        ctx.rect(storageContext.clip.left, storageContext.clip.top, storageContext.clip.width, storageContext.clip.height);
        ctx.clip();
      }

      if (storageContext.ctx.storage) {
        storageContext.ctx.storage.forEach(function(item) {
          renderItem(ctx, item);
        });
      }

      ctx.restore();
    });

    Util.log("html2canvas: Renderer: Canvas renderer done - returning canvas obj");

    if (options.elements.length === 1) {
      if (typeof options.elements[0] === "object" && options.elements[0].nodeName !== "BODY") {
        // crop image to the bounds of selected (single) element
        bounds = _html2canvas.Util.Bounds(options.elements[0]);
        newCanvas = document.createElement('canvas');
        

	    newCanvas.width = Math.ceil(bounds.width);
        newCanvas.height = Math.ceil(bounds.height);
   
	  ctx = newCanvas.getContext("2d");
      ctx.drawImage(canvas, bounds.left, bounds.top, bounds.width, bounds.height, 0, 0, bounds.width, bounds.height);

		
		
		canvas = null;
        return newCanvas;
      }
    }

    return canvas;
  };
};
})(window,document);

},{}],8:[function(require,module,exports){
/*jslint adsafe: false, bitwise: true, browser: true, cap: false, css: false,
  debug: false, devel: true, eqeqeq: true, es5: false, evil: false,
  forin: false, fragment: false, immed: true, laxbreak: false, newcap: true,
  nomen: false, on: false, onevar: true, passfail: false, plusplus: true,
  regexp: false, rhino: true, safe: false, strict: false, sub: false,
  undef: true, white: false, widget: false, windows: false */
/*global jQuery: false, window: false */
//"use strict";

/*
 * Original code (c) 2010 Nick Galbreath
 * http://code.google.com/p/stringencoders/source/browse/#svn/trunk/javascript
 *
 * jQuery port (c) 2010 Carlo Zottmann
 * http://github.com/carlo/jquery-base64
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
*/

/* base64 encode/decode compatible with window.btoa/atob
 *
 * window.atob/btoa is a Firefox extension to convert binary data (the "b")
 * to base64 (ascii, the "a").
 *
 * It is also found in Safari and Chrome.  It is not available in IE.
 *
 * if (!window.btoa) window.btoa = $.base64.encode
 * if (!window.atob) window.atob = $.base64.decode
 *
 * The original spec's for atob/btoa are a bit lacking
 * https://developer.mozilla.org/en/DOM/window.atob
 * https://developer.mozilla.org/en/DOM/window.btoa
 *
 * window.btoa and $.base64.encode takes a string where charCodeAt is [0,255]
 * If any character is not [0,255], then an exception is thrown.
 *
 * window.atob and $.base64.decode take a base64-encoded string
 * If the input length is not a multiple of 4, or contains invalid characters
 *   then an exception is thrown.
 */
 
jQuery.base64 = ( function( $ ) {
  
  var _PADCHAR = "=",
    _ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
    _VERSION = "1.0";


  function _getbyte64( s, i ) {
    // This is oddly fast, except on Chrome/V8.
    // Minimal or no improvement in performance by using a
    // object with properties mapping chars to value (eg. 'A': 0)

    var idx = _ALPHA.indexOf( s.charAt( i ) );

    if ( idx === -1 ) {
      throw "Cannot decode base64";
    }

    return idx;
  }
  
  
  function _decode( s ) {
    var pads = 0,
      i,
      b10,
      imax = s.length,
      x = [];

    s = String( s );
    
    if ( imax === 0 ) {
      return s;
    }

    if ( imax % 4 !== 0 ) {
      throw "Cannot decode base64";
    }

    if ( s.charAt( imax - 1 ) === _PADCHAR ) {
      pads = 1;

      if ( s.charAt( imax - 2 ) === _PADCHAR ) {
        pads = 2;
      }

      // either way, we want to ignore this last block
      imax -= 4;
    }

    for ( i = 0; i < imax; i += 4 ) {
      b10 = ( _getbyte64( s, i ) << 18 ) | ( _getbyte64( s, i + 1 ) << 12 ) | ( _getbyte64( s, i + 2 ) << 6 ) | _getbyte64( s, i + 3 );
      x.push( String.fromCharCode( b10 >> 16, ( b10 >> 8 ) & 0xff, b10 & 0xff ) );
    }

    switch ( pads ) {
      case 1:
        b10 = ( _getbyte64( s, i ) << 18 ) | ( _getbyte64( s, i + 1 ) << 12 ) | ( _getbyte64( s, i + 2 ) << 6 );
        x.push( String.fromCharCode( b10 >> 16, ( b10 >> 8 ) & 0xff ) );
        break;

      case 2:
        b10 = ( _getbyte64( s, i ) << 18) | ( _getbyte64( s, i + 1 ) << 12 );
        x.push( String.fromCharCode( b10 >> 16 ) );
        break;
    }

    return x.join( "" );
  }
  
  
  function _getbyte( s, i ) {
    var x = s.charCodeAt( i );

    if ( x > 255 ) {
      throw "INVALID_CHARACTER_ERR: DOM Exception 5";
    }
    
    return x;
  }


  function _encode( s ) {
    if ( arguments.length !== 1 ) {
      throw "SyntaxError: exactly one argument required";
    }

    s = String( s );

    var i,
      b10,
      x = [],
      imax = s.length - s.length % 3;

    if ( s.length === 0 ) {
      return s;
    }

    for ( i = 0; i < imax; i += 3 ) {
      b10 = ( _getbyte( s, i ) << 16 ) | ( _getbyte( s, i + 1 ) << 8 ) | _getbyte( s, i + 2 );
      x.push( _ALPHA.charAt( b10 >> 18 ) );
      x.push( _ALPHA.charAt( ( b10 >> 12 ) & 0x3F ) );
      x.push( _ALPHA.charAt( ( b10 >> 6 ) & 0x3f ) );
      x.push( _ALPHA.charAt( b10 & 0x3f ) );
    }

    switch ( s.length - imax ) {
      case 1:
        b10 = _getbyte( s, i ) << 16;
        x.push( _ALPHA.charAt( b10 >> 18 ) + _ALPHA.charAt( ( b10 >> 12 ) & 0x3F ) + _PADCHAR + _PADCHAR );
        break;

      case 2:
        b10 = ( _getbyte( s, i ) << 16 ) | ( _getbyte( s, i + 1 ) << 8 );
        x.push( _ALPHA.charAt( b10 >> 18 ) + _ALPHA.charAt( ( b10 >> 12 ) & 0x3F ) + _ALPHA.charAt( ( b10 >> 6 ) & 0x3f ) + _PADCHAR );
        break;
    }

    return x.join( "" );
  }


  return {
    decode: _decode,
    encode: _encode,
    VERSION: _VERSION
  };
      
}( jQuery ) );


},{}],9:[function(require,module,exports){
/**
 * jsPDF
 * (c) 2009 James Hall
 * 
 * Some parts based on FPDF.
 */

var jsPDF = function(){
	
	// Private properties
	var version = '20090504';
	var buffer = '';
	
	var pdfVersion = '1.3'; // PDF Version
	var defaultPageFormat = 'a4';
	var pageFormats = { // Size in mm of various paper formats
		'a3': [841.89, 1190.55],
		'a4': [595.28, 841.89],
		'a5': [420.94, 595.28],
		'letter': [612, 792],
		'legal': [612, 1008]
	};
	var textColor = '0 g';
	var page = 0;
	var objectNumber = 2; // 'n' Current object number
	var state = 0; // Current document state
	var pages = new Array();
	var offsets = new Array(); // List of offsets
	var lineWidth = 0.200025; // 2mm
	var pageHeight;
	var k; // Scale factor
	var unit = 'mm'; // Default to mm for units
	var fontNumber; // TODO: This is temp, replace with real font handling
	var documentProperties = {};
	var fontSize = 16; // Default font size
	var pageFontSize = 16;

	// Initilisation 
	if (unit == 'pt') {
		k = 1;
	} else if(unit == 'mm') {
		k = 72/25.4;
	} else if(unit == 'cm') {
		k = 72/2.54;
	} else if(unit == 'in') {
		k = 72;
	}
	
	// Private functions
	var newObject = function() {
		//Begin a new object
		objectNumber ++;
		offsets[objectNumber] = buffer.length;
		out(objectNumber + ' 0 obj');		
	}
	
	
	var putHeader = function() {
		out('%PDF-' + pdfVersion);
	}
	
	var putPages = function() {
		
		// TODO: Fix, hardcoded to a4 portrait
		var wPt = pageWidth * k;
		var hPt = pageHeight * k;

		for(n=1; n <= page; n++) {
			newObject();
			out('<</Type /Page');
			out('/Parent 1 0 R');	
			out('/Resources 2 0 R');
			out('/Contents ' + (objectNumber + 1) + ' 0 R>>');
			out('endobj');
			
			//Page content
			p = pages[n];
			newObject();
			out('<</Length ' + p.length  + '>>');
			putStream(p);
			out('endobj');					
		}
		offsets[1] = buffer.length;
		out('1 0 obj');
		out('<</Type /Pages');
		var kids='/Kids [';
		for (i = 0; i < page; i++) {
			kids += (3 + 2 * i) + ' 0 R ';
		}
		out(kids + ']');
		out('/Count ' + page);
		out(sprintf('/MediaBox [0 0 %.2f %.2f]', wPt, hPt));
		out('>>');
		out('endobj');		
	}
	
	var putStream = function(str) {
		out('stream');
		out(str);
		out('endstream');
	}
	
	var putResources = function() {
		putFonts();
		putImages();
		
		//Resource dictionary
		offsets[2] = buffer.length;
		out('2 0 obj');
		out('<<');
		putResourceDictionary();
		out('>>');
		out('endobj');
	}	
	
	var putFonts = function() {
		// TODO: Only supports core font hardcoded to Helvetica
		newObject();
		fontNumber = objectNumber;
		name = 'Helvetica';
		out('<</Type /Font');
		out('/BaseFont /' + name);
		out('/Subtype /Type1');
		out('/Encoding /WinAnsiEncoding');
		out('>>');
		out('endobj');
	}
	
	var putImages = function() {
		// TODO
	}
	
	var putResourceDictionary = function() {
		out('/ProcSet [/PDF /Text /ImageB /ImageC /ImageI]');
		out('/Font <<');
		// Do this for each font, the '1' bit is the index of the font
        // fontNumber is currently the object number related to 'putFonts'
		out('/F1 ' + fontNumber + ' 0 R');
		out('>>');
		out('/XObject <<');
		putXobjectDict();
		out('>>');
	}
	
	var putXobjectDict = function() {
		// TODO
		// Loop through images
	}
	
	
	var putInfo = function() {
		out('/Producer (jsPDF ' + version + ')');
		if(documentProperties.title != undefined) {
			out('/Title (' + pdfEscape(documentProperties.title) + ')');
		}
		if(documentProperties.subject != undefined) {
			out('/Subject (' + pdfEscape(documentProperties.subject) + ')');
		}
		if(documentProperties.author != undefined) {
			out('/Author (' + pdfEscape(documentProperties.author) + ')');
		}
		if(documentProperties.keywords != undefined) {
			out('/Keywords (' + pdfEscape(documentProperties.keywords) + ')');
		}
		if(documentProperties.creator != undefined) {
			out('/Creator (' + pdfEscape(documentProperties.creator) + ')');
		}		
		var created = new Date();
		var year = created.getFullYear();
		var month = (created.getMonth() + 1);
		var day = created.getDate();
		var hour = created.getHours();
		var minute = created.getMinutes();
		var second = created.getSeconds();
		out('/CreationDate (D:' + sprintf('%02d%02d%02d%02d%02d%02d', year, month, day, hour, minute, second) + ')');
	}
	
	var putCatalog = function () {
		out('/Type /Catalog');
		out('/Pages 1 0 R');
		// TODO: Add zoom and layout modes
		out('/OpenAction [3 0 R /FitH null]');
		out('/PageLayout /OneColumn');
	}	
	
	function putTrailer() {
		out('/Size ' + (objectNumber + 1));
		out('/Root ' + objectNumber + ' 0 R');
		out('/Info ' + (objectNumber - 1) + ' 0 R');
	}	

	var endDocument = function() {
		state = 1;
		putHeader();
		putPages();
		
		putResources();
		//Info
		newObject();
		out('<<');
		putInfo();
		out('>>');
		out('endobj');
		
		//Catalog
		newObject();
		out('<<');
		putCatalog();
		out('>>');
		out('endobj');
		
		//Cross-ref
		var o = buffer.length;
		out('xref');
		out('0 ' + (objectNumber + 1));
		out('0000000000 65535 f ');
		for (var i=1; i <= objectNumber; i++) {
			out(sprintf('%010d 00000 n ', offsets[i]));
		}
		//Trailer
		out('trailer');
		out('<<');
		putTrailer();
		out('>>');
		out('startxref');
		out(o);
		out('%%EOF');
		state = 3;		
	}
	
	var beginPage = function() {
		page ++;
		// Do dimension stuff
		state = 2;
		pages[page] = '';
		
		// TODO: Hardcoded at A4 and portrait
		pageHeight = pageFormats['a4'][1] / k;
		pageWidth = pageFormats['a4'][0] / k;
	}
	
	var out = function(string) {
		if(state == 2) {
			pages[page] += string + '\n';
		} else {
			buffer += string + '\n';
		}
	}
	
	var _addPage = function() {
		beginPage();
		// Set line width
		out(sprintf('%.2f w', (lineWidth * k)));
		
		// Set font - TODO
		// 16 is the font size
		pageFontSize = fontSize;
		out('BT /F1 ' + parseInt(fontSize) + '.00 Tf ET'); 		
	}
	
	// Add the first page automatically
	_addPage();	

	// Escape text
	var pdfEscape = function(text) {
		return text.replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
	}
	
	return {
		addPage: function() {
			_addPage();
		},
		text: function(x, y, text) {
			// need page height
			if(pageFontSize != fontSize) {
				out('BT /F1 ' + parseInt(fontSize) + '.00 Tf ET');
				pageFontSize = fontSize;
			}
			var str = sprintf('BT %.2f %.2f Td (%s) Tj ET', x * k, (pageHeight - y) * k, pdfEscape(text));
			out(str);
		},
		setProperties: function(properties) {
			documentProperties = properties;
		},
		addImage: function(imageData, format, x, y, w, h) {
		
		},
		output: function(type, options) {
			endDocument();
			if(type == undefined) {
				return buffer;
			}
			if(type == 'datauri') {
				document.location.href = 'data:application/pdf;base64,' + Base64.encode(buffer);
			}
			if(type == 'datauristring') {


				return 'data:application/pdf;base64,' + Base64.encode(buffer);
			}
			// @TODO: Add different output options
		},
		setFontSize: function(size) {
			fontSize = size;
		}
	}

};

},{}],10:[function(require,module,exports){
$(document).ready(function(){

    $(".embed-image").click(function(e){ 

        var iframe = $(this).parent().find('iframe');
        var videoObject = $(this).parent().find('.embed-video');
        var textcontent = $(this).parent().prev();       
        
        
        var players  = window.playersaem;   
        
        if(iframe.length>=1){


        $(".lp__multimedia_card .lp__card_img > .embed-video").find("iframe").removeAttr("style").css({
            'height': $(".lp__multimedia_card .lp__card_img > img").height(),
            'width': $(".lp__multimedia_card .lp__card_img > img").width()
        });



            if(typeof textcontent!="undefined" && typeof (textcontent.attr('class')) != 'undefined' && textcontent.attr('class').indexOf('featuredcard')>-1){
                
                textcontent.hide();
                
            }
            
            var srcVal = iframe[0].src;
            var imageObject = $(this).parent().children(':first-child');
            var playIcon = $(this).parent().find('.lp__play_icon');
            
            if(imageObject.length>=1){
                imageObject.css("visibility", "hidden");
                imageObject.css("height", "0");
                //imageObject.hide();
                if(playIcon.length>=1){
                playIcon.css("visibility", "hidden");
                playIcon.css("height", "0");
                   // playIcon.hide();
                }
                videoObject.css("visibility", "visible");
                videoObject.css("height", "auto");
                videoObject.show();
            }
            
            if (srcVal.indexOf("youtube") >= 0 ){

                
                
                var iframeid = iframe[0].id;
                var player = null;
                
                if(typeof players !='undefined'){
                    
                    for (x = 0; x < players.length; x++) {
                        
                        if(iframeid==players[x].a.id){
                            
                            player = players[x];
                            
                        }
                    }
                    
                }
                
                if(null!= player){
                    
                    player.playVideo();
                }else{
                    
                    
                    if (srcVal.indexOf("?") >= 0){
                        iframe[0].src =iframe[0].src +'&autoplay=1';
                    }else if (srcVal.indexOf("?") == -1){
                        iframe[0].src =iframe[0].src +'?autoplay=1';
                    }
                }
                
            }
        }
        equalHeight($(".lp__indepth_card_wrapper"));
    });
    
});
},{}],11:[function(require,module,exports){
// -----------Begin Navigation JS ------------- //
var select = require('../utils/select');
var dispatch = require('../utils/dispatch');

var clickEvent = ('ontouchstart' in document.documentElement ? 'touchstart' : 'click');
var dispatchers = [];

function handleNavElements (e) {

  var toggleElements = select('.loop-overlay, .loop-nav');
  var navCloseElement = select('.loop-nav-close')[ 0 ];

  toggleElements.forEach(function (element) {
    element.classList.toggle('is-visible');
  });

  document.body.classList.toggle('usa-mobile_nav-active');
  navCloseElement.focus();

  return false;
}

function navInit () {
  var navElements = select('.loop-menu-btn, .loop-overlay, .loop-nav-close');

  dispatchers = navElements.map(function (element) {
    return dispatch(element, clickEvent, handleNavElements);
  });
}

function navOff () {
  while (dispatchers.length) {
    dispatchers.pop().off();
  }
}

module.exports = navInit;
module.exports.off = navOff;
// -----------End Navigation JS ------------- //
},{"../utils/dispatch":22,"../utils/select":23}],12:[function(require,module,exports){


function sprintf( ) {
    // Return a formatted string  
    // 
    // version: 903.3016
    // discuss at: http://phpjs.org/functions/sprintf
    // +   original by: Ash Searle (http://hexmen.com/blog/)
    // + namespaced by: Michael White (http://getsprink.com)
    // +    tweaked by: Jack
    // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +      input by: Paulo Ricardo F. Santos
    // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // +      input by: Brett Zamir (http://brettz9.blogspot.com)
    // +   improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // *     example 1: sprintf("%01.2f", 123.1);
    // *     returns 1: 123.10
    // *     example 2: sprintf("[%10s]", 'monkey');
    // *     returns 2: '[    monkey]'
    // *     example 3: sprintf("[%'#10s]", 'monkey');
    // *     returns 3: '[####monkey]'
    var regex = /%%|%(\d+\$)?([-+\'#0 ]*)(\*\d+\$|\*|\d+)?(\.(\*\d+\$|\*|\d+))?([scboxXuidfegEG])/g;
    var a = arguments, i = 0, format = a[i++];

    // pad()
    var pad = function(str, len, chr, leftJustify) {
        if (!chr) chr = ' ';
        var padding = (str.length >= len) ? '' : Array(1 + len - str.length >>> 0).join(chr);
        return leftJustify ? str + padding : padding + str;
    };

    // justify()
    var justify = function(value, prefix, leftJustify, minWidth, zeroPad, customPadChar) {
        var diff = minWidth - value.length;
        if (diff > 0) {
            if (leftJustify || !zeroPad) {
                value = pad(value, minWidth, customPadChar, leftJustify);
            } else {
                value = value.slice(0, prefix.length) + pad('', diff, '0', true) + value.slice(prefix.length);
            }
        }
        return value;
    };

    // formatBaseX()
    var formatBaseX = function(value, base, prefix, leftJustify, minWidth, precision, zeroPad) {
        // Note: casts negative numbers to positive ones
        var number = value >>> 0;
        prefix = prefix && number && {'2': '0b', '8': '0', '16': '0x'}[base] || '';
        value = prefix + pad(number.toString(base), precision || 0, '0', false);
        return justify(value, prefix, leftJustify, minWidth, zeroPad);
    };

    // formatString()
    var formatString = function(value, leftJustify, minWidth, precision, zeroPad, customPadChar) {
        if (precision != null) {
            value = value.slice(0, precision);
        }
        return justify(value, '', leftJustify, minWidth, zeroPad, customPadChar);
    };

    // doFormat()
    var doFormat = function(substring, valueIndex, flags, minWidth, _, precision, type) {
        var number;
        var prefix;
        var method;
        var textTransform;
        var value;

        if (substring == '%%') return '%';

        // parse flags
        var leftJustify = false, positivePrefix = '', zeroPad = false, prefixBaseX = false, customPadChar = ' ';
        var flagsl = flags.length;
        for (var j = 0; flags && j < flagsl; j++) switch (flags.charAt(j)) {
            case ' ': positivePrefix = ' '; break;
            case '+': positivePrefix = '+'; break;
            case '-': leftJustify = true; break;
            case "'": customPadChar = flags.charAt(j+1); break;
            case '0': zeroPad = true; break;
            case '#': prefixBaseX = true; break;
        }

        // parameters may be null, undefined, empty-string or real valued
        // we want to ignore null, undefined and empty-string values
        if (!minWidth) {
            minWidth = 0;
        } else if (minWidth == '*') {
            minWidth = +a[i++];
        } else if (minWidth.charAt(0) == '*') {
            minWidth = +a[minWidth.slice(1, -1)];
        } else {
            minWidth = +minWidth;
        }

        // Note: undocumented perl feature:
        if (minWidth < 0) {
            minWidth = -minWidth;
            leftJustify = true;
        }

        if (!isFinite(minWidth)) {
            throw new Error('sprintf: (minimum-)width must be finite');
        }

        if (!precision) {
            precision = 'fFeE'.indexOf(type) > -1 ? 6 : (type == 'd') ? 0 : void(0);
        } else if (precision == '*') {
            precision = +a[i++];
        } else if (precision.charAt(0) == '*') {
            precision = +a[precision.slice(1, -1)];
        } else {
            precision = +precision;
        }

        // grab value using valueIndex if required?
        value = valueIndex ? a[valueIndex.slice(0, -1)] : a[i++];

        switch (type) {
            case 's': return formatString(String(value), leftJustify, minWidth, precision, zeroPad, customPadChar);
            case 'c': return formatString(String.fromCharCode(+value), leftJustify, minWidth, precision, zeroPad);
            case 'b': return formatBaseX(value, 2, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
            case 'o': return formatBaseX(value, 8, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
            case 'x': return formatBaseX(value, 16, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
            case 'X': return formatBaseX(value, 16, prefixBaseX, leftJustify, minWidth, precision, zeroPad).toUpperCase();
            case 'u': return formatBaseX(value, 10, prefixBaseX, leftJustify, minWidth, precision, zeroPad);
            case 'i':
            case 'd': {
                number = parseInt(+value);
                prefix = number < 0 ? '-' : positivePrefix;
                value = prefix + pad(String(Math.abs(number)), precision, '0', false);
                return justify(value, prefix, leftJustify, minWidth, zeroPad);
            }
            case 'e':
            case 'E':
            case 'f':
            case 'F':
            case 'g':
            case 'G': {
                number = +value;
                prefix = number < 0 ? '-' : positivePrefix;
                method = ['toExponential', 'toFixed', 'toPrecision']['efg'.indexOf(type.toLowerCase())];
                textTransform = ['toString', 'toUpperCase']['eEfFgG'.indexOf(type) % 2];
                value = prefix + Math.abs(number)[method](precision);
                return justify(value, prefix, leftJustify, minWidth, zeroPad)[textTransform]();
            }
            default: return substring;
        }
    };

    return format.replace(regex, doFormat);
}

},{}],13:[function(require,module,exports){
'use strict';

var splitTableBreakPoint = 991;
$(document).ready(function() {
    
    // $("table").addClass("responsive");
    $("table.responsive td br").remove(); 
    var switched = false;
    var updateTables = function() {
        if (($(window).width() < splitTableBreakPoint) && !switched) {
            switched = true;
            $("table.responsive").each(function(i, element) {
                splitTable($(element));
            });
            return true;
        } else if (switched && ($(window).width() > splitTableBreakPoint)) {
            switched = false;
            $("table.responsive").each(function(i, element) {
                unsplitTable($(element));
            });
        } 
    };
    $(window).load(updateTables);
    $(window).bind("resize", updateTables);
    
    function splitTable(original) {
        original.wrap("<div class='table-wrapper' />");
        original.find("tr:not(:first-child)").each(function(){
            
            if($(this).find("td").length === 1)
                $(this).append('<td class="dummy-td">&nbsp;</td>');
        })
        var copy = original.clone();
        copy.find("td:not(:first-child), th:not(:first-child)").css("display", "none");
        copy.removeClass("responsive");
        original.closest(".table-wrapper").append(copy);
        copy.wrap("<div class='pinned' />");
        original.wrap("<div class='scrollable' />");
    }
    
    function unsplitTable(original) {
        original.closest(".table-wrapper").find(".pinned").remove();
        original.find(".dummy-td").remove();
        original.unwrap();
    }
});

$("document").ready(function() {
    $(window).resize(scrollIdentity);
    $(window).load(scrollIdentity);
    /*document.body.addEventListener('DOMNodeInserted', function(event) {
    if ($(event.relatedNode).hasClass("scrollable"))
    scrollIdentity();
    }, false);*/
    
    $("body").on("click", "div.has_scrollbar", function() {
        var obj = $(this).parent(".scrollable");
        var scrollWi = ($(obj)[0].scrollWidth >= $(obj)[0].clientWidth)? ($(obj)[0].clientWidth + $(obj)[0].scrollLeft) : $(obj)[0].scrollWidth;
        $(obj).animate({scrollLeft:scrollWi}, 500);
    })
});

function scrollIdentity() {
    if ($(window).width() < splitTableBreakPoint) {
        $("div.scrollable").each(function() {
            var hasHorizontalScrollbar = this.scrollWidth > this.clientWidth;
            if (hasHorizontalScrollbar && $(this).find(".has_scrollbar").length === 0) {
                $(this).append('<div title="It has scrollable content" class="has_scrollbar">&rsaquo;<style>table.responsive>tbody>tr>td {white-space: nowrap;} .has_scrollbar{position:absolute;right:5px;top:0;/*calc((100% - 63px) / 2);*/font-size:2em;color:gray;-webkit-animation:pop-left 1s infinite;-moz-animation:pop-left 1s infinite;-o-animation:pop-left 1s infinite;animation:pop-left 1s infinite}@-webkit-keyframes "pop-left"{0%{right:-2px;}50%{right:0px;}100%{right:-2px;}}@-moz-keyframes "pop-left"{0%{right:-2px;}50%{right:0px;}100%{right:-2px;}}@-o-keyframes pop-left{0% { right:-2px}50%{right:0px}100%{right:-2px}@keyframes "pop-left"{0%{right:-2px;}50%{right:0px;}100%{right:-2px;}}</style></div>');
            }
        });
    } else {
        $(".has_scrollbar").remove(".has_scrollbar")
    }
}


},{}],14:[function(require,module,exports){
/*The MIT License (MIT)

Copyright (c) 2014 https://github.com/kayalshri/

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.*/

(function($){
    $.fn.extend({
        tableExport: function(options) {
            var defaults = {
                separator: ',',
                ignoreColumn: [],
                tableName:'yourTableName',
                type:'csv',
                pdfFontSize:14,
                pdfLeftMargin:20,
                escape:'true',
                htmlContent:'false',
                consoleLog:'false',
                id:"",
                fileName:"export"
            };
            
            var options = $.extend(defaults, options);
            var el = this;
            
            if(defaults.type == 'csv' || defaults.type == 'txt'){
                
                // Header
                var tdData ="";
                $(el).find('thead').find('tr').each(function() {
                    tdData += "\n";					
                    $(this).filter(':visible').find('th').each(function(index,data) {
                        if ($(this).css('display') != 'none'){
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                tdData += '"' + parseString($(this)) + '"' + defaults.separator;									
                            }
                        }
                        
                    });
                    tdData = $.trim(tdData);
                    tdData = $.trim(tdData).substring(0, tdData.length -1);
                });
                
                // Row vs Column
                $(el).find('tbody').find('tr').each(function() {
                    tdData += "\n";
                    $(this).filter(':visible').find('td').each(function(index,data) {
                        if ($(this).css('display') != 'none'){
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                tdData += '"'+ parseString($(this)) + '"'+ defaults.separator;
                            }
                        }
                    });
                    //tdData = $.trim(tdData);
                    tdData = $.trim(tdData).substring(0, tdData.length -1);
                });
                
                //output
                if(defaults.consoleLog == 'true'){
                    console.log(tdData);
                    
                    
                }
                var base64data = "base64," + $.base64.encode(tdData);
                
                
                
                
                var filename=defaults.fileName+"."+defaults.type;
                
                
                
                if ( window.navigator.msSaveBlob) {
                    
                    
                    
                    
                    
                    var blob = new Blob([decodeURIComponent(tdData)], {
                        type: 'text/'+defaults.type+';charset=utf8'
                    });
                    
                    // Crashes in IE 10, IE 11 and Microsoft Edge
                    // See MS Edge Issue #10396033
                    // Hence, the deliberate 'false'
                    // This is here just for completeness
                    // Remove the 'false' at your own risk
                    window.navigator.msSaveBlob(blob, filename);
                    
                } else if (window.Blob && window.URL) {
                    
                    
                    // HTML5 Blob        
                    var blob = new Blob([tdData], {
                        type: 'text/'+defaults.type+';charset=utf-8'
                    });
                    var csvUrl = URL.createObjectURL(blob);
                    
                    
                    
                    var a = document.createElement('a');
                    
                    a.href = csvUrl;
                    //setting the file name
                    a.download = filename;
                    //triggering the function
                    
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    //a.click();
                    
                    
                } else {
                    
                    
                    // Data URI
                    var csvData = 'data:application/'+defaults.type+';charset=utf-8,' + encodeURIComponent(tdData);
                    
                    
                    var a = document.createElement('a');
                    
                    a.href = csvData;
                    //setting the file name
                    a.download = filename;
                    //triggering the function
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    
                    
                    
                }
                
                
                //window.open('data:application/'+defaults.type+';filename=exportData;' + base64data);
            }else if(defaults.type == 'sql'){
                
                // Header
                var tdData ="INSERT INTO `"+defaults.tableName+"` (";
                $(el).find('thead').find('tr').each(function() {
                    
                    $(this).filter(':visible').find('th').each(function(index,data) {
                        if ($(this).css('display') != 'none'){
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                tdData += '`' + parseString($(this)) + '`,' ;									
                            }
                        }
                        
                    });
                    tdData = $.trim(tdData);
                    tdData = $.trim(tdData).substring(0, tdData.length -1);
                });
                tdData += ") VALUES ";
                // Row vs Column
                $(el).find('tbody').find('tr').each(function() {
                    tdData += "(";
                    $(this).filter(':visible').find('td').each(function(index,data) {
                        if ($(this).css('display') != 'none'){
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                tdData += '"'+ parseString($(this)) + '",';
                            }
                        }
                    });
                    
                    tdData = $.trim(tdData).substring(0, tdData.length -1);
                    tdData += "),";
                });
                tdData = $.trim(tdData).substring(0, tdData.length -1);
                tdData += ";";
                
                //output
                //console.log(tdData);
                
                if(defaults.consoleLog == 'true'){
                    console.log(tdData);
                }
                
                var base64data = "base64," + $.base64.encode(tdData);
                window.open('data:application/sql;filename=exportData;' + base64data);
                
                
            }else if(defaults.type == 'json'){
                
                var jsonHeaderArray = [];
                $(el).find('thead').find('tr').each(function() {
                    var tdData ="";	
                    var jsonArrayTd = [];
                    
                    $(this).filter(':visible').find('th').each(function(index,data) {
                        if ($(this).css('display') != 'none'){
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                jsonArrayTd.push(parseString($(this)));									
                            }
                        }
                    });									
                    jsonHeaderArray.push(jsonArrayTd);						
                    
                });
                
                var jsonArray = [];
                $(el).find('tbody').find('tr').each(function() {
                    var tdData ="";	
                    var jsonArrayTd = [];
                    
                    $(this).filter(':visible').find('td').each(function(index,data) {
                        if ($(this).css('display') != 'none'){
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                jsonArrayTd.push(parseString($(this)));									
                            }
                        }
                    });									
                    jsonArray.push(jsonArrayTd);									
                    
                });
                
                var jsonExportArray =[];
                jsonExportArray.push({header:jsonHeaderArray,data:jsonArray});
                
                //Return as JSON
                //console.log(JSON.stringify(jsonExportArray));
                
                //Return as Array
                //console.log(jsonExportArray);
                if(defaults.consoleLog == 'true'){
                    console.log(JSON.stringify(jsonExportArray));
                }
                var base64data = "base64," + $.base64.encode(JSON.stringify(jsonExportArray));
                window.open('data:application/json;filename=exportData;' + base64data);
            }else if(defaults.type == 'xml'){
                
                var xml = '<?xml version="1.0" encoding="utf-8"?>';
                xml += '<tabledata><fields>';
                
                // Header
                $(el).find('thead').find('tr').each(function() {
                    $(this).filter(':visible').find('th').each(function(index,data) {
                        if ($(this).css('display') != 'none'){					
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                xml += "<field>" + parseString($(this)) + "</field>";
                            }
                        }
                    });									
                });					
                xml += '</fields><data>';
                
                // Row Vs Column
                var rowCount=1;
                $(el).find('tbody').find('tr').each(function() {
                    xml += '<row id="'+rowCount+'">';
                    var colCount=0;
                    $(this).filter(':visible').find('td').each(function(index,data) {
                        if ($(this).css('display') != 'none'){	
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                xml += "<column-"+colCount+">"+parseString($(this))+"</column-"+colCount+">";
                            }
                        }
                        colCount++;
                    });															
                    rowCount++;
                    xml += '</row>';
                });					
                xml += '</data></tabledata>'
                
                if(defaults.consoleLog == 'true'){
                    console.log(xml);
                }
                
                var base64data = "base64," + $.base64.encode(xml);
                window.open('data:application/xml;filename=exportData;' + base64data);
                
            }else if(defaults.type == 'excel' || defaults.type == 'doc'|| defaults.type == 'powerpoint'  ){
                //console.log($(this).html());
                var excel="<table>";
                // Header
                $(el).find('thead').find('tr').each(function() {
                    excel += "<tr>";
                    $(this).filter(':visible').find('th').each(function(index,data) {
                        if ($(this).css('display') != 'none'){					
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                excel += "<td>" + parseString($(this))+ "</td>";
                            }
                        }
                    });	
                    excel += '</tr>';						
                    
                });					
                
                
                // Row Vs Column
                var rowCount=1;
                $(el).find('tbody').find('tr').each(function() {
                    excel += "<tr>";
                    var colCount=0;
                    $(this).filter(':visible').find('td').each(function(index,data) {
                        if ($(this).css('display') != 'none'){	
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                excel += "<td>"+parseString($(this))+"</td>";
                            }
                        }
                        colCount++;
                    });															
                    rowCount++;
                    excel += '</tr>';
                });					
                excel += '</table>'
                
                if(defaults.consoleLog == 'true'){
                    console.log(excel);
                }
                
                var excelFile = "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:x='urn:schemas-microsoft-com:office:"+defaults.type+"' xmlns='http://www.w3.org/TR/REC-html40'>";
                excelFile += "<head>";
                excelFile += "<!--[if gte mso 9]>";
                excelFile += "<xml>";
                excelFile += "<x:ExcelWorkbook>";
                excelFile += "<x:ExcelWorksheets>";
                excelFile += "<x:ExcelWorksheet>";
                excelFile += "<x:Name>";
                excelFile += "{worksheet}";
                excelFile += "</x:Name>";
                excelFile += "<x:WorksheetOptions>";
                excelFile += "<x:DisplayGridlines/>";
                excelFile += "</x:WorksheetOptions>";
                excelFile += "</x:ExcelWorksheet>";
                excelFile += "</x:ExcelWorksheets>";
                excelFile += "</x:ExcelWorkbook>";
                excelFile += "</xml>";
                excelFile += "<![endif]-->";
                excelFile += "</head>";
                excelFile += "<body>";
                excelFile += excel;
                excelFile += "</body>";
                excelFile += "</html>";
                
                var base64data = "base64," + $.base64.encode(excelFile);
                
                
                
                
                
                
                var csvData = 'data:application/vnd.ms-' + defaults.type + ';filename=exportData.doc;' + base64data;
                
                var fileName = defaults.fileName;
                
                if ( window.navigator.msSaveBlob) {
                    
                    if(defaults.type=='excel'){
                        
                        fileName = fileName+".xls";
                        
                        
                    }
                    
                    if(defaults.type=='doc'){
                        
                        fileName = fileName+".doc";
                        
                        
                    }
                    
                    
                    var blob = new Blob([decodeURIComponent(excelFile)], {
                        type:  'data:application/vnd.ms-' + defaults.type+';charset=utf8'
                    });
                    
                    // Crashes in IE 10, IE 11 and Microsoft Edge
                    // See MS Edge Issue #10396033
                    // Hence, the deliberate 'false'
                    // This is here just for completeness
                    // Remove the 'false' at your own risk
                    window.navigator.msSaveBlob(blob, fileName);
                    
                }else{ 
                    
                    if(defaults.type=='excel'){
                        
                        fileName = fileName+".xls";
                        
                        
                    }
                    
                    if(defaults.type=='doc'){
                        
                        fileName = fileName+".doc";
                        
                        
                    }
                    
                    
                    
                    var a = document.createElement('a');
                    
                    
                    
                    a.href = csvData;
                    //setting the file name
                    a.download = fileName;
                    //triggering the function
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    
                }
                
                
                //window.open('data:application/vnd.ms-'+defaults.type+';filename=exportData.doc;' + base64data);
                
            }else if(defaults.type == 'png'){
                html2canvas($(el), {
                    onrendered: function(canvas) {										
                        var img = canvas.toDataURL("image/png");
                        window.open(img);
                        
                        
                    }
                });		
            }else if(defaults.type == 'pdf'){
                
                var doc = new jsPDF('p','pt', 'a4', true);
                doc.setFontSize(defaults.pdfFontSize);
                
                // Header
                var startColPosition=defaults.pdfLeftMargin;
                $(el).find('thead').find('tr').each(function() {
                    $(this).filter(':visible').find('th').each(function(index,data) {
                        if ($(this).css('display') != 'none'){					
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                var colPosition = startColPosition+ (index * 50);									
                                doc.text(colPosition,20, parseString($(this)));
                            }
                        }
                    });									
                });					
                
                
                // Row Vs Column
                var startRowPosition = 20; var page =1;var rowPosition=0;
                $(el).find('tbody').find('tr').each(function(index,data) {
                    rowCalc = index+1;
                    
                    if (rowCalc % 26 == 0){
                        doc.addPage();
                        page++;
                        startRowPosition=startRowPosition+10;
                    }
                    rowPosition=(startRowPosition + (rowCalc * 10)) - ((page -1) * 280);
                    
                    $(this).filter(':visible').find('td').each(function(index,data) {
                        if ($(this).css('display') != 'none'){	
                            if(defaults.ignoreColumn.indexOf(index) == -1){
                                var colPosition = startColPosition+ (index * 50);									
                                doc.text(colPosition,rowPosition, parseString($(this)));
                            }
                        }
                        
                    });															
                    
                });		
                
                
                
                
                var csvData = doc.output('datauristring');
                
                var fileName = defaults.fileName;
                
                if(defaults.type=='pdf'){
                    
                    fileName = fileName+".pdf";
                    
                    
                }
                
                
                
                if ( window.navigator.msSaveBlob) {
                    
                    
                    
                    var blob = new Blob([], {
                        type:  csvData+';charset=utf8'
                    });
                    
                    // Crashes in IE 10, IE 11 and Microsoft Edge
                    // See MS Edge Issue #10396033
                    // Hence, the deliberate 'false'
                    // This is here just for completeness
                    // Remove the 'false' at your own risk
                    window.navigator.msSaveBlob(blob, fileName);
                    
                }else{
                    
                    
                    
                    
                    
                    var a = document.createElement('a');
                    
                    a.href = csvData;
                    //setting the file name
                    a.download = fileName;
                    //triggering the function
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    
                }
                
                
                
                
                
                //console.log(doc);
                // Output as Data URI
                //doc.output('datauri');
                
            }
            
            
            function parseString(data){
                
                if(defaults.htmlContent == 'true'){
                    content_data = data.html().trim();
                }else{
                    content_data = data.text().trim();
                }
                
                if(defaults.escape == 'true'){
                    content_data = escape(content_data);
                }
                
                
                
                return content_data;
            }
            
        }
    });
})(jQuery);


},{}],15:[function(require,module,exports){
 // Put states into array
 var state_array = [];

 $(document).ready(function() {
   $('.region').each(function() {
     var a = $(this).text();
     if ($.inArray(a, state_array) == -1) {
       state_array.push(a);
     }
   });
   state_array.sort();
 });

 // Put states into select list
 $(document).ready(function() {
   var option = '';

   for (var i = 0; i < state_array.length; i++) {
     option += '<option value="' + state_array[i] + '">' + state_array[i] + '</option>';
   }

   $('.state_select').append(option);

 });

 // Clear selection
 $('.btn-clear').click(function() {
   $('#sorting_table tr').show();
 });

 // Filter table based on user input
 $('.state_select').change(function() {

   $('#sorting_table tr').show();

   var state_code = $(this).val();

   $('.region').each(function() {

     if ($(this).text() != state_code) {
       $(this).closest("tr").hide();
     }

   });
 });

 $('th').click(function() {  
   var table =  $(this).parents('table').eq(0);
   var rows = table.find('tr:gt(0)').toArray().sort(comparer($(this).index()))
   this.asc = !this.asc;   
   if (!this.asc) {
     rows = rows.reverse();
   }   
   for (var i = 0; i < rows.length; i++) {
     table.append(rows[i]);
   }
 })

 function comparer(index) {  
   return function(a, b) {      
     var valA = getCellValue(a, index), valB = getCellValue(b, index);
     return $.isNumeric(valA) && $.isNumeric(valB) ?  valA - valB  : valA.localeCompare(valB) ; 
   }
 }

 function getCellValue(row, index) {
   return $(row).children('td').eq(index).html();
 }
 
 // Get user input to search for string
$(".input").keyup(function () {
      var data = this.value.toUpperCase().split(" ");
      var jo = $("#sorting_table_list").find("tr");
      if (this.value == "") {
          jo.show();
          return;
      }
      jo.hide();

      jo.filter(function (i, v) {
          var $t = $(this);
          for (var d = 0; d < data.length; ++d) {
              if ($t.text().toUpperCase().indexOf(data[d]) > -1) {
                  return true;
              }
          }
          return false;
      })
      .show();
  }).focus(function () {
      this.value = "";
      $(this).css({
          "color": "black"
      });
      $(this).unbind('focus');
  }).css({
      "color": "#C0C0C0"
  });
},{}],16:[function(require,module,exports){
/*START: Tab click event handler*/
    $(document).on("click", "tab-nav ul li", function(e) {
        $(this).closest("tab").find(".lp__tab_active").removeClass("lp__tab_active");
        $(this).find("a").addClass("lp__tab_active");
        $(this).closest("tab").find("tab-content ul.lp__tab_content_list>li").eq($(this).index()).addClass("lp__tab_active");
    });
    /*END: Tab click event handler*/

var screenWidth = 600;
    /*START: Scrollable tabs controller*/
if ($(window).width() > screenWidth) {
    var hidWidth;
    var scrollBarWidths = 0;

    var widthOfList = function() {
        var itemsWidth = 0;
        $('.lp__list li').each(function() {
            var itemWidth = $(this).outerWidth();
            itemsWidth += itemWidth;
        });
        return itemsWidth;
    };
    var getLeftPosi = function() {
        return $('.lp__list').position().left;
    };

    var widthOfRightHidden = function() {
        return (($('.lp__wrapper').outerWidth()) - widthOfList() - getLeftPosi()) - scrollBarWidths;
    };
    var reAdjust = function() {
        if (($('.lp__wrapper').outerWidth()) < widthOfList()) {
            $('.lp__scroller-right').show();
        } else {
            $('.lp__scroller-right').hide();
        }

        if (getLeftPosi() < 0) {
            $('.lp__scroller-left').show();
        } else {
            $('.item').animate({
                left: "-=" + getLeftPosi() + "px"
            }, 'slow');
            $('.lp__scroller-left').hide();
        }
    }

    reAdjust();

    $(window).on('resize', function(e) {
        reAdjust();
    });

    $('.lp__scroller-right').click(function() {
        
        $('.lp__scroller-left').fadeIn('slow');

        var scrollWidth = $('.lp__wrapper').outerWidth() - 200;

        if (scrollWidth >= Math.abs(widthOfRightHidden()))
            scrollWidth = Math.abs(widthOfRightHidden()) + 75;


        if (widthOfRightHidden() <= 0) {
            scrollWidth = -Math.abs(scrollWidth);
        } else {
            $('.lp__scroller-right').fadeOut('slow');
            return false;
        }
        $('.lp__list').animate({
            left: "+=" + scrollWidth + "px"
        }, 'slow', function() {});



    });

    $('.lp__scroller-left').click(function() {
        
        $('.lp__scroller-right').fadeIn('slow');
        var scrollWidth = $('.lp__wrapper').outerWidth() - 100;

        if (Math.abs($(".lp__list").position().left) >= (scrollWidth))
            scrollWidth = $(".lp__list").position().left
        else
            scrollWidth = $(".lp__list").position().left;
        if ($(".lp__list").position().left >= scrollWidth)
            $('.lp__scroller-left').fadeOut('slow');

        $('.lp__list').animate({
            left: "-=" + scrollWidth + "px"
        }, 'slow', function() {

        });
    });
}
    /*END: Scrollable tabs controller*/
},{}],17:[function(require,module,exports){

+function ($) {
  'use strict';

  function transitionEnd() {
    var el = document.createElement('loop')

    var transEndEventNames = {
      WebkitTransition : 'webkitTransitionEnd',
      MozTransition    : 'transitionend',
      OTransition      : 'oTransitionEnd otransitionend',
      transition       : 'transitionend'
    }

    for (var name in transEndEventNames) {
      if (el.style[name] !== undefined) {
        return { end: transEndEventNames[name] }
      }
    }

    return false // explicit for ie8 (  ._.)
  }

  // http://blog.alexmaccaw.com/css-transitions
  $.fn.emulateTransitionEnd = function (duration) {
    var called = false
    var $el = this
    $(this).one('bsTransitionEnd', function () { called = true })
    var callback = function () { if (!called) $($el).trigger($.support.transition.end) }
    setTimeout(callback, duration)
    return this
  }

  $(function () {
    $.support.transition = transitionEnd()

    if (!$.support.transition) return

    $.event.special.bsTransitionEnd = {
      bindType: $.support.transition.end,
      delegateType: $.support.transition.end,
      handle: function (e) {
        if ($(e.target).is(this)) return e.handleObj.handler.apply(this, arguments)
      }
    }
  })

}(jQuery);

},{}],18:[function(require,module,exports){
$(document).ready(function() { 
    
    $(".lp__shorting_table").each(function(){
        
        var downLoadLinks =  $(this).find('.download_group_btn').children('a');
        downLoadLinks.each(function () {
            var anchorRef = $(this);






            anchorRef.on('click',function(e){

                var hrefVal = $(this).attr('href');



                if(hrefVal=='#'){

                   
                e.preventDefault();

                var tableRef = $(this).parent().parent().find('table').first();

                var tableType = $(this).data('type');


                tableRef.tableExport({type:tableType,escape:'false',fileName:'export',id:'csv'});
                }

                
            });
        });

        
        
        
    })
});
},{}],19:[function(require,module,exports){
var select = require('../utils/select');
var whenDOMReady = require('../utils/when-dom-ready');
var Accordion = require('../components/accordion');

whenDOMReady(function initAccordions () {

  var accordions = select('.usa-accordion, .loop-accordion-content');
  accordions.forEach(function (el) {
    new Accordion(el);
  });
});

},{"../components/accordion":1,"../utils/select":23,"../utils/when-dom-ready":24}],20:[function(require,module,exports){
var whenDOMReady = require('../utils/when-dom-ready');
var navInit = require('../components/navigation');

whenDOMReady(navInit);

},{"../components/navigation":11,"../utils/when-dom-ready":24}],21:[function(require,module,exports){
'use strict';


require('./components/tableExport.js');
require('./components/jquery.base64');
require('./components/html2canvas.js');
require('./components/sprintf.js');
require('./components/jspdf.js');
require('./components/base64.js');
require('./components/wbg_table_export.js');
require('./initializers/accordions');
require('./initializers/navigation');
require('./components/transition');
require('./components/button');
require('./components/collapse');
require('./components/dropdown');
require('./components/table_sorting');
require('./components/table');
require('./components/tabs'); 
require('./components/multimedia');
require('./components/card');



},{"./components/base64.js":2,"./components/button":3,"./components/card":4,"./components/collapse":5,"./components/dropdown":6,"./components/html2canvas.js":7,"./components/jquery.base64":8,"./components/jspdf.js":9,"./components/multimedia":10,"./components/sprintf.js":12,"./components/table":13,"./components/tableExport.js":14,"./components/table_sorting":15,"./components/tabs":16,"./components/transition":17,"./components/wbg_table_export.js":18,"./initializers/accordions":19,"./initializers/navigation":20}],22:[function(require,module,exports){
/**
 * Attaches a given listener function to a given element which is
 * triggered by a specified list of event types.
 * @param {HTMLElement} element - the element to which the listener will be attached
 * @param {String} eventTypes - space-separated list of event types which will trigger the listener
 * @param {Function} listener - the function to be executed
 * @returns {Object} - containing a <tt>trigger()</tt> method for executing the listener, and an <tt>off()</tt> method for detaching it
 */
module.exports = function dispatch (element, eventTypes, listener, options) {
  var eventTypeArray = eventTypes.split(/\s+/);

  var attach = function (e, t, d) {
    if (e.attachEvent) {
      e.attachEvent('on' + t, d, options);
    }
    if (e.addEventListener) {
      e.addEventListener(t, d, options);
    }
  };

  var trigger = function (e, t) {
    var fakeEvent;
    if ('createEvent' in document) {
      // modern browsers, IE9+
      fakeEvent = document.createEvent('HTMLEvents');
      fakeEvent.initEvent(t, false, true);
      e.dispatchEvent(fakeEvent);
    } else {
      // IE 8
      fakeEvent = document.createEventObject();
      fakeEvent.eventType = t;
      e.fireEvent('on'+e.eventType, fakeEvent);
    }
  };

  var detach = function (e, t, d) {
    if (e.detachEvent) {
      e.detachEvent('on' + t, d, options);
    }
    if (e.removeEventListener) {
      e.removeEventListener(t, d, options);
    }
  };

  eventTypeArray.forEach(function (eventType) {
    attach.call(null, element, eventType, listener);
  });

  return {
    trigger: function () {
      trigger.call(null, element, eventTypeArray[ 0 ]);
    },
    off: function () {
      eventTypeArray.forEach(function (eventType) {
        detach.call(null, element, eventType, listener);
      });
    },
  };
};

},{}],23:[function(require,module,exports){
/**
 * @name select
 * @desc selects elements from the DOM by class selector or ID selector.
 * @param {string} selector - The selector to traverse the DOM with.
 * @param {HTMLElement} context - The context to traverse the DOM in.
 * @return {Array.HTMLElement} - An array of DOM nodes or an empty array.
 */
module.exports = function select (selector, context) {

  if (typeof selector !== 'string') {
    return [];
  }

  if ((context === undefined) || !isElement(context)) {
    context = window.document;
  }

  var selection = context.querySelectorAll(selector);

  return Array.prototype.slice.call(selection);

};

function isElement (value) {
  return !!value && typeof value === 'object' && value.nodeType === 1;
}
},{}],24:[function(require,module,exports){
/*
 * @name DOMLoaded
 * @param {function} cb - The callback function to run when the DOM has loaded.
 */
module.exports = function DOMLoaded (cb) {
  // in case the document is already rendered
  if ('loading' !== document.readyState) {
    if (isFunction(cb)) {
      cb();
    }
  } else if (document.addEventListener) { // modern browsers
    document.addEventListener('DOMContentLoaded', cb);
  } else { // IE <= 8
    document.attachEvent('onreadystatechange', function (){
      if ('complete' === document.readyState) {
        if (isFunction(cb)) {
          cb();
        }
      }
    });
  }
};

function isFunction (arg) {
  return (typeof arg === 'function');
}
},{}]},{},[21])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJzcmMvanMvY29tcG9uZW50cy9hY2NvcmRpb24uanMiLCJzcmMvanMvY29tcG9uZW50cy9iYXNlNjQuanMiLCJzcmMvanMvY29tcG9uZW50cy9idXR0b24uanMiLCJzcmMvanMvY29tcG9uZW50cy9jYXJkLmpzIiwic3JjL2pzL2NvbXBvbmVudHMvY29sbGFwc2UuanMiLCJzcmMvanMvY29tcG9uZW50cy9kcm9wZG93bi5qcyIsInNyYy9qcy9jb21wb25lbnRzL2h0bWwyY2FudmFzLmpzIiwic3JjL2pzL2NvbXBvbmVudHMvanF1ZXJ5LmJhc2U2NC5qcyIsInNyYy9qcy9jb21wb25lbnRzL2pzcGRmLmpzIiwic3JjL2pzL2NvbXBvbmVudHMvbXVsdGltZWRpYS5qcyIsInNyYy9qcy9jb21wb25lbnRzL25hdmlnYXRpb24uanMiLCJzcmMvanMvY29tcG9uZW50cy9zcHJpbnRmLmpzIiwic3JjL2pzL2NvbXBvbmVudHMvdGFibGUuanMiLCJzcmMvanMvY29tcG9uZW50cy90YWJsZUV4cG9ydC5qcyIsInNyYy9qcy9jb21wb25lbnRzL3RhYmxlX3NvcnRpbmcuanMiLCJzcmMvanMvY29tcG9uZW50cy90YWJzLmpzIiwic3JjL2pzL2NvbXBvbmVudHMvdHJhbnNpdGlvbi5qcyIsInNyYy9qcy9jb21wb25lbnRzL3diZ190YWJsZV9leHBvcnQuanMiLCJzcmMvanMvaW5pdGlhbGl6ZXJzL2FjY29yZGlvbnMuanMiLCJzcmMvanMvaW5pdGlhbGl6ZXJzL25hdmlnYXRpb24uanMiLCJzcmMvanMvc3RhcnQuanMiLCJzcmMvanMvdXRpbHMvZGlzcGF0Y2guanMiLCJzcmMvanMvdXRpbHMvc2VsZWN0LmpzIiwic3JjL2pzL3V0aWxzL3doZW4tZG9tLXJlYWR5LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDeEVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMvSUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDckhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDcE5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbk5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbDhGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlMQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDcFRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3RDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDeEpBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzNFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9pQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNqR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQy9GQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNoREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN4Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1hBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDSkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3ZCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDM0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDekJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiLy8gLS0tLS0tLS0tLS1CZWdpbiBBY2NvcmRpb24gSlMgLS0tLS0tLS0tLS0tLSAvL1xuXG52YXIgc2VsZWN0ID0gcmVxdWlyZSgnLi4vdXRpbHMvc2VsZWN0Jyk7XG5cbmZ1bmN0aW9uIHNob3dQYW5lbExpc3RlbmVyIChlbCwgZXYpIHtcbiAgdmFyIGV4cGFuZGVkID0gZWwuZ2V0QXR0cmlidXRlKCdhcmlhLWV4cGFuZGVkJykgPT09ICd0cnVlJztcbiAgdGhpcy5oaWRlQWxsKCk7XG4gIGlmICghZXhwYW5kZWQpIHtcbiAgICB0aGlzLnNob3coZWwpO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuZnVuY3Rpb24gQWNjb3JkaW9uIChlbCkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHRoaXMucm9vdCA9IGVsO1xuXG4gIC8vIGRlbGVnYXRlIGNsaWNrIGV2ZW50cyBvbiBlYWNoIDxidXR0b24+XG4gIHZhciBidXR0b25zID0gc2VsZWN0KCdidXR0b24nLCB0aGlzLnJvb3QpO1xuICBidXR0b25zLmZvckVhY2goZnVuY3Rpb24gKGVsKSB7XG4gICAgaWYgKGVsLmF0dGFjaEV2ZW50KSB7XG4gICAgICBlbC5hdHRhY2hFdmVudCgnb25jbGljaycsIHNob3dQYW5lbExpc3RlbmVyLmJpbmQoc2VsZiwgZWwpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBzaG93UGFuZWxMaXN0ZW5lci5iaW5kKHNlbGYsIGVsKSk7XG4gICAgfVxuICB9KTtcblxuICAvLyBmaW5kIHRoZSBmaXJzdCBleHBhbmRlZCBidXR0b25cbiAgdmFyIGV4cGFuZGVkID0gdGhpcy4kKCdidXR0b25bYXJpYS1leHBhbmRlZD10cnVlXScpWyAwIF07XG4gIHRoaXMuaGlkZUFsbCgpO1xuICBpZiAoZXhwYW5kZWQgIT09IHVuZGVmaW5lZCkge1xuICAgIHRoaXMuc2hvdyhleHBhbmRlZCk7XG4gIH1cbn1cblxuQWNjb3JkaW9uLnByb3RvdHlwZS4kID0gZnVuY3Rpb24gKHNlbGVjdG9yKSB7XG4gIHJldHVybiBzZWxlY3Qoc2VsZWN0b3IsIHRoaXMucm9vdCk7XG59O1xuXG5cbkFjY29yZGlvbi5wcm90b3R5cGUuaGlkZSA9IGZ1bmN0aW9uIChidXR0b24pIHtcbiAgdmFyIHNlbGVjdG9yID0gYnV0dG9uLmdldEF0dHJpYnV0ZSgnYXJpYS1jb250cm9scycpLFxuICAgIGNvbnRlbnQgPSB0aGlzLiQoJyMnICsgc2VsZWN0b3IpWyAwIF07XG5cbiAgYnV0dG9uLnNldEF0dHJpYnV0ZSgnYXJpYS1leHBhbmRlZCcsIGZhbHNlKTtcbiAgY29udGVudC5zZXRBdHRyaWJ1dGUoJ2FyaWEtaGlkZGVuJywgdHJ1ZSk7XG4gIHJldHVybiB0aGlzO1xufTtcblxuLyoqXG4gKiBAcGFyYW0ge0hUTUxFbGVtZW50fSBidXR0b25cbiAqIEByZXR1cm4ge0FjY29yZGlvbn1cbiAqL1xuQWNjb3JkaW9uLnByb3RvdHlwZS5zaG93ID0gZnVuY3Rpb24gKGJ1dHRvbikge1xuICB2YXIgc2VsZWN0b3IgPSBidXR0b24uZ2V0QXR0cmlidXRlKCdhcmlhLWNvbnRyb2xzJyksXG4gICAgY29udGVudCA9IHRoaXMuJCgnIycgKyBzZWxlY3RvcilbIDAgXTtcblxuICBidXR0b24uc2V0QXR0cmlidXRlKCdhcmlhLWV4cGFuZGVkJywgdHJ1ZSk7XG4gIGNvbnRlbnQuc2V0QXR0cmlidXRlKCdhcmlhLWhpZGRlbicsIGZhbHNlKTtcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG5BY2NvcmRpb24ucHJvdG90eXBlLmhpZGVBbGwgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgdmFyIGJ1dHRvbnMgPSB0aGlzLiQoJ3VsID4gbGkgPiBidXR0b24sIC51c2EtYWNjb3JkaW9uLWJ1dHRvbicpO1xuICBidXR0b25zLmZvckVhY2goZnVuY3Rpb24gKGJ1dHRvbikge1xuICAgIHNlbGYuaGlkZShidXR0b24pO1xuICB9KTtcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IEFjY29yZGlvbjtcbi8vIC0tLS0tLS0tLS0tRW5kIEFjY29yZGlvbiBKUyAtLS0tLS0tLS0tLS0tIC8vIiwiXG4vKipcbipcbiogIEJhc2U2NCBlbmNvZGUgLyBkZWNvZGVcbiogIGh0dHA6Ly93d3cud2VidG9vbGtpdC5pbmZvL1xuKlxuKiovXG5cbnZhciBCYXNlNjQgPSB7XG5cblx0Ly8gcHJpdmF0ZSBwcm9wZXJ0eVxuXHRfa2V5U3RyIDogXCJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvPVwiLFxuXG5cdC8vIHB1YmxpYyBtZXRob2QgZm9yIGVuY29kaW5nXG5cdGVuY29kZSA6IGZ1bmN0aW9uIChpbnB1dCkge1xuXHRcdHZhciBvdXRwdXQgPSBcIlwiO1xuXHRcdHZhciBjaHIxLCBjaHIyLCBjaHIzLCBlbmMxLCBlbmMyLCBlbmMzLCBlbmM0O1xuXHRcdHZhciBpID0gMDtcblxuXHRcdGlucHV0ID0gQmFzZTY0Ll91dGY4X2VuY29kZShpbnB1dCk7XG5cblx0XHR3aGlsZSAoaSA8IGlucHV0Lmxlbmd0aCkge1xuXG5cdFx0XHRjaHIxID0gaW5wdXQuY2hhckNvZGVBdChpKyspO1xuXHRcdFx0Y2hyMiA9IGlucHV0LmNoYXJDb2RlQXQoaSsrKTtcblx0XHRcdGNocjMgPSBpbnB1dC5jaGFyQ29kZUF0KGkrKyk7XG5cblx0XHRcdGVuYzEgPSBjaHIxID4+IDI7XG5cdFx0XHRlbmMyID0gKChjaHIxICYgMykgPDwgNCkgfCAoY2hyMiA+PiA0KTtcblx0XHRcdGVuYzMgPSAoKGNocjIgJiAxNSkgPDwgMikgfCAoY2hyMyA+PiA2KTtcblx0XHRcdGVuYzQgPSBjaHIzICYgNjM7XG5cblx0XHRcdGlmIChpc05hTihjaHIyKSkge1xuXHRcdFx0XHRlbmMzID0gZW5jNCA9IDY0O1xuXHRcdFx0fSBlbHNlIGlmIChpc05hTihjaHIzKSkge1xuXHRcdFx0XHRlbmM0ID0gNjQ7XG5cdFx0XHR9XG5cblx0XHRcdG91dHB1dCA9IG91dHB1dCArXG5cdFx0XHR0aGlzLl9rZXlTdHIuY2hhckF0KGVuYzEpICsgdGhpcy5fa2V5U3RyLmNoYXJBdChlbmMyKSArXG5cdFx0XHR0aGlzLl9rZXlTdHIuY2hhckF0KGVuYzMpICsgdGhpcy5fa2V5U3RyLmNoYXJBdChlbmM0KTtcblxuXHRcdH1cblxuXHRcdHJldHVybiBvdXRwdXQ7XG5cdH0sXG5cblx0Ly8gcHVibGljIG1ldGhvZCBmb3IgZGVjb2Rpbmdcblx0ZGVjb2RlIDogZnVuY3Rpb24gKGlucHV0KSB7XG5cdFx0dmFyIG91dHB1dCA9IFwiXCI7XG5cdFx0dmFyIGNocjEsIGNocjIsIGNocjM7XG5cdFx0dmFyIGVuYzEsIGVuYzIsIGVuYzMsIGVuYzQ7XG5cdFx0dmFyIGkgPSAwO1xuXG5cdFx0aW5wdXQgPSBpbnB1dC5yZXBsYWNlKC9bXkEtWmEtejAtOVxcK1xcL1xcPV0vZywgXCJcIik7XG5cblx0XHR3aGlsZSAoaSA8IGlucHV0Lmxlbmd0aCkge1xuXG5cdFx0XHRlbmMxID0gdGhpcy5fa2V5U3RyLmluZGV4T2YoaW5wdXQuY2hhckF0KGkrKykpO1xuXHRcdFx0ZW5jMiA9IHRoaXMuX2tleVN0ci5pbmRleE9mKGlucHV0LmNoYXJBdChpKyspKTtcblx0XHRcdGVuYzMgPSB0aGlzLl9rZXlTdHIuaW5kZXhPZihpbnB1dC5jaGFyQXQoaSsrKSk7XG5cdFx0XHRlbmM0ID0gdGhpcy5fa2V5U3RyLmluZGV4T2YoaW5wdXQuY2hhckF0KGkrKykpO1xuXG5cdFx0XHRjaHIxID0gKGVuYzEgPDwgMikgfCAoZW5jMiA+PiA0KTtcblx0XHRcdGNocjIgPSAoKGVuYzIgJiAxNSkgPDwgNCkgfCAoZW5jMyA+PiAyKTtcblx0XHRcdGNocjMgPSAoKGVuYzMgJiAzKSA8PCA2KSB8IGVuYzQ7XG5cblx0XHRcdG91dHB1dCA9IG91dHB1dCArIFN0cmluZy5mcm9tQ2hhckNvZGUoY2hyMSk7XG5cblx0XHRcdGlmIChlbmMzICE9IDY0KSB7XG5cdFx0XHRcdG91dHB1dCA9IG91dHB1dCArIFN0cmluZy5mcm9tQ2hhckNvZGUoY2hyMik7XG5cdFx0XHR9XG5cdFx0XHRpZiAoZW5jNCAhPSA2NCkge1xuXHRcdFx0XHRvdXRwdXQgPSBvdXRwdXQgKyBTdHJpbmcuZnJvbUNoYXJDb2RlKGNocjMpO1xuXHRcdFx0fVxuXG5cdFx0fVxuXG5cdFx0b3V0cHV0ID0gQmFzZTY0Ll91dGY4X2RlY29kZShvdXRwdXQpO1xuXG5cdFx0cmV0dXJuIG91dHB1dDtcblxuXHR9LFxuXG5cdC8vIHByaXZhdGUgbWV0aG9kIGZvciBVVEYtOCBlbmNvZGluZ1xuXHRfdXRmOF9lbmNvZGUgOiBmdW5jdGlvbiAoc3RyaW5nKSB7XG5cdFx0c3RyaW5nID0gc3RyaW5nLnJlcGxhY2UoL1xcclxcbi9nLFwiXFxuXCIpO1xuXHRcdHZhciB1dGZ0ZXh0ID0gXCJcIjtcblxuXHRcdGZvciAodmFyIG4gPSAwOyBuIDwgc3RyaW5nLmxlbmd0aDsgbisrKSB7XG5cblx0XHRcdHZhciBjID0gc3RyaW5nLmNoYXJDb2RlQXQobik7XG5cblx0XHRcdGlmIChjIDwgMTI4KSB7XG5cdFx0XHRcdHV0ZnRleHQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShjKTtcblx0XHRcdH1cblx0XHRcdGVsc2UgaWYoKGMgPiAxMjcpICYmIChjIDwgMjA0OCkpIHtcblx0XHRcdFx0dXRmdGV4dCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKChjID4+IDYpIHwgMTkyKTtcblx0XHRcdFx0dXRmdGV4dCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKChjICYgNjMpIHwgMTI4KTtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHR1dGZ0ZXh0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoKGMgPj4gMTIpIHwgMjI0KTtcblx0XHRcdFx0dXRmdGV4dCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKCgoYyA+PiA2KSAmIDYzKSB8IDEyOCk7XG5cdFx0XHRcdHV0ZnRleHQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZSgoYyAmIDYzKSB8IDEyOCk7XG5cdFx0XHR9XG5cblx0XHR9XG5cblx0XHRyZXR1cm4gdXRmdGV4dDtcblx0fSxcblxuXHQvLyBwcml2YXRlIG1ldGhvZCBmb3IgVVRGLTggZGVjb2Rpbmdcblx0X3V0ZjhfZGVjb2RlIDogZnVuY3Rpb24gKHV0ZnRleHQpIHtcblx0XHR2YXIgc3RyaW5nID0gXCJcIjtcblx0XHR2YXIgaSA9IDA7XG5cdFx0dmFyIGMgPSBjMSA9IGMyID0gMDtcblxuXHRcdHdoaWxlICggaSA8IHV0ZnRleHQubGVuZ3RoICkge1xuXG5cdFx0XHRjID0gdXRmdGV4dC5jaGFyQ29kZUF0KGkpO1xuXG5cdFx0XHRpZiAoYyA8IDEyOCkge1xuXHRcdFx0XHRzdHJpbmcgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShjKTtcblx0XHRcdFx0aSsrO1xuXHRcdFx0fVxuXHRcdFx0ZWxzZSBpZigoYyA+IDE5MSkgJiYgKGMgPCAyMjQpKSB7XG5cdFx0XHRcdGMyID0gdXRmdGV4dC5jaGFyQ29kZUF0KGkrMSk7XG5cdFx0XHRcdHN0cmluZyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKCgoYyAmIDMxKSA8PCA2KSB8IChjMiAmIDYzKSk7XG5cdFx0XHRcdGkgKz0gMjtcblx0XHRcdH1cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRjMiA9IHV0ZnRleHQuY2hhckNvZGVBdChpKzEpO1xuXHRcdFx0XHRjMyA9IHV0ZnRleHQuY2hhckNvZGVBdChpKzIpO1xuXHRcdFx0XHRzdHJpbmcgKz0gU3RyaW5nLmZyb21DaGFyQ29kZSgoKGMgJiAxNSkgPDwgMTIpIHwgKChjMiAmIDYzKSA8PCA2KSB8IChjMyAmIDYzKSk7XG5cdFx0XHRcdGkgKz0gMztcblx0XHRcdH1cblxuXHRcdH1cblxuXHRcdHJldHVybiBzdHJpbmc7XG5cdH1cblxufVxuIiwiLy8gLS0tLS0tLS0tLS1CZWdpbiBCdXR0b24gSlMgLS0tLS0tLS0tLS0tLSAvL1xuK2Z1bmN0aW9uICgkKSB7XG4gICd1c2Ugc3RyaWN0JztcblxuICAvLyBCVVRUT04gUFVCTElDIENMQVNTIERFRklOSVRJT05cbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbiAgdmFyIEJ1dHRvbiA9IGZ1bmN0aW9uIChlbGVtZW50LCBvcHRpb25zKSB7XG4gICAgdGhpcy4kZWxlbWVudCAgPSAkKGVsZW1lbnQpXG4gICAgdGhpcy5vcHRpb25zICAgPSAkLmV4dGVuZCh7fSwgQnV0dG9uLkRFRkFVTFRTLCBvcHRpb25zKVxuICAgIHRoaXMuaXNMb2FkaW5nID0gZmFsc2VcbiAgfVxuXG4gIEJ1dHRvbi5WRVJTSU9OICA9ICcxLjAuMCdcblxuICBCdXR0b24uREVGQVVMVFMgPSB7XG4gICAgbG9hZGluZ1RleHQ6ICdsb2FkaW5nLi4uJ1xuICB9XG5cbiAgQnV0dG9uLnByb3RvdHlwZS5zZXRTdGF0ZSA9IGZ1bmN0aW9uIChzdGF0ZSkge1xuICAgIHZhciBkICAgID0gJ2Rpc2FibGVkJ1xuICAgIHZhciAkZWwgID0gdGhpcy4kZWxlbWVudFxuICAgIHZhciB2YWwgID0gJGVsLmlzKCdpbnB1dCcpID8gJ3ZhbCcgOiAnaHRtbCdcbiAgICB2YXIgZGF0YSA9ICRlbC5kYXRhKClcblxuICAgIHN0YXRlICs9ICdUZXh0J1xuXG4gICAgaWYgKGRhdGEucmVzZXRUZXh0ID09IG51bGwpICRlbC5kYXRhKCdyZXNldFRleHQnLCAkZWxbdmFsXSgpKVxuXG4gICAgLy8gcHVzaCB0byBldmVudCBsb29wIHRvIGFsbG93IGZvcm1zIHRvIHN1Ym1pdFxuICAgIHNldFRpbWVvdXQoJC5wcm94eShmdW5jdGlvbiAoKSB7XG4gICAgICAkZWxbdmFsXShkYXRhW3N0YXRlXSA9PSBudWxsID8gdGhpcy5vcHRpb25zW3N0YXRlXSA6IGRhdGFbc3RhdGVdKVxuXG4gICAgICBpZiAoc3RhdGUgPT0gJ2xvYWRpbmdUZXh0Jykge1xuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IHRydWVcbiAgICAgICAgJGVsLmFkZENsYXNzKGQpLmF0dHIoZCwgZCkucHJvcChkLCB0cnVlKVxuICAgICAgfSBlbHNlIGlmICh0aGlzLmlzTG9hZGluZykge1xuICAgICAgICB0aGlzLmlzTG9hZGluZyA9IGZhbHNlXG4gICAgICAgICRlbC5yZW1vdmVDbGFzcyhkKS5yZW1vdmVBdHRyKGQpLnByb3AoZCwgZmFsc2UpXG4gICAgICB9XG4gICAgfSwgdGhpcyksIDApXG4gIH1cblxuICBCdXR0b24ucHJvdG90eXBlLnRvZ2dsZSA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgY2hhbmdlZCA9IHRydWVcbiAgICB2YXIgJHBhcmVudCA9IHRoaXMuJGVsZW1lbnQuY2xvc2VzdCgnW2RhdGEtdG9nZ2xlPVwiYnV0dG9uc1wiXScpXG5cbiAgICBpZiAoJHBhcmVudC5sZW5ndGgpIHtcbiAgICAgIHZhciAkaW5wdXQgPSB0aGlzLiRlbGVtZW50LmZpbmQoJ2lucHV0JylcbiAgICAgIGlmICgkaW5wdXQucHJvcCgndHlwZScpID09ICdyYWRpbycpIHtcbiAgICAgICAgaWYgKCRpbnB1dC5wcm9wKCdjaGVja2VkJykpIGNoYW5nZWQgPSBmYWxzZVxuICAgICAgICAkcGFyZW50LmZpbmQoJy5hY3RpdmUnKS5yZW1vdmVDbGFzcygnYWN0aXZlJylcbiAgICAgICAgdGhpcy4kZWxlbWVudC5hZGRDbGFzcygnYWN0aXZlJylcbiAgICAgIH0gZWxzZSBpZiAoJGlucHV0LnByb3AoJ3R5cGUnKSA9PSAnY2hlY2tib3gnKSB7XG4gICAgICAgIGlmICgoJGlucHV0LnByb3AoJ2NoZWNrZWQnKSkgIT09IHRoaXMuJGVsZW1lbnQuaGFzQ2xhc3MoJ2FjdGl2ZScpKSBjaGFuZ2VkID0gZmFsc2VcbiAgICAgICAgdGhpcy4kZWxlbWVudC50b2dnbGVDbGFzcygnYWN0aXZlJylcbiAgICAgIH1cbiAgICAgICRpbnB1dC5wcm9wKCdjaGVja2VkJywgdGhpcy4kZWxlbWVudC5oYXNDbGFzcygnYWN0aXZlJykpXG4gICAgICBpZiAoY2hhbmdlZCkgJGlucHV0LnRyaWdnZXIoJ2NoYW5nZScpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuJGVsZW1lbnQuYXR0cignYXJpYS1wcmVzc2VkJywgIXRoaXMuJGVsZW1lbnQuaGFzQ2xhc3MoJ2FjdGl2ZScpKVxuICAgICAgdGhpcy4kZWxlbWVudC50b2dnbGVDbGFzcygnYWN0aXZlJylcbiAgICB9XG4gIH1cblxuXG4gIC8vIEJVVFRPTiBQTFVHSU4gREVGSU5JVElPTlxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT1cblxuICBmdW5jdGlvbiBQbHVnaW4ob3B0aW9uKSB7XG4gICAgcmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgJHRoaXMgICA9ICQodGhpcylcbiAgICAgIHZhciBkYXRhICAgID0gJHRoaXMuZGF0YSgnYnMuYnV0dG9uJylcbiAgICAgIHZhciBvcHRpb25zID0gdHlwZW9mIG9wdGlvbiA9PSAnb2JqZWN0JyAmJiBvcHRpb25cblxuICAgICAgaWYgKCFkYXRhKSAkdGhpcy5kYXRhKCdicy5idXR0b24nLCAoZGF0YSA9IG5ldyBCdXR0b24odGhpcywgb3B0aW9ucykpKVxuXG4gICAgICBpZiAob3B0aW9uID09ICd0b2dnbGUnKSBkYXRhLnRvZ2dsZSgpXG4gICAgICBlbHNlIGlmIChvcHRpb24pIGRhdGEuc2V0U3RhdGUob3B0aW9uKVxuICAgIH0pXG4gIH1cblxuICB2YXIgb2xkID0gJC5mbi5idXR0b25cblxuICAkLmZuLmJ1dHRvbiAgICAgICAgICAgICA9IFBsdWdpblxuICAkLmZuLmJ1dHRvbi5Db25zdHJ1Y3RvciA9IEJ1dHRvblxuXG5cbiAgLy8gQlVUVE9OIE5PIENPTkZMSUNUXG4gIC8vID09PT09PT09PT09PT09PT09PVxuXG4gICQuZm4uYnV0dG9uLm5vQ29uZmxpY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgJC5mbi5idXR0b24gPSBvbGRcbiAgICByZXR1cm4gdGhpc1xuICB9XG5cblxuICAvLyBCVVRUT04gREFUQS1BUElcbiAgLy8gPT09PT09PT09PT09PT09XG5cbiAgJChkb2N1bWVudClcbiAgICAub24oJ2NsaWNrLmJzLmJ1dHRvbi5kYXRhLWFwaScsICdbZGF0YS10b2dnbGVePVwiYnV0dG9uXCJdJywgZnVuY3Rpb24gKGUpIHtcbiAgICAgIHZhciAkYnRuID0gJChlLnRhcmdldCkuY2xvc2VzdCgnLmJ0bicpXG4gICAgICBQbHVnaW4uY2FsbCgkYnRuLCAndG9nZ2xlJylcbiAgICAgIGlmICghKCQoZS50YXJnZXQpLmlzKCdpbnB1dFt0eXBlPVwicmFkaW9cIl0sIGlucHV0W3R5cGU9XCJjaGVja2JveFwiXScpKSkge1xuICAgICAgICAvLyBQcmV2ZW50IGRvdWJsZSBjbGljayBvbiByYWRpb3MsIGFuZCB0aGUgZG91YmxlIHNlbGVjdGlvbnMgKHNvIGNhbmNlbGxhdGlvbikgb24gY2hlY2tib3hlc1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgLy8gVGhlIHRhcmdldCBjb21wb25lbnQgc3RpbGwgcmVjZWl2ZSB0aGUgZm9jdXNcbiAgICAgICAgaWYgKCRidG4uaXMoJ2lucHV0LGJ1dHRvbicpKSAkYnRuLnRyaWdnZXIoJ2ZvY3VzJylcbiAgICAgICAgZWxzZSAkYnRuLmZpbmQoJ2lucHV0OnZpc2libGUsYnV0dG9uOnZpc2libGUnKS5maXJzdCgpLnRyaWdnZXIoJ2ZvY3VzJylcbiAgICAgIH1cbiAgICB9KVxuICAgIC5vbignZm9jdXMuYnMuYnV0dG9uLmRhdGEtYXBpIGJsdXIuYnMuYnV0dG9uLmRhdGEtYXBpJywgJ1tkYXRhLXRvZ2dsZV49XCJidXR0b25cIl0nLCBmdW5jdGlvbiAoZSkge1xuICAgICAgJChlLnRhcmdldCkuY2xvc2VzdCgnLmJ0bicpLnRvZ2dsZUNsYXNzKCdmb2N1cycsIC9eZm9jdXMoaW4pPyQvLnRlc3QoZS50eXBlKSlcbiAgICB9KVxuXG59KGpRdWVyeSk7XG4iLCIvLyAtLS0tLS0tLS0tLUJlZ2luIENhcmQgSlMgLS0tLS0tLS0tLS0tLSAvL1xudmFyIHNjcmVlbldpZHRoID0gNzY4O1xuLy8gRXF1YWwgaGlnaHQgZm9yIGNhcmRcbmlmICgkKHdpbmRvdykud2lkdGgoKSA+IHNjcmVlbldpZHRoKSB7XG4gICAgZnVuY3Rpb24gZXF1YWxIZWlnaHQoZ3JvdXApIHtcbiAgICAgICAgdGFsbGVzdCA9IDA7XG4gICAgICAgIHZhciBteVNlbGVjdGVyID0gZ3JvdXAuc2VsZWN0b3I7XG4gICAgICAgICQobXlTZWxlY3RlcikuY2xvc2VzdChcIi5scF9fY2FyZC1zZWN0aW9uXCIpLmVhY2goZnVuY3Rpb24oaW5kZXgsIHRoaXNHcm91cCkge1xuICAgICAgICAgICAgdmFyIHNlbGVjdGVkQ29udGFpbmVyID0gJCh0aGlzR3JvdXApLmZpbmQobXlTZWxlY3Rlcik7XG4gICAgICAgICAgICBzZWxlY3RlZENvbnRhaW5lci5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHRoaXNIZWlnaHQgPSAkKHRoaXMpLmhlaWdodCgpO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzSGVpZ2h0ID4gdGFsbGVzdCkge1xuICAgICAgICAgICAgICAgICAgICB0YWxsZXN0ID0gdGhpc0hlaWdodDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHNlbGVjdGVkQ29udGFpbmVyLmhlaWdodCh0YWxsZXN0KTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgICQod2luZG93KS5sb2FkKGZ1bmN0aW9uKCkge1xuICAgICAgICBlcXVhbEhlaWdodCgkKFwiLmxvb3BfY2FyZF9waG90b190aXRsZV90ZXh0IC5scF9fY2FyZF93cmFwcGVyXCIpKTsgXG4gICAgICAgIGVxdWFsSGVpZ2h0KCQoXCIubG9vcF9jYXJkX3Bob3RvX3RpdGxlX3RleHRfbGlua3MgLmxwX19jYXJkX3dyYXBwZXJcIikpOyAgIFxuICAgICAgICBlcXVhbEhlaWdodCgkKFwiLmxvb3BfY2FyZF9oYW1tZXJfdGl0bGUgLmxwX19jYXJkX3dyYXBwZXJcIikpOyAgICBcbiAgICB9KTtcbn1cbi8vIC0tLS0tLS0tLS0tRW5kIENhcmQgSlMgLS0tLS0tLS0tLS0tLSAvLyIsIi8qID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuICogQm9vdHN0cmFwOiBjb2xsYXBzZS5qcyB2My4zLjdcbiAqIGh0dHA6Ly9nZXRib290c3RyYXAuY29tL2phdmFzY3JpcHQvI2NvbGxhcHNlXG4gKiA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAqIENvcHlyaWdodCAyMDExLTIwMTYgVHdpdHRlciwgSW5jLlxuICogTGljZW5zZWQgdW5kZXIgTUlUIChodHRwczovL2dpdGh1Yi5jb20vdHdicy9ib290c3RyYXAvYmxvYi9tYXN0ZXIvTElDRU5TRSlcbiAqID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL1xuXG4vKiBqc2hpbnQgbGF0ZWRlZjogZmFsc2UgKi9cblxuK2Z1bmN0aW9uICgkKSB7XG4gICd1c2Ugc3RyaWN0JztcblxuICAvLyBDT0xMQVBTRSBQVUJMSUMgQ0xBU1MgREVGSU5JVElPTlxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG4gIHZhciBDb2xsYXBzZSA9IGZ1bmN0aW9uIChlbGVtZW50LCBvcHRpb25zKSB7XG4gICAgdGhpcy4kZWxlbWVudCAgICAgID0gJChlbGVtZW50KVxuICAgIHRoaXMub3B0aW9ucyAgICAgICA9ICQuZXh0ZW5kKHt9LCBDb2xsYXBzZS5ERUZBVUxUUywgb3B0aW9ucylcbiAgICB0aGlzLiR0cmlnZ2VyICAgICAgPSAkKCdbZGF0YS10b2dnbGU9XCJjb2xsYXBzZVwiXVtocmVmPVwiIycgKyBlbGVtZW50LmlkICsgJ1wiXSwnICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICdbZGF0YS10b2dnbGU9XCJjb2xsYXBzZVwiXVtkYXRhLXRhcmdldD1cIiMnICsgZWxlbWVudC5pZCArICdcIl0nKVxuICAgIHRoaXMudHJhbnNpdGlvbmluZyA9IG51bGxcblxuICAgIGlmICh0aGlzLm9wdGlvbnMucGFyZW50KSB7XG4gICAgICB0aGlzLiRwYXJlbnQgPSB0aGlzLmdldFBhcmVudCgpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuYWRkQXJpYUFuZENvbGxhcHNlZENsYXNzKHRoaXMuJGVsZW1lbnQsIHRoaXMuJHRyaWdnZXIpXG4gICAgfVxuXG4gICAgaWYgKHRoaXMub3B0aW9ucy50b2dnbGUpIHRoaXMudG9nZ2xlKClcbiAgfVxuXG4gIENvbGxhcHNlLlZFUlNJT04gID0gJzMuMy43J1xuXG4gIENvbGxhcHNlLlRSQU5TSVRJT05fRFVSQVRJT04gPSAzNTBcblxuICBDb2xsYXBzZS5ERUZBVUxUUyA9IHtcbiAgICB0b2dnbGU6IHRydWVcbiAgfVxuXG4gIENvbGxhcHNlLnByb3RvdHlwZS5kaW1lbnNpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGhhc1dpZHRoID0gdGhpcy4kZWxlbWVudC5oYXNDbGFzcygnd2lkdGgnKVxuICAgIHJldHVybiBoYXNXaWR0aCA/ICd3aWR0aCcgOiAnaGVpZ2h0J1xuICB9XG5cbiAgQ29sbGFwc2UucHJvdG90eXBlLnNob3cgPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKHRoaXMudHJhbnNpdGlvbmluZyB8fCB0aGlzLiRlbGVtZW50Lmhhc0NsYXNzKCdpbicpKSByZXR1cm5cblxuICAgIHZhciBhY3RpdmVzRGF0YVxuICAgIHZhciBhY3RpdmVzID0gdGhpcy4kcGFyZW50ICYmIHRoaXMuJHBhcmVudC5jaGlsZHJlbignLnBhbmVsJykuY2hpbGRyZW4oJy5pbiwgLmNvbGxhcHNpbmcnKVxuXG4gICAgaWYgKGFjdGl2ZXMgJiYgYWN0aXZlcy5sZW5ndGgpIHtcbiAgICAgIGFjdGl2ZXNEYXRhID0gYWN0aXZlcy5kYXRhKCdicy5jb2xsYXBzZScpXG4gICAgICBpZiAoYWN0aXZlc0RhdGEgJiYgYWN0aXZlc0RhdGEudHJhbnNpdGlvbmluZykgcmV0dXJuXG4gICAgfVxuXG4gICAgdmFyIHN0YXJ0RXZlbnQgPSAkLkV2ZW50KCdzaG93LmJzLmNvbGxhcHNlJylcbiAgICB0aGlzLiRlbGVtZW50LnRyaWdnZXIoc3RhcnRFdmVudClcbiAgICBpZiAoc3RhcnRFdmVudC5pc0RlZmF1bHRQcmV2ZW50ZWQoKSkgcmV0dXJuXG5cbiAgICBpZiAoYWN0aXZlcyAmJiBhY3RpdmVzLmxlbmd0aCkge1xuICAgICAgUGx1Z2luLmNhbGwoYWN0aXZlcywgJ2hpZGUnKVxuICAgICAgYWN0aXZlc0RhdGEgfHwgYWN0aXZlcy5kYXRhKCdicy5jb2xsYXBzZScsIG51bGwpXG4gICAgfVxuXG4gICAgdmFyIGRpbWVuc2lvbiA9IHRoaXMuZGltZW5zaW9uKClcblxuICAgIHRoaXMuJGVsZW1lbnRcbiAgICAgIC5yZW1vdmVDbGFzcygnY29sbGFwc2UnKVxuICAgICAgLmFkZENsYXNzKCdjb2xsYXBzaW5nJylbZGltZW5zaW9uXSgwKVxuICAgICAgLmF0dHIoJ2FyaWEtZXhwYW5kZWQnLCB0cnVlKVxuXG4gICAgdGhpcy4kdHJpZ2dlclxuICAgICAgLnJlbW92ZUNsYXNzKCdjb2xsYXBzZWQnKVxuICAgICAgLmF0dHIoJ2FyaWEtZXhwYW5kZWQnLCB0cnVlKVxuXG4gICAgdGhpcy50cmFuc2l0aW9uaW5nID0gMVxuXG4gICAgdmFyIGNvbXBsZXRlID0gZnVuY3Rpb24gKCkge1xuICAgICAgdGhpcy4kZWxlbWVudFxuICAgICAgICAucmVtb3ZlQ2xhc3MoJ2NvbGxhcHNpbmcnKVxuICAgICAgICAuYWRkQ2xhc3MoJ2NvbGxhcHNlIGluJylbZGltZW5zaW9uXSgnJylcbiAgICAgIHRoaXMudHJhbnNpdGlvbmluZyA9IDBcbiAgICAgIHRoaXMuJGVsZW1lbnRcbiAgICAgICAgLnRyaWdnZXIoJ3Nob3duLmJzLmNvbGxhcHNlJylcbiAgICB9XG5cbiAgICBpZiAoISQuc3VwcG9ydC50cmFuc2l0aW9uKSByZXR1cm4gY29tcGxldGUuY2FsbCh0aGlzKVxuXG4gICAgdmFyIHNjcm9sbFNpemUgPSAkLmNhbWVsQ2FzZShbJ3Njcm9sbCcsIGRpbWVuc2lvbl0uam9pbignLScpKVxuXG4gICAgdGhpcy4kZWxlbWVudFxuICAgICAgLm9uZSgnYnNUcmFuc2l0aW9uRW5kJywgJC5wcm94eShjb21wbGV0ZSwgdGhpcykpXG4gICAgICAuZW11bGF0ZVRyYW5zaXRpb25FbmQoQ29sbGFwc2UuVFJBTlNJVElPTl9EVVJBVElPTilbZGltZW5zaW9uXSh0aGlzLiRlbGVtZW50WzBdW3Njcm9sbFNpemVdKVxuICB9XG5cbiAgQ29sbGFwc2UucHJvdG90eXBlLmhpZGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKHRoaXMudHJhbnNpdGlvbmluZyB8fCAhdGhpcy4kZWxlbWVudC5oYXNDbGFzcygnaW4nKSkgcmV0dXJuXG5cbiAgICB2YXIgc3RhcnRFdmVudCA9ICQuRXZlbnQoJ2hpZGUuYnMuY29sbGFwc2UnKVxuICAgIHRoaXMuJGVsZW1lbnQudHJpZ2dlcihzdGFydEV2ZW50KVxuICAgIGlmIChzdGFydEV2ZW50LmlzRGVmYXVsdFByZXZlbnRlZCgpKSByZXR1cm5cblxuICAgIHZhciBkaW1lbnNpb24gPSB0aGlzLmRpbWVuc2lvbigpXG5cbiAgICB0aGlzLiRlbGVtZW50W2RpbWVuc2lvbl0odGhpcy4kZWxlbWVudFtkaW1lbnNpb25dKCkpWzBdLm9mZnNldEhlaWdodFxuXG4gICAgdGhpcy4kZWxlbWVudFxuICAgICAgLmFkZENsYXNzKCdjb2xsYXBzaW5nJylcbiAgICAgIC5yZW1vdmVDbGFzcygnY29sbGFwc2UgaW4nKVxuICAgICAgLmF0dHIoJ2FyaWEtZXhwYW5kZWQnLCBmYWxzZSlcblxuICAgIHRoaXMuJHRyaWdnZXJcbiAgICAgIC5hZGRDbGFzcygnY29sbGFwc2VkJylcbiAgICAgIC5hdHRyKCdhcmlhLWV4cGFuZGVkJywgZmFsc2UpXG5cbiAgICB0aGlzLnRyYW5zaXRpb25pbmcgPSAxXG5cbiAgICB2YXIgY29tcGxldGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICB0aGlzLnRyYW5zaXRpb25pbmcgPSAwXG4gICAgICB0aGlzLiRlbGVtZW50XG4gICAgICAgIC5yZW1vdmVDbGFzcygnY29sbGFwc2luZycpXG4gICAgICAgIC5hZGRDbGFzcygnY29sbGFwc2UnKVxuICAgICAgICAudHJpZ2dlcignaGlkZGVuLmJzLmNvbGxhcHNlJylcbiAgICB9XG5cbiAgICBpZiAoISQuc3VwcG9ydC50cmFuc2l0aW9uKSByZXR1cm4gY29tcGxldGUuY2FsbCh0aGlzKVxuXG4gICAgdGhpcy4kZWxlbWVudFxuICAgICAgW2RpbWVuc2lvbl0oMClcbiAgICAgIC5vbmUoJ2JzVHJhbnNpdGlvbkVuZCcsICQucHJveHkoY29tcGxldGUsIHRoaXMpKVxuICAgICAgLmVtdWxhdGVUcmFuc2l0aW9uRW5kKENvbGxhcHNlLlRSQU5TSVRJT05fRFVSQVRJT04pXG4gIH1cblxuICBDb2xsYXBzZS5wcm90b3R5cGUudG9nZ2xlID0gZnVuY3Rpb24gKCkge1xuICAgIHRoaXNbdGhpcy4kZWxlbWVudC5oYXNDbGFzcygnaW4nKSA/ICdoaWRlJyA6ICdzaG93J10oKVxuICB9XG5cbiAgQ29sbGFwc2UucHJvdG90eXBlLmdldFBhcmVudCA9IGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gJCh0aGlzLm9wdGlvbnMucGFyZW50KVxuICAgICAgLmZpbmQoJ1tkYXRhLXRvZ2dsZT1cImNvbGxhcHNlXCJdW2RhdGEtcGFyZW50PVwiJyArIHRoaXMub3B0aW9ucy5wYXJlbnQgKyAnXCJdJylcbiAgICAgIC5lYWNoKCQucHJveHkoZnVuY3Rpb24gKGksIGVsZW1lbnQpIHtcbiAgICAgICAgdmFyICRlbGVtZW50ID0gJChlbGVtZW50KVxuICAgICAgICB0aGlzLmFkZEFyaWFBbmRDb2xsYXBzZWRDbGFzcyhnZXRUYXJnZXRGcm9tVHJpZ2dlcigkZWxlbWVudCksICRlbGVtZW50KVxuICAgICAgfSwgdGhpcykpXG4gICAgICAuZW5kKClcbiAgfVxuXG4gIENvbGxhcHNlLnByb3RvdHlwZS5hZGRBcmlhQW5kQ29sbGFwc2VkQ2xhc3MgPSBmdW5jdGlvbiAoJGVsZW1lbnQsICR0cmlnZ2VyKSB7XG4gICAgdmFyIGlzT3BlbiA9ICRlbGVtZW50Lmhhc0NsYXNzKCdpbicpXG5cbiAgICAkZWxlbWVudC5hdHRyKCdhcmlhLWV4cGFuZGVkJywgaXNPcGVuKVxuICAgICR0cmlnZ2VyXG4gICAgICAudG9nZ2xlQ2xhc3MoJ2NvbGxhcHNlZCcsICFpc09wZW4pXG4gICAgICAuYXR0cignYXJpYS1leHBhbmRlZCcsIGlzT3BlbilcbiAgfVxuXG4gIGZ1bmN0aW9uIGdldFRhcmdldEZyb21UcmlnZ2VyKCR0cmlnZ2VyKSB7XG4gICAgdmFyIGhyZWZcbiAgICB2YXIgdGFyZ2V0ID0gJHRyaWdnZXIuYXR0cignZGF0YS10YXJnZXQnKVxuICAgICAgfHwgKGhyZWYgPSAkdHJpZ2dlci5hdHRyKCdocmVmJykpICYmIGhyZWYucmVwbGFjZSgvLiooPz0jW15cXHNdKyQpLywgJycpIC8vIHN0cmlwIGZvciBpZTdcblxuICAgIHJldHVybiAkKHRhcmdldClcbiAgfVxuXG5cbiAgLy8gQ09MTEFQU0UgUExVR0lOIERFRklOSVRJT05cbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuICBmdW5jdGlvbiBQbHVnaW4ob3B0aW9uKSB7XG4gICAgcmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgJHRoaXMgICA9ICQodGhpcylcbiAgICAgIHZhciBkYXRhICAgID0gJHRoaXMuZGF0YSgnYnMuY29sbGFwc2UnKVxuICAgICAgdmFyIG9wdGlvbnMgPSAkLmV4dGVuZCh7fSwgQ29sbGFwc2UuREVGQVVMVFMsICR0aGlzLmRhdGEoKSwgdHlwZW9mIG9wdGlvbiA9PSAnb2JqZWN0JyAmJiBvcHRpb24pXG5cbiAgICAgIGlmICghZGF0YSAmJiBvcHRpb25zLnRvZ2dsZSAmJiAvc2hvd3xoaWRlLy50ZXN0KG9wdGlvbikpIG9wdGlvbnMudG9nZ2xlID0gZmFsc2VcbiAgICAgIGlmICghZGF0YSkgJHRoaXMuZGF0YSgnYnMuY29sbGFwc2UnLCAoZGF0YSA9IG5ldyBDb2xsYXBzZSh0aGlzLCBvcHRpb25zKSkpXG4gICAgICBpZiAodHlwZW9mIG9wdGlvbiA9PSAnc3RyaW5nJykgZGF0YVtvcHRpb25dKClcbiAgICB9KVxuICB9XG5cbiAgdmFyIG9sZCA9ICQuZm4uY29sbGFwc2VcblxuICAkLmZuLmNvbGxhcHNlICAgICAgICAgICAgID0gUGx1Z2luXG4gICQuZm4uY29sbGFwc2UuQ29uc3RydWN0b3IgPSBDb2xsYXBzZVxuXG5cbiAgLy8gQ09MTEFQU0UgTk8gQ09ORkxJQ1RcbiAgLy8gPT09PT09PT09PT09PT09PT09PT1cblxuICAkLmZuLmNvbGxhcHNlLm5vQ29uZmxpY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgJC5mbi5jb2xsYXBzZSA9IG9sZFxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuXG4gIC8vIENPTExBUFNFIERBVEEtQVBJXG4gIC8vID09PT09PT09PT09PT09PT09XG5cbiAgJChkb2N1bWVudCkub24oJ2NsaWNrLmJzLmNvbGxhcHNlLmRhdGEtYXBpJywgJ1tkYXRhLXRvZ2dsZT1cImNvbGxhcHNlXCJdJywgZnVuY3Rpb24gKGUpIHtcbiAgICB2YXIgJHRoaXMgICA9ICQodGhpcylcblxuICAgIGlmICghJHRoaXMuYXR0cignZGF0YS10YXJnZXQnKSkgZS5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICB2YXIgJHRhcmdldCA9IGdldFRhcmdldEZyb21UcmlnZ2VyKCR0aGlzKVxuICAgIHZhciBkYXRhICAgID0gJHRhcmdldC5kYXRhKCdicy5jb2xsYXBzZScpXG4gICAgdmFyIG9wdGlvbiAgPSBkYXRhID8gJ3RvZ2dsZScgOiAkdGhpcy5kYXRhKClcblxuICAgIFBsdWdpbi5jYWxsKCR0YXJnZXQsIG9wdGlvbilcbiAgfSlcblxufShqUXVlcnkpO1xuIiwiLy8gLS0tLS0tLS0tLS1CZWdpbiBEUk9QRE9XTiBKUyAtLS0tLS0tLS0tLS0tIC8vXG5cbitmdW5jdGlvbiAoJCkge1xuICAndXNlIHN0cmljdCc7XG5cbiAgdmFyIGJhY2tkcm9wID0gJy5kcm9wZG93bi1iYWNrZHJvcCdcbiAgdmFyIHRvZ2dsZSAgID0gJ1tkYXRhLXRvZ2dsZT1cImRyb3Bkb3duXCJdJ1xuICB2YXIgRHJvcGRvd24gPSBmdW5jdGlvbiAoZWxlbWVudCkge1xuICAgICQoZWxlbWVudCkub24oJ2NsaWNrLmRyb3Bkb3duJywgdGhpcy50b2dnbGUpXG4gIH1cblxuICBEcm9wZG93bi5WRVJTSU9OID0gJzEuMC4wJ1xuXG4gIGZ1bmN0aW9uIGdldFBhcmVudCgkdGhpcykge1xuICAgIHZhciBzZWxlY3RvciA9ICR0aGlzLmF0dHIoJ2RhdGEtdGFyZ2V0JylcblxuICAgIGlmICghc2VsZWN0b3IpIHtcbiAgICAgIHNlbGVjdG9yID0gJHRoaXMuYXR0cignaHJlZicpXG4gICAgICBzZWxlY3RvciA9IHNlbGVjdG9yICYmIC8jW0EtWmEtel0vLnRlc3Qoc2VsZWN0b3IpICYmIHNlbGVjdG9yLnJlcGxhY2UoLy4qKD89I1teXFxzXSokKS8sICcnKSAvLyBzdHJpcCBmb3IgaWU3XG4gICAgfVxuXG4gICAgdmFyICRwYXJlbnQgPSBzZWxlY3RvciAmJiAkKHNlbGVjdG9yKVxuXG4gICAgcmV0dXJuICRwYXJlbnQgJiYgJHBhcmVudC5sZW5ndGggPyAkcGFyZW50IDogJHRoaXMucGFyZW50KClcbiAgfVxuXG4gIGZ1bmN0aW9uIGNsZWFyTWVudXMoZSkge1xuICAgIGlmIChlICYmIGUud2hpY2ggPT09IDMpIHJldHVyblxuICAgICQoYmFja2Ryb3ApLnJlbW92ZSgpXG4gICAgJCh0b2dnbGUpLmVhY2goZnVuY3Rpb24gKCkge1xuICAgICAgdmFyICR0aGlzICAgICAgICAgPSAkKHRoaXMpXG4gICAgICB2YXIgJHBhcmVudCAgICAgICA9IGdldFBhcmVudCgkdGhpcylcbiAgICAgIHZhciByZWxhdGVkVGFyZ2V0ID0geyByZWxhdGVkVGFyZ2V0OiB0aGlzIH1cblxuICAgICAgaWYgKCEkcGFyZW50Lmhhc0NsYXNzKCdvcGVuJykpIHJldHVyblxuXG4gICAgICBpZiAoZSAmJiBlLnR5cGUgPT0gJ2NsaWNrJyAmJiAvaW5wdXR8dGV4dGFyZWEvaS50ZXN0KGUudGFyZ2V0LnRhZ05hbWUpICYmICQuY29udGFpbnMoJHBhcmVudFswXSwgZS50YXJnZXQpKSByZXR1cm5cblxuICAgICAgJHBhcmVudC50cmlnZ2VyKGUgPSAkLkV2ZW50KCdoaWRlLmRyb3Bkb3duJywgcmVsYXRlZFRhcmdldCkpXG5cbiAgICAgIGlmIChlLmlzRGVmYXVsdFByZXZlbnRlZCgpKSByZXR1cm5cblxuICAgICAgJHRoaXMuYXR0cignYXJpYS1leHBhbmRlZCcsICdmYWxzZScpXG4gICAgICAkcGFyZW50LnJlbW92ZUNsYXNzKCdvcGVuJykudHJpZ2dlcigkLkV2ZW50KCdoaWRkZW4uZHJvcGRvd24nLCByZWxhdGVkVGFyZ2V0KSlcbiAgICB9KVxuICB9XG5cbiAgRHJvcGRvd24ucHJvdG90eXBlLnRvZ2dsZSA9IGZ1bmN0aW9uIChlKSB7XG4gICAgdmFyICR0aGlzID0gJCh0aGlzKVxuXG4gICAgaWYgKCR0aGlzLmlzKCcuZGlzYWJsZWQsIDpkaXNhYmxlZCcpKSByZXR1cm5cblxuICAgIHZhciAkcGFyZW50ICA9IGdldFBhcmVudCgkdGhpcylcbiAgICB2YXIgaXNBY3RpdmUgPSAkcGFyZW50Lmhhc0NsYXNzKCdvcGVuJylcblxuICAgIGNsZWFyTWVudXMoKVxuXG4gICAgaWYgKCFpc0FjdGl2ZSkge1xuICAgICAgaWYgKCdvbnRvdWNoc3RhcnQnIGluIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCAmJiAhJHBhcmVudC5jbG9zZXN0KCcubmF2YmFyLW5hdicpLmxlbmd0aCkge1xuICAgICAgICAvLyBpZiBtb2JpbGUgd2UgdXNlIGEgYmFja2Ryb3AgYmVjYXVzZSBjbGljayBldmVudHMgZG9uJ3QgZGVsZWdhdGVcbiAgICAgICAgJChkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKSlcbiAgICAgICAgICAuYWRkQ2xhc3MoJ2Ryb3Bkb3duLWJhY2tkcm9wJylcbiAgICAgICAgICAuaW5zZXJ0QWZ0ZXIoJCh0aGlzKSlcbiAgICAgICAgICAub24oJ2NsaWNrJywgY2xlYXJNZW51cylcbiAgICAgIH1cblxuICAgICAgdmFyIHJlbGF0ZWRUYXJnZXQgPSB7IHJlbGF0ZWRUYXJnZXQ6IHRoaXMgfVxuICAgICAgJHBhcmVudC50cmlnZ2VyKGUgPSAkLkV2ZW50KCdzaG93LmRyb3Bkb3duJywgcmVsYXRlZFRhcmdldCkpXG5cbiAgICAgIGlmIChlLmlzRGVmYXVsdFByZXZlbnRlZCgpKSByZXR1cm5cblxuICAgICAgJHRoaXNcbiAgICAgICAgLnRyaWdnZXIoJ2ZvY3VzJylcbiAgICAgICAgLmF0dHIoJ2FyaWEtZXhwYW5kZWQnLCAndHJ1ZScpXG5cbiAgICAgICRwYXJlbnRcbiAgICAgICAgLnRvZ2dsZUNsYXNzKCdvcGVuJylcbiAgICAgICAgLnRyaWdnZXIoJC5FdmVudCgnc2hvd24uZHJvcGRvd24nLCByZWxhdGVkVGFyZ2V0KSlcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIERyb3Bkb3duLnByb3RvdHlwZS5rZXlkb3duID0gZnVuY3Rpb24gKGUpIHtcbiAgICBpZiAoIS8oMzh8NDB8Mjd8MzIpLy50ZXN0KGUud2hpY2gpIHx8IC9pbnB1dHx0ZXh0YXJlYS9pLnRlc3QoZS50YXJnZXQudGFnTmFtZSkpIHJldHVyblxuXG4gICAgdmFyICR0aGlzID0gJCh0aGlzKVxuXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKVxuXG4gICAgaWYgKCR0aGlzLmlzKCcuZGlzYWJsZWQsIDpkaXNhYmxlZCcpKSByZXR1cm5cblxuICAgIHZhciAkcGFyZW50ICA9IGdldFBhcmVudCgkdGhpcylcbiAgICB2YXIgaXNBY3RpdmUgPSAkcGFyZW50Lmhhc0NsYXNzKCdvcGVuJylcblxuICAgIGlmICghaXNBY3RpdmUgJiYgZS53aGljaCAhPSAyNyB8fCBpc0FjdGl2ZSAmJiBlLndoaWNoID09IDI3KSB7XG4gICAgICBpZiAoZS53aGljaCA9PSAyNykgJHBhcmVudC5maW5kKHRvZ2dsZSkudHJpZ2dlcignZm9jdXMnKVxuICAgICAgcmV0dXJuICR0aGlzLnRyaWdnZXIoJ2NsaWNrJylcbiAgICB9XG5cbiAgICB2YXIgZGVzYyA9ICcgbGk6bm90KC5kaXNhYmxlZCk6dmlzaWJsZSBhJ1xuICAgIHZhciAkaXRlbXMgPSAkcGFyZW50LmZpbmQoJy5scF9fZHJvcGRvd25fbWVudScgKyBkZXNjKVxuXG4gICAgaWYgKCEkaXRlbXMubGVuZ3RoKSByZXR1cm5cblxuICAgIHZhciBpbmRleCA9ICRpdGVtcy5pbmRleChlLnRhcmdldClcblxuICAgIGlmIChlLndoaWNoID09IDM4ICYmIGluZGV4ID4gMCkgICAgICAgICAgICAgICAgIGluZGV4LS0gICAgICAgICAvLyB1cFxuICAgIGlmIChlLndoaWNoID09IDQwICYmIGluZGV4IDwgJGl0ZW1zLmxlbmd0aCAtIDEpIGluZGV4KysgICAgICAgICAvLyBkb3duXG4gICAgaWYgKCF+aW5kZXgpICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXggPSAwXG5cbiAgICAkaXRlbXMuZXEoaW5kZXgpLnRyaWdnZXIoJ2ZvY3VzJylcbiAgfVxuXG5cbiAgLy8gRFJPUERPV04gUExVR0lOIERFRklOSVRJT05cbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuICBmdW5jdGlvbiBQbHVnaW4ob3B0aW9uKSB7XG4gICAgcmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgJHRoaXMgPSAkKHRoaXMpXG4gICAgICB2YXIgZGF0YSAgPSAkdGhpcy5kYXRhKCcuZHJvcGRvd24nKVxuXG4gICAgICBpZiAoIWRhdGEpICR0aGlzLmRhdGEoJy5kcm9wZG93bicsIChkYXRhID0gbmV3IERyb3Bkb3duKHRoaXMpKSlcbiAgICAgIGlmICh0eXBlb2Ygb3B0aW9uID09ICdzdHJpbmcnKSBkYXRhW29wdGlvbl0uY2FsbCgkdGhpcylcbiAgICB9KVxuICB9XG5cbiAgdmFyIG9sZCA9ICQuZm4uZHJvcGRvd25cblxuICAkLmZuLmRyb3Bkb3duICAgICAgICAgICAgID0gUGx1Z2luXG4gICQuZm4uZHJvcGRvd24uQ29uc3RydWN0b3IgPSBEcm9wZG93blxuXG5cbiAgLy8gRFJPUERPV04gTk8gQ09ORkxJQ1RcbiAgLy8gPT09PT09PT09PT09PT09PT09PT1cblxuICAkLmZuLmRyb3Bkb3duLm5vQ29uZmxpY3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgJC5mbi5kcm9wZG93biA9IG9sZFxuICAgIHJldHVybiB0aGlzXG4gIH1cbiAgLy8gQVBQTFkgVE8gU1RBTkRBUkQgRFJPUERPV04gRUxFTUVOVFNcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuICAkKGRvY3VtZW50KVxuICAgIC5vbignY2xpY2suZHJvcGRvd24uZGF0YS1hcGknLCBjbGVhck1lbnVzKVxuICAgIC5vbignY2xpY2suZHJvcGRvd24uZGF0YS1hcGknLCAnLmRyb3Bkb3duIGZvcm0nLCBmdW5jdGlvbiAoZSkgeyBlLnN0b3BQcm9wYWdhdGlvbigpIH0pXG4gICAgLm9uKCdjbGljay5kcm9wZG93bi5kYXRhLWFwaScsIHRvZ2dsZSwgRHJvcGRvd24ucHJvdG90eXBlLnRvZ2dsZSlcbiAgICAub24oJ2tleWRvd24uZHJvcGRvd24uZGF0YS1hcGknLCB0b2dnbGUsIERyb3Bkb3duLnByb3RvdHlwZS5rZXlkb3duKVxuICAgIC5vbigna2V5ZG93bi5kcm9wZG93bi5kYXRhLWFwaScsICcubHBfX2Ryb3Bkb3duX21lbnUnLCBEcm9wZG93bi5wcm90b3R5cGUua2V5ZG93bilcblxufShqUXVlcnkpO1xuXG4vLyBCZWdpbiBkcm9wZG93biB1cmxcbiAkKGRvY3VtZW50KS5yZWFkeShmdW5jdGlvbigpIHsgXG5cbiAgICAgJCgnLmxwX19kcm9wZG93bl9tZW51IGxpIGEnKS5jbGljayhmdW5jdGlvbigpe1xuICAgICAgICAgdmFyIGNvdW50cnlOYW1lID0gJCh0aGlzKS50ZXh0KCk7XG4gICAgICAgICAkKHRoaXMpLnBhcmVudCgpLnBhcmVudCgpLnBhcmVudCgpLmZpbmQoXCIubHBfX2ZpbHRlcl9vcHRpb25cIikuaHRtbChjb3VudHJ5TmFtZSk7XG4gICAgICAgICB2YXIgb3B0aW9uID0gJCh0aGlzKS5hKCdocmVmJyk7XG4gICAgICAgICBpZihvcHRpb24gIT09IFwiXCIpIHtcbiAgICAgICAgICAgICBpZihvcHRpb24uaW5kZXhPZignd29ybGRiYW5rLm9yZycpPi0xIHx8IG9wdGlvbi5pbmRleE9mKCdiYW5jb211bmRpYWwub3JnJyk+LTEgfHwgXG4gICAgICAgICAgICAgICAgIG9wdGlvbi5pbmRleE9mKCdhbGJhbmthbGRhd2xpLm9yZycpPi0xIHx8IG9wdGlvbi5pbmRleE9mKCdiYW5xdWVtb25kaWFsZS5vcmcnKT4tMSB8fCBcbiAgICAgICAgICAgICAgICAgb3B0aW9uLmluZGV4T2YoJ3NoaWhhbmcub3JnJyk+LTEpIHtcbiAgICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uID0gb3B0aW9uO1xuICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgIHZhciBuZXdXaW5kb3cgPSB3aW5kb3cub3BlbihvcHRpb24sXCJfYmxhbmtcIik7XG4gICAgICAgICAgICAgICAgIG5ld1dpbmRvdy5sb2NhdGlvbiA9IG9wdGlvbjtcbiAgICAgICAgICAgICB9XG4gICAgICAgICB9IFxuXG4gICAgIH0pO1xuXG4gfSk7IFxuLy8gQmVnaW4gY291bnRyeS1kcm9wZG93bi1zZWFyY2gtdGV4dFxuICAgICQoZG9jdW1lbnQpLnJlYWR5KGZ1bmN0aW9uKCl7XG4kKFwiLmxwX19mb3JtX2NvbnRyb2xcIikua2V5dXAoZnVuY3Rpb24oKXtcbnZhciB2YWx1ZSA9ICQodGhpcykudmFsKCk7XG4kKFwiLmxwX19kcm9wZG93bl9tZW51PmxpIHNwYW4gLmNvdW50cnlmaXJzdExldmVsXCIpLmVhY2goZnVuY3Rpb24oKXtcblxuICAgdmFyIGxlbmd0aCA9IHZhbHVlLmxlbmd0aDtcbiAgIHZhciBzdWJzdHJpbmcgPSAkKHRoaXMpLnRleHQoKS50b0xvd2VyQ2FzZSgpLnN1YnN0cmluZygwLGxlbmd0aCk7XG4gICAvL2lmKCQodGhpcykudGV4dCgpLnRvTG93ZXJDYXNlKCkuc2VhcmNoKHZhbHVlLnRvTG93ZXJDYXNlKCkpID4gLTEpXG4gICBpZih2YWx1ZT09PXN1YnN0cmluZylcbiAgIHtcbiAgICQodGhpcykucGFyZW50KCkucGFyZW50KCkuc2hvdygpO1xuICAgfWVsc2VcbiAgIHtcbiAgICQodGhpcykucGFyZW50KCkucGFyZW50KCkuaGlkZSgpO1xuICAgXG4gICB9XG59KTtcbn0pO1xufSk7XG5cbiAkKCBkb2N1bWVudCApLnJlYWR5KGZ1bmN0aW9uKCkge1xuICAkKFwiLmxwX19mb3JtX2NvbnRyb2xcIikuY2xpY2soZnVuY3Rpb24oKXtcbiAgICAkKFwiLnNlbGVjdC1pdGVtXCIpLmFkZENsYXNzKFwiYWN0aXZlLXN0YXRlXCIpO1xuICAgXG4gIH0pO1xuICAkKFwiLmxwX19zZWFyY2hfc2VjdGlvblwiKS5jbGljayhmdW5jdGlvbigpe1xuICAgICQoXCIuc2VsZWN0LWl0ZW1cIikucmVtb3ZlQ2xhc3MoXCJhY3RpdmUtc3RhdGVcIik7XG4gIH0pO1xuICQoXCIubHBfX3NlYXJjaF9zZWN0aW9uXCIpLmNsaWNrKGZ1bmN0aW9uKCl7XG4gICAgJChcIi5zZWxlY3QtaXRlbVwiKS5yZW1vdmVDbGFzcyhcImFjdGl2ZS1zdGF0ZVwiKTtcbiAgfSk7XG4gfSk7IFxuLy8gQmVnaW4gY291bnRyeS1kcm9wZG93bi1zZWFyY2gtdGV4dFxuXG4vLyAtLS0tLS0tLS0tLUVuZCBEUk9QRE9XTiBKUyAtLS0tLS0tLS0tLS0tIC8vXG4iLCIvKlxuICBodG1sMmNhbnZhcyAwLjQuMSA8aHR0cDovL2h0bWwyY2FudmFzLmhlcnR6ZW4uY29tPlxuICBDb3B5cmlnaHQgKGMpIDIwMTMgTmlrbGFzIHZvbiBIZXJ0emVuXG5cbiAgUmVsZWFzZWQgdW5kZXIgTUlUIExpY2Vuc2VcbiovXG5cbihmdW5jdGlvbih3aW5kb3csIGRvY3VtZW50LCB1bmRlZmluZWQpe1xuXG4vL1widXNlIHN0cmljdFwiO1xuXG52YXIgX2h0bWwyY2FudmFzID0ge30sXG5wcmV2aW91c0VsZW1lbnQsXG5jb21wdXRlZENTUyxcbmh0bWwyY2FudmFzO1xuXG5faHRtbDJjYW52YXMuVXRpbCA9IHt9O1xuXG5faHRtbDJjYW52YXMuVXRpbC5sb2cgPSBmdW5jdGlvbihhKSB7XG4gIGlmIChfaHRtbDJjYW52YXMubG9nZ2luZyAmJiB3aW5kb3cuY29uc29sZSAmJiB3aW5kb3cuY29uc29sZS5sb2cpIHtcbiAgICB3aW5kb3cuY29uc29sZS5sb2coYSk7XG4gIH1cbn07XG5cbl9odG1sMmNhbnZhcy5VdGlsLnRyaW1UZXh0ID0gKGZ1bmN0aW9uKGlzTmF0aXZlKXtcbiAgcmV0dXJuIGZ1bmN0aW9uKGlucHV0KSB7XG4gICAgcmV0dXJuIGlzTmF0aXZlID8gaXNOYXRpdmUuYXBwbHkoaW5wdXQpIDogKChpbnB1dCB8fCAnJykgKyAnJykucmVwbGFjZSggL15cXHMrfFxccyskL2cgLCAnJyApO1xuICB9O1xufSkoU3RyaW5nLnByb3RvdHlwZS50cmltKTtcblxuX2h0bWwyY2FudmFzLlV0aWwuYXNGbG9hdCA9IGZ1bmN0aW9uKHYpIHtcbiAgcmV0dXJuIHBhcnNlRmxvYXQodik7XG59O1xuXG4oZnVuY3Rpb24oKSB7XG4gIC8vIFRPRE86IHN1cHBvcnQgYWxsIHBvc3NpYmxlIGxlbmd0aCB2YWx1ZXNcbiAgdmFyIFRFWFRfU0hBRE9XX1BST1BFUlRZID0gLygocmdiYXxyZ2IpXFwoW15cXCldK1xcKShcXHMtP1xcZCtweCl7MCx9KS9nO1xuICB2YXIgVEVYVF9TSEFET1dfVkFMVUVTID0gLygtP1xcZCtweCl8KCMuKyl8KHJnYlxcKC4rXFwpKXwocmdiYVxcKC4rXFwpKS9nO1xuICBfaHRtbDJjYW52YXMuVXRpbC5wYXJzZVRleHRTaGFkb3dzID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgaWYgKCF2YWx1ZSB8fCB2YWx1ZSA9PT0gJ25vbmUnKSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuXG4gICAgLy8gZmluZCBtdWx0aXBsZSBzaGFkb3cgZGVjbGFyYXRpb25zXG4gICAgdmFyIHNoYWRvd3MgPSB2YWx1ZS5tYXRjaChURVhUX1NIQURPV19QUk9QRVJUWSksXG4gICAgICByZXN1bHRzID0gW107XG4gICAgZm9yICh2YXIgaSA9IDA7IHNoYWRvd3MgJiYgKGkgPCBzaGFkb3dzLmxlbmd0aCk7IGkrKykge1xuICAgICAgdmFyIHMgPSBzaGFkb3dzW2ldLm1hdGNoKFRFWFRfU0hBRE9XX1ZBTFVFUyk7XG4gICAgICByZXN1bHRzLnB1c2goe1xuICAgICAgICBjb2xvcjogc1swXSxcbiAgICAgICAgb2Zmc2V0WDogc1sxXSA/IHNbMV0ucmVwbGFjZSgncHgnLCAnJykgOiAwLFxuICAgICAgICBvZmZzZXRZOiBzWzJdID8gc1syXS5yZXBsYWNlKCdweCcsICcnKSA6IDAsXG4gICAgICAgIGJsdXI6IHNbM10gPyBzWzNdLnJlcGxhY2UoJ3B4JywgJycpIDogMFxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHRzO1xuICB9O1xufSkoKTtcblxuX2h0bWwyY2FudmFzLlV0aWwucGFyc2VCYWNrZ3JvdW5kSW1hZ2UgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICB2YXIgd2hpdGVzcGFjZSA9ICcgXFxyXFxuXFx0JyxcbiAgICAgICAgbWV0aG9kLCBkZWZpbml0aW9uLCBwcmVmaXgsIHByZWZpeF9pLCBibG9jaywgcmVzdWx0cyA9IFtdLFxuICAgICAgICBjLCBtb2RlID0gMCwgbnVtUGFyZW4gPSAwLCBxdW90ZSwgYXJncztcblxuICAgIHZhciBhcHBlbmRSZXN1bHQgPSBmdW5jdGlvbigpe1xuICAgICAgICBpZihtZXRob2QpIHtcbiAgICAgICAgICAgIGlmKGRlZmluaXRpb24uc3Vic3RyKCAwLCAxICkgPT09ICdcIicpIHtcbiAgICAgICAgICAgICAgICBkZWZpbml0aW9uID0gZGVmaW5pdGlvbi5zdWJzdHIoIDEsIGRlZmluaXRpb24ubGVuZ3RoIC0gMiApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYoZGVmaW5pdGlvbikge1xuICAgICAgICAgICAgICAgIGFyZ3MucHVzaChkZWZpbml0aW9uKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmKG1ldGhvZC5zdWJzdHIoIDAsIDEgKSA9PT0gJy0nICYmXG4gICAgICAgICAgICAgICAgICAgIChwcmVmaXhfaSA9IG1ldGhvZC5pbmRleE9mKCAnLScsIDEgKSArIDEpID4gMCkge1xuICAgICAgICAgICAgICAgIHByZWZpeCA9IG1ldGhvZC5zdWJzdHIoIDAsIHByZWZpeF9pKTtcbiAgICAgICAgICAgICAgICBtZXRob2QgPSBtZXRob2Quc3Vic3RyKCBwcmVmaXhfaSApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVzdWx0cy5wdXNoKHtcbiAgICAgICAgICAgICAgICBwcmVmaXg6IHByZWZpeCxcbiAgICAgICAgICAgICAgICBtZXRob2Q6IG1ldGhvZC50b0xvd2VyQ2FzZSgpLFxuICAgICAgICAgICAgICAgIHZhbHVlOiBibG9jayxcbiAgICAgICAgICAgICAgICBhcmdzOiBhcmdzXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBhcmdzID0gW107IC8vZm9yIHNvbWUgb2RkIHJlYXNvbiwgc2V0dGluZyAubGVuZ3RoID0gMCBkaWRuJ3Qgd29yayBpbiBzYWZhcmlcbiAgICAgICAgbWV0aG9kID1cbiAgICAgICAgICAgIHByZWZpeCA9XG4gICAgICAgICAgICBkZWZpbml0aW9uID1cbiAgICAgICAgICAgIGJsb2NrID0gJyc7XG4gICAgfTtcblxuICAgIGFwcGVuZFJlc3VsdCgpO1xuICAgIGZvcih2YXIgaSA9IDAsIGlpID0gdmFsdWUubGVuZ3RoOyBpPGlpOyBpKyspIHtcbiAgICAgICAgYyA9IHZhbHVlW2ldO1xuICAgICAgICBpZihtb2RlID09PSAwICYmIHdoaXRlc3BhY2UuaW5kZXhPZiggYyApID4gLTEpe1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgc3dpdGNoKGMpIHtcbiAgICAgICAgICAgIGNhc2UgJ1wiJzpcbiAgICAgICAgICAgICAgICBpZighcXVvdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgcXVvdGUgPSBjO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmKHF1b3RlID09PSBjKSB7XG4gICAgICAgICAgICAgICAgICAgIHF1b3RlID0gbnVsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgIGNhc2UgJygnOlxuICAgICAgICAgICAgICAgIGlmKHF1b3RlKSB7IGJyZWFrOyB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZihtb2RlID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIG1vZGUgPSAxO1xuICAgICAgICAgICAgICAgICAgICBibG9jayArPSBjO1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBudW1QYXJlbisrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSAnKSc6XG4gICAgICAgICAgICAgICAgaWYocXVvdGUpIHsgYnJlYWs7IH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmKG1vZGUgPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYobnVtUGFyZW4gPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1vZGUgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2sgKz0gYztcbiAgICAgICAgICAgICAgICAgICAgICAgIGFwcGVuZFJlc3VsdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBudW1QYXJlbi0tO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICBjYXNlICcsJzpcbiAgICAgICAgICAgICAgICBpZihxdW90ZSkgeyBicmVhazsgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYobW9kZSA9PT0gMCkge1xuICAgICAgICAgICAgICAgICAgICBhcHBlbmRSZXN1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKG1vZGUgPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYobnVtUGFyZW4gPT09IDAgJiYgIW1ldGhvZC5tYXRjaCgvXnVybCQvaSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFyZ3MucHVzaChkZWZpbml0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmluaXRpb24gPSAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrICs9IGM7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIGJsb2NrICs9IGM7XG4gICAgICAgIGlmKG1vZGUgPT09IDApIHsgbWV0aG9kICs9IGM7IH1cbiAgICAgICAgZWxzZSB7IGRlZmluaXRpb24gKz0gYzsgfVxuICAgIH1cbiAgICBhcHBlbmRSZXN1bHQoKTtcblxuICAgIHJldHVybiByZXN1bHRzO1xufTtcblxuX2h0bWwyY2FudmFzLlV0aWwuQm91bmRzID0gZnVuY3Rpb24gKGVsZW1lbnQpIHtcbiAgdmFyIGNsaWVudFJlY3QsIGJvdW5kcyA9IHt9O1xuXG4gIGlmIChlbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCl7XG4gICAgY2xpZW50UmVjdCA9IGVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cbiAgICAvLyBUT0RPIGFkZCBzY3JvbGwgcG9zaXRpb24gdG8gYm91bmRzLCBzbyBubyBzY3JvbGxpbmcgb2Ygd2luZG93IG5lY2Vzc2FyeVxuICAgIGJvdW5kcy50b3AgPSBjbGllbnRSZWN0LnRvcDtcbiAgICBib3VuZHMuYm90dG9tID0gY2xpZW50UmVjdC5ib3R0b20gfHwgKGNsaWVudFJlY3QudG9wICsgY2xpZW50UmVjdC5oZWlnaHQpO1xuICAgIGJvdW5kcy5sZWZ0ID0gY2xpZW50UmVjdC5sZWZ0O1xuXG4gICAgYm91bmRzLndpZHRoID0gZWxlbWVudC5vZmZzZXRXaWR0aDtcbiAgICBib3VuZHMuaGVpZ2h0ID0gZWxlbWVudC5vZmZzZXRIZWlnaHQ7XG4gIH1cblxuICByZXR1cm4gYm91bmRzO1xufTtcblxuLy8gVE9ETyBpZGVhbGx5LCB3ZSdkIHdhbnQgZXZlcnl0aGluZyB0byBnbyB0aHJvdWdoIHRoaXMgZnVuY3Rpb24gaW5zdGVhZCBvZiBVdGlsLkJvdW5kcyxcbi8vIGJ1dCB3b3VsZCByZXF1aXJlIGZ1cnRoZXIgd29yayB0byBjYWxjdWxhdGUgdGhlIGNvcnJlY3QgcG9zaXRpb25zIGZvciBlbGVtZW50cyB3aXRoIG9mZnNldFBhcmVudHNcbl9odG1sMmNhbnZhcy5VdGlsLk9mZnNldEJvdW5kcyA9IGZ1bmN0aW9uIChlbGVtZW50KSB7XG4gIHZhciBwYXJlbnQgPSBlbGVtZW50Lm9mZnNldFBhcmVudCA/IF9odG1sMmNhbnZhcy5VdGlsLk9mZnNldEJvdW5kcyhlbGVtZW50Lm9mZnNldFBhcmVudCkgOiB7dG9wOiAwLCBsZWZ0OiAwfTtcblxuICByZXR1cm4ge1xuICAgIHRvcDogZWxlbWVudC5vZmZzZXRUb3AgKyBwYXJlbnQudG9wLFxuICAgIGJvdHRvbTogZWxlbWVudC5vZmZzZXRUb3AgKyBlbGVtZW50Lm9mZnNldEhlaWdodCArIHBhcmVudC50b3AsXG4gICAgbGVmdDogZWxlbWVudC5vZmZzZXRMZWZ0ICsgcGFyZW50LmxlZnQsXG4gICAgd2lkdGg6IGVsZW1lbnQub2Zmc2V0V2lkdGgsXG4gICAgaGVpZ2h0OiBlbGVtZW50Lm9mZnNldEhlaWdodFxuICB9O1xufTtcblxuZnVuY3Rpb24gdG9QWChlbGVtZW50LCBhdHRyaWJ1dGUsIHZhbHVlICkge1xuICAgIHZhciByc0xlZnQgPSBlbGVtZW50LnJ1bnRpbWVTdHlsZSAmJiBlbGVtZW50LnJ1bnRpbWVTdHlsZVthdHRyaWJ1dGVdLFxuICAgICAgICBsZWZ0LFxuICAgICAgICBzdHlsZSA9IGVsZW1lbnQuc3R5bGU7XG5cbiAgICAvLyBDaGVjayBpZiB3ZSBhcmUgbm90IGRlYWxpbmcgd2l0aCBwaXhlbHMsIChPcGVyYSBoYXMgaXNzdWVzIHdpdGggdGhpcylcbiAgICAvLyBQb3J0ZWQgZnJvbSBqUXVlcnkgY3NzLmpzXG4gICAgLy8gRnJvbSB0aGUgYXdlc29tZSBoYWNrIGJ5IERlYW4gRWR3YXJkc1xuICAgIC8vIGh0dHA6Ly9lcmlrLmVhZS5uZXQvYXJjaGl2ZXMvMjAwNy8wNy8yNy8xOC41NC4xNS8jY29tbWVudC0xMDIyOTFcblxuICAgIC8vIElmIHdlJ3JlIG5vdCBkZWFsaW5nIHdpdGggYSByZWd1bGFyIHBpeGVsIG51bWJlclxuICAgIC8vIGJ1dCBhIG51bWJlciB0aGF0IGhhcyBhIHdlaXJkIGVuZGluZywgd2UgbmVlZCB0byBjb252ZXJ0IGl0IHRvIHBpeGVsc1xuXG4gICAgaWYgKCAhL14tP1swLTldK1xcLj9bMC05XSooPzpweCk/JC9pLnRlc3QoIHZhbHVlICkgJiYgL14tP1xcZC8udGVzdCh2YWx1ZSkgKSB7XG4gICAgICAgIC8vIFJlbWVtYmVyIHRoZSBvcmlnaW5hbCB2YWx1ZXNcbiAgICAgICAgbGVmdCA9IHN0eWxlLmxlZnQ7XG5cbiAgICAgICAgLy8gUHV0IGluIHRoZSBuZXcgdmFsdWVzIHRvIGdldCBhIGNvbXB1dGVkIHZhbHVlIG91dFxuICAgICAgICBpZiAocnNMZWZ0KSB7XG4gICAgICAgICAgICBlbGVtZW50LnJ1bnRpbWVTdHlsZS5sZWZ0ID0gZWxlbWVudC5jdXJyZW50U3R5bGUubGVmdDtcbiAgICAgICAgfVxuICAgICAgICBzdHlsZS5sZWZ0ID0gYXR0cmlidXRlID09PSBcImZvbnRTaXplXCIgPyBcIjFlbVwiIDogKHZhbHVlIHx8IDApO1xuICAgICAgICB2YWx1ZSA9IHN0eWxlLnBpeGVsTGVmdCArIFwicHhcIjtcblxuICAgICAgICAvLyBSZXZlcnQgdGhlIGNoYW5nZWQgdmFsdWVzXG4gICAgICAgIHN0eWxlLmxlZnQgPSBsZWZ0O1xuICAgICAgICBpZiAocnNMZWZ0KSB7XG4gICAgICAgICAgICBlbGVtZW50LnJ1bnRpbWVTdHlsZS5sZWZ0ID0gcnNMZWZ0O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaWYgKCEvXih0aGlufG1lZGl1bXx0aGljaykkL2kudGVzdCh2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIE1hdGgucm91bmQocGFyc2VGbG9hdCh2YWx1ZSkpICsgXCJweFwiO1xuICAgIH1cblxuICAgIHJldHVybiB2YWx1ZTtcbn1cblxuZnVuY3Rpb24gYXNJbnQodmFsKSB7XG4gICAgcmV0dXJuIHBhcnNlSW50KHZhbCwgMTApO1xufVxuXG5mdW5jdGlvbiBpc1BlcmNlbnRhZ2UodmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlLnRvU3RyaW5nKCkuaW5kZXhPZihcIiVcIikgIT09IC0xO1xufVxuXG5mdW5jdGlvbiBwYXJzZUJhY2tncm91bmRTaXplUG9zaXRpb24odmFsdWUsIGVsZW1lbnQsIGF0dHJpYnV0ZSwgaW5kZXgpIHtcbiAgICB2YWx1ZSA9ICh2YWx1ZSB8fCAnJykuc3BsaXQoJywnKTtcbiAgICB2YWx1ZSA9IHZhbHVlW2luZGV4IHx8IDBdIHx8IHZhbHVlWzBdIHx8ICdhdXRvJztcbiAgICB2YWx1ZSA9IF9odG1sMmNhbnZhcy5VdGlsLnRyaW1UZXh0KHZhbHVlKS5zcGxpdCgnICcpO1xuICAgIGlmKGF0dHJpYnV0ZSA9PT0gJ2JhY2tncm91bmRTaXplJyAmJiAodmFsdWVbMF0gJiYgdmFsdWVbMF0ubWF0Y2goL14oY292ZXJ8Y29udGFpbnxhdXRvKSQvKSkpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHZhbHVlWzBdID0gKHZhbHVlWzBdLmluZGV4T2YoIFwiJVwiICkgPT09IC0xKSA/IHRvUFgoZWxlbWVudCwgYXR0cmlidXRlICsgXCJYXCIsIHZhbHVlWzBdKSA6IHZhbHVlWzBdO1xuICAgICAgICBpZih2YWx1ZVsxXSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBpZihhdHRyaWJ1dGUgPT09ICdiYWNrZ3JvdW5kU2l6ZScpIHtcbiAgICAgICAgICAgICAgICB2YWx1ZVsxXSA9ICdhdXRvJztcbiAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vIElFIDkgZG9lc24ndCByZXR1cm4gZG91YmxlIGRpZ2l0IGFsd2F5c1xuICAgICAgICAgICAgICAgIHZhbHVlWzFdID0gdmFsdWVbMF07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdmFsdWVbMV0gPSAodmFsdWVbMV0uaW5kZXhPZihcIiVcIikgPT09IC0xKSA/IHRvUFgoZWxlbWVudCwgYXR0cmlidXRlICsgXCJZXCIsIHZhbHVlWzFdKSA6IHZhbHVlWzFdO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWU7XG59XG5cbl9odG1sMmNhbnZhcy5VdGlsLmdldENTUyA9IGZ1bmN0aW9uIChlbGVtZW50LCBhdHRyaWJ1dGUsIGluZGV4KSB7XG4gICAgaWYgKHByZXZpb3VzRWxlbWVudCAhPT0gZWxlbWVudCkge1xuICAgICAgY29tcHV0ZWRDU1MgPSBkb2N1bWVudC5kZWZhdWx0Vmlldy5nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQsIG51bGwpO1xuICAgIH1cblxuICAgIHZhciB2YWx1ZSA9IGNvbXB1dGVkQ1NTW2F0dHJpYnV0ZV07XG5cbiAgICBpZiAoL15iYWNrZ3JvdW5kKFNpemV8UG9zaXRpb24pJC8udGVzdChhdHRyaWJ1dGUpKSB7XG4gICAgICAgIHJldHVybiBwYXJzZUJhY2tncm91bmRTaXplUG9zaXRpb24odmFsdWUsIGVsZW1lbnQsIGF0dHJpYnV0ZSwgaW5kZXgpO1xuICAgIH0gZWxzZSBpZiAoL2JvcmRlcihUb3B8Qm90dG9tKShMZWZ0fFJpZ2h0KVJhZGl1cy8udGVzdChhdHRyaWJ1dGUpKSB7XG4gICAgICB2YXIgYXJyID0gdmFsdWUuc3BsaXQoXCIgXCIpO1xuICAgICAgaWYgKGFyci5sZW5ndGggPD0gMSkge1xuICAgICAgICAgIGFyclsxXSA9IGFyclswXTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBhcnIubWFwKGFzSW50KTtcbiAgICB9XG5cbiAgcmV0dXJuIHZhbHVlO1xufTtcblxuX2h0bWwyY2FudmFzLlV0aWwucmVzaXplQm91bmRzID0gZnVuY3Rpb24oIGN1cnJlbnRfd2lkdGgsIGN1cnJlbnRfaGVpZ2h0LCB0YXJnZXRfd2lkdGgsIHRhcmdldF9oZWlnaHQsIHN0cmV0Y2hfbW9kZSApe1xuICB2YXIgdGFyZ2V0X3JhdGlvID0gdGFyZ2V0X3dpZHRoIC8gdGFyZ2V0X2hlaWdodCxcbiAgICBjdXJyZW50X3JhdGlvID0gY3VycmVudF93aWR0aCAvIGN1cnJlbnRfaGVpZ2h0LFxuICAgIG91dHB1dF93aWR0aCwgb3V0cHV0X2hlaWdodDtcblxuICBpZighc3RyZXRjaF9tb2RlIHx8IHN0cmV0Y2hfbW9kZSA9PT0gJ2F1dG8nKSB7XG4gICAgb3V0cHV0X3dpZHRoID0gdGFyZ2V0X3dpZHRoO1xuICAgIG91dHB1dF9oZWlnaHQgPSB0YXJnZXRfaGVpZ2h0O1xuICB9IGVsc2UgaWYodGFyZ2V0X3JhdGlvIDwgY3VycmVudF9yYXRpbyBeIHN0cmV0Y2hfbW9kZSA9PT0gJ2NvbnRhaW4nKSB7XG4gICAgb3V0cHV0X2hlaWdodCA9IHRhcmdldF9oZWlnaHQ7XG4gICAgb3V0cHV0X3dpZHRoID0gdGFyZ2V0X2hlaWdodCAqIGN1cnJlbnRfcmF0aW87XG4gIH0gZWxzZSB7XG4gICAgb3V0cHV0X3dpZHRoID0gdGFyZ2V0X3dpZHRoO1xuICAgIG91dHB1dF9oZWlnaHQgPSB0YXJnZXRfd2lkdGggLyBjdXJyZW50X3JhdGlvO1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICB3aWR0aDogb3V0cHV0X3dpZHRoLFxuICAgIGhlaWdodDogb3V0cHV0X2hlaWdodFxuICB9O1xufTtcblxuX2h0bWwyY2FudmFzLlV0aWwuQmFja2dyb3VuZFBvc2l0aW9uID0gZnVuY3Rpb24oZWxlbWVudCwgYm91bmRzLCBpbWFnZSwgaW1hZ2VJbmRleCwgYmFja2dyb3VuZFNpemUgKSB7XG4gICAgdmFyIGJhY2tncm91bmRQb3NpdGlvbiA9ICBfaHRtbDJjYW52YXMuVXRpbC5nZXRDU1MoZWxlbWVudCwgJ2JhY2tncm91bmRQb3NpdGlvbicsIGltYWdlSW5kZXgpLFxuICAgICAgICBsZWZ0UG9zaXRpb24sXG4gICAgICAgIHRvcFBvc2l0aW9uO1xuICAgIGlmIChiYWNrZ3JvdW5kUG9zaXRpb24ubGVuZ3RoID09PSAxKXtcbiAgICAgICAgYmFja2dyb3VuZFBvc2l0aW9uID0gW2JhY2tncm91bmRQb3NpdGlvblswXSwgYmFja2dyb3VuZFBvc2l0aW9uWzBdXTtcbiAgICB9XG5cbiAgICBpZiAoaXNQZXJjZW50YWdlKGJhY2tncm91bmRQb3NpdGlvblswXSkpe1xuICAgICAgICBsZWZ0UG9zaXRpb24gPSAoYm91bmRzLndpZHRoIC0gKGJhY2tncm91bmRTaXplIHx8IGltYWdlKS53aWR0aCkgKiAocGFyc2VGbG9hdChiYWNrZ3JvdW5kUG9zaXRpb25bMF0pIC8gMTAwKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICBsZWZ0UG9zaXRpb24gPSBwYXJzZUludChiYWNrZ3JvdW5kUG9zaXRpb25bMF0sIDEwKTtcbiAgICB9XG5cbiAgICBpZiAoYmFja2dyb3VuZFBvc2l0aW9uWzFdID09PSAnYXV0bycpIHtcbiAgICAgICAgdG9wUG9zaXRpb24gPSBsZWZ0UG9zaXRpb24gLyBpbWFnZS53aWR0aCAqIGltYWdlLmhlaWdodDtcbiAgICB9IGVsc2UgaWYgKGlzUGVyY2VudGFnZShiYWNrZ3JvdW5kUG9zaXRpb25bMV0pKXtcbiAgICAgICAgdG9wUG9zaXRpb24gPSAgKGJvdW5kcy5oZWlnaHQgLSAoYmFja2dyb3VuZFNpemUgfHwgaW1hZ2UpLmhlaWdodCkgKiBwYXJzZUZsb2F0KGJhY2tncm91bmRQb3NpdGlvblsxXSkgLyAxMDA7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgdG9wUG9zaXRpb24gPSBwYXJzZUludChiYWNrZ3JvdW5kUG9zaXRpb25bMV0sIDEwKTtcbiAgICB9XG5cbiAgICBpZiAoYmFja2dyb3VuZFBvc2l0aW9uWzBdID09PSAnYXV0bycpIHtcbiAgICAgICAgbGVmdFBvc2l0aW9uID0gdG9wUG9zaXRpb24gLyBpbWFnZS5oZWlnaHQgKiBpbWFnZS53aWR0aDtcbiAgICB9XG5cbiAgICByZXR1cm4ge2xlZnQ6IGxlZnRQb3NpdGlvbiwgdG9wOiB0b3BQb3NpdGlvbn07XG59O1xuXG5faHRtbDJjYW52YXMuVXRpbC5CYWNrZ3JvdW5kU2l6ZSA9IGZ1bmN0aW9uKGVsZW1lbnQsIGJvdW5kcywgaW1hZ2UsIGltYWdlSW5kZXgpIHtcbiAgdmFyIGJhY2tncm91bmRTaXplID0gIF9odG1sMmNhbnZhcy5VdGlsLmdldENTUyhlbGVtZW50LCAnYmFja2dyb3VuZFNpemUnLCBpbWFnZUluZGV4KSwgd2lkdGgsIGhlaWdodDtcblxuICBpZiAoYmFja2dyb3VuZFNpemUubGVuZ3RoID09PSAxKSB7XG4gICAgYmFja2dyb3VuZFNpemUgPSBbYmFja2dyb3VuZFNpemVbMF0sIGJhY2tncm91bmRTaXplWzBdXTtcbiAgfVxuXG4gIGlmIChpc1BlcmNlbnRhZ2UoYmFja2dyb3VuZFNpemVbMF0pKSB7XG4gICAgd2lkdGggPSBib3VuZHMud2lkdGggKiBwYXJzZUZsb2F0KGJhY2tncm91bmRTaXplWzBdKSAvIDEwMDtcbiAgfSBlbHNlIGlmICgvY29udGFpbnxjb3Zlci8udGVzdChiYWNrZ3JvdW5kU2l6ZVswXSkpIHtcbiAgICByZXR1cm4gX2h0bWwyY2FudmFzLlV0aWwucmVzaXplQm91bmRzKGltYWdlLndpZHRoLCBpbWFnZS5oZWlnaHQsIGJvdW5kcy53aWR0aCwgYm91bmRzLmhlaWdodCwgYmFja2dyb3VuZFNpemVbMF0pO1xuICB9IGVsc2Uge1xuICAgIHdpZHRoID0gcGFyc2VJbnQoYmFja2dyb3VuZFNpemVbMF0sIDEwKTtcbiAgfVxuXG4gIGlmIChiYWNrZ3JvdW5kU2l6ZVswXSA9PT0gJ2F1dG8nICYmIGJhY2tncm91bmRTaXplWzFdID09PSAnYXV0bycpIHtcbiAgICBoZWlnaHQgPSBpbWFnZS5oZWlnaHQ7XG4gIH0gZWxzZSBpZiAoYmFja2dyb3VuZFNpemVbMV0gPT09ICdhdXRvJykge1xuICAgIGhlaWdodCA9IHdpZHRoIC8gaW1hZ2Uud2lkdGggKiBpbWFnZS5oZWlnaHQ7XG4gIH0gZWxzZSBpZiAoaXNQZXJjZW50YWdlKGJhY2tncm91bmRTaXplWzFdKSkge1xuICAgIGhlaWdodCA9ICBib3VuZHMuaGVpZ2h0ICogcGFyc2VGbG9hdChiYWNrZ3JvdW5kU2l6ZVsxXSkgLyAxMDA7XG4gIH0gZWxzZSB7XG4gICAgaGVpZ2h0ID0gcGFyc2VJbnQoYmFja2dyb3VuZFNpemVbMV0sIDEwKTtcbiAgfVxuXG4gIGlmIChiYWNrZ3JvdW5kU2l6ZVswXSA9PT0gJ2F1dG8nKSB7XG4gICAgd2lkdGggPSBoZWlnaHQgLyBpbWFnZS5oZWlnaHQgKiBpbWFnZS53aWR0aDtcbiAgfVxuXG4gIHJldHVybiB7d2lkdGg6IHdpZHRoLCBoZWlnaHQ6IGhlaWdodH07XG59O1xuXG5faHRtbDJjYW52YXMuVXRpbC5CYWNrZ3JvdW5kUmVwZWF0ID0gZnVuY3Rpb24oZWxlbWVudCwgaW1hZ2VJbmRleCkge1xuICB2YXIgYmFja2dyb3VuZFJlcGVhdCA9IF9odG1sMmNhbnZhcy5VdGlsLmdldENTUyhlbGVtZW50LCBcImJhY2tncm91bmRSZXBlYXRcIikuc3BsaXQoXCIsXCIpLm1hcChfaHRtbDJjYW52YXMuVXRpbC50cmltVGV4dCk7XG4gIHJldHVybiBiYWNrZ3JvdW5kUmVwZWF0W2ltYWdlSW5kZXhdIHx8IGJhY2tncm91bmRSZXBlYXRbMF07XG59O1xuXG5faHRtbDJjYW52YXMuVXRpbC5FeHRlbmQgPSBmdW5jdGlvbiAob3B0aW9ucywgZGVmYXVsdHMpIHtcbiAgZm9yICh2YXIga2V5IGluIG9wdGlvbnMpIHtcbiAgICBpZiAob3B0aW9ucy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICBkZWZhdWx0c1trZXldID0gb3B0aW9uc1trZXldO1xuICAgIH1cbiAgfVxuICByZXR1cm4gZGVmYXVsdHM7XG59O1xuXG5cbi8qXG4gKiBEZXJpdmVkIGZyb20galF1ZXJ5LmNvbnRlbnRzKClcbiAqIENvcHlyaWdodCAyMDEwLCBKb2huIFJlc2lnXG4gKiBEdWFsIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgb3IgR1BMIFZlcnNpb24gMiBsaWNlbnNlcy5cbiAqIGh0dHA6Ly9qcXVlcnkub3JnL2xpY2Vuc2VcbiAqL1xuX2h0bWwyY2FudmFzLlV0aWwuQ2hpbGRyZW4gPSBmdW5jdGlvbiggZWxlbSApIHtcbiAgdmFyIGNoaWxkcmVuO1xuICB0cnkge1xuICAgIGNoaWxkcmVuID0gKGVsZW0ubm9kZU5hbWUgJiYgZWxlbS5ub2RlTmFtZS50b1VwcGVyQ2FzZSgpID09PSBcIklGUkFNRVwiKSA/IGVsZW0uY29udGVudERvY3VtZW50IHx8IGVsZW0uY29udGVudFdpbmRvdy5kb2N1bWVudCA6IChmdW5jdGlvbihhcnJheSkge1xuICAgICAgdmFyIHJldCA9IFtdO1xuICAgICAgaWYgKGFycmF5ICE9PSBudWxsKSB7XG4gICAgICAgIChmdW5jdGlvbihmaXJzdCwgc2Vjb25kICkge1xuICAgICAgICAgIHZhciBpID0gZmlyc3QubGVuZ3RoLFxuICAgICAgICAgIGogPSAwO1xuXG4gICAgICAgICAgaWYgKHR5cGVvZiBzZWNvbmQubGVuZ3RoID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgICAgICBmb3IgKHZhciBsID0gc2Vjb25kLmxlbmd0aDsgaiA8IGw7IGorKykge1xuICAgICAgICAgICAgICBmaXJzdFtpKytdID0gc2Vjb25kW2pdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB3aGlsZSAoc2Vjb25kW2pdICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgZmlyc3RbaSsrXSA9IHNlY29uZFtqKytdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIGZpcnN0Lmxlbmd0aCA9IGk7XG5cbiAgICAgICAgICByZXR1cm4gZmlyc3Q7XG4gICAgICAgIH0pKHJldCwgYXJyYXkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJldDtcbiAgICB9KShlbGVtLmNoaWxkTm9kZXMpO1xuXG4gIH0gY2F0Y2ggKGV4KSB7XG4gICAgX2h0bWwyY2FudmFzLlV0aWwubG9nKFwiaHRtbDJjYW52YXMuVXRpbC5DaGlsZHJlbiBmYWlsZWQgd2l0aCBleGNlcHRpb246IFwiICsgZXgubWVzc2FnZSk7XG4gICAgY2hpbGRyZW4gPSBbXTtcbiAgfVxuICByZXR1cm4gY2hpbGRyZW47XG59O1xuXG5faHRtbDJjYW52YXMuVXRpbC5pc1RyYW5zcGFyZW50ID0gZnVuY3Rpb24oYmFja2dyb3VuZENvbG9yKSB7XG4gIHJldHVybiAoIWJhY2tncm91bmRDb2xvciB8fCBiYWNrZ3JvdW5kQ29sb3IgPT09IFwidHJhbnNwYXJlbnRcIiB8fCBiYWNrZ3JvdW5kQ29sb3IgPT09IFwicmdiYSgwLCAwLCAwLCAwKVwiKTtcbn07XG5cbl9odG1sMmNhbnZhcy5VdGlsLkZvbnQgPSAoZnVuY3Rpb24gKCkge1xuXG4gIHZhciBmb250RGF0YSA9IHt9O1xuXG4gIHJldHVybiBmdW5jdGlvbihmb250LCBmb250U2l6ZSwgZG9jKSB7XG4gICAgaWYgKGZvbnREYXRhW2ZvbnQgKyBcIi1cIiArIGZvbnRTaXplXSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gZm9udERhdGFbZm9udCArIFwiLVwiICsgZm9udFNpemVdO1xuICAgIH1cblxuICAgIHZhciBjb250YWluZXIgPSBkb2MuY3JlYXRlRWxlbWVudCgnZGl2JyksXG4gICAgaW1nID0gZG9jLmNyZWF0ZUVsZW1lbnQoJ2ltZycpLFxuICAgIHNwYW4gPSBkb2MuY3JlYXRlRWxlbWVudCgnc3BhbicpLFxuICAgIHNhbXBsZVRleHQgPSAnSGlkZGVuIFRleHQnLFxuICAgIGJhc2VsaW5lLFxuICAgIG1pZGRsZSxcbiAgICBtZXRyaWNzT2JqO1xuXG4gICAgY29udGFpbmVyLnN0eWxlLnZpc2liaWxpdHkgPSBcImhpZGRlblwiO1xuICAgIGNvbnRhaW5lci5zdHlsZS5mb250RmFtaWx5ID0gZm9udDtcbiAgICBjb250YWluZXIuc3R5bGUuZm9udFNpemUgPSBmb250U2l6ZTtcbiAgICBjb250YWluZXIuc3R5bGUubWFyZ2luID0gMDtcbiAgICBjb250YWluZXIuc3R5bGUucGFkZGluZyA9IDA7XG5cbiAgICBkb2MuYm9keS5hcHBlbmRDaGlsZChjb250YWluZXIpO1xuXG4gICAgLy8gaHR0cDovL3Byb2JhYmx5cHJvZ3JhbW1pbmcuY29tLzIwMDkvMDMvMTUvdGhlLXRpbmllc3QtZ2lmLWV2ZXIgKGhhbmR0aW55d2hpdGUuZ2lmKVxuICAgIGltZy5zcmMgPSBcImRhdGE6aW1hZ2UvZ2lmO2Jhc2U2NCxSMGxHT0RsaEFRQUJBSUFCQVAvLy93QUFBQ3dBQUFBQUFRQUJBQUFDQWtRQkFEcz1cIjtcbiAgICBpbWcud2lkdGggPSAxO1xuICAgIGltZy5oZWlnaHQgPSAxO1xuXG4gICAgaW1nLnN0eWxlLm1hcmdpbiA9IDA7XG4gICAgaW1nLnN0eWxlLnBhZGRpbmcgPSAwO1xuICAgIGltZy5zdHlsZS52ZXJ0aWNhbEFsaWduID0gXCJiYXNlbGluZVwiO1xuXG4gICAgc3Bhbi5zdHlsZS5mb250RmFtaWx5ID0gZm9udDtcbiAgICBzcGFuLnN0eWxlLmZvbnRTaXplID0gZm9udFNpemU7XG4gICAgc3Bhbi5zdHlsZS5tYXJnaW4gPSAwO1xuICAgIHNwYW4uc3R5bGUucGFkZGluZyA9IDA7XG5cbiAgICBzcGFuLmFwcGVuZENoaWxkKGRvYy5jcmVhdGVUZXh0Tm9kZShzYW1wbGVUZXh0KSk7XG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKHNwYW4pO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChpbWcpO1xuICAgIGJhc2VsaW5lID0gKGltZy5vZmZzZXRUb3AgLSBzcGFuLm9mZnNldFRvcCkgKyAxO1xuXG4gICAgY29udGFpbmVyLnJlbW92ZUNoaWxkKHNwYW4pO1xuICAgIGNvbnRhaW5lci5hcHBlbmRDaGlsZChkb2MuY3JlYXRlVGV4dE5vZGUoc2FtcGxlVGV4dCkpO1xuXG4gICAgY29udGFpbmVyLnN0eWxlLmxpbmVIZWlnaHQgPSBcIm5vcm1hbFwiO1xuICAgIGltZy5zdHlsZS52ZXJ0aWNhbEFsaWduID0gXCJzdXBlclwiO1xuXG4gICAgbWlkZGxlID0gKGltZy5vZmZzZXRUb3AtY29udGFpbmVyLm9mZnNldFRvcCkgKyAxO1xuICAgIG1ldHJpY3NPYmogPSB7XG4gICAgICBiYXNlbGluZTogYmFzZWxpbmUsXG4gICAgICBsaW5lV2lkdGg6IDEsXG4gICAgICBtaWRkbGU6IG1pZGRsZVxuICAgIH07XG5cbiAgICBmb250RGF0YVtmb250ICsgXCItXCIgKyBmb250U2l6ZV0gPSBtZXRyaWNzT2JqO1xuXG4gICAgZG9jLmJvZHkucmVtb3ZlQ2hpbGQoY29udGFpbmVyKTtcblxuICAgIHJldHVybiBtZXRyaWNzT2JqO1xuICB9O1xufSkoKTtcblxuKGZ1bmN0aW9uKCl7XG4gIHZhciBVdGlsID0gX2h0bWwyY2FudmFzLlV0aWwsXG4gICAgR2VuZXJhdGUgPSB7fTtcblxuICBfaHRtbDJjYW52YXMuR2VuZXJhdGUgPSBHZW5lcmF0ZTtcblxuICB2YXIgcmVHcmFkaWVudHMgPSBbXG4gIC9eKC13ZWJraXQtbGluZWFyLWdyYWRpZW50KVxcKChbYS16XFxzXSspKFtcXHdcXGRcXC5cXHMsJVxcKFxcKV0rKVxcKSQvLFxuICAvXigtby1saW5lYXItZ3JhZGllbnQpXFwoKFthLXpcXHNdKykoW1xcd1xcZFxcLlxccywlXFwoXFwpXSspXFwpJC8sXG4gIC9eKC13ZWJraXQtZ3JhZGllbnQpXFwoKGxpbmVhcnxyYWRpYWwpLFxccygoPzpcXGR7MSwzfSU/KVxccyg/OlxcZHsxLDN9JT8pLFxccyg/OlxcZHsxLDN9JT8pXFxzKD86XFxkezEsM30lPykpKFtcXHdcXGRcXC5cXHMsJVxcKFxcKVxcLV0rKVxcKSQvLFxuICAvXigtbW96LWxpbmVhci1ncmFkaWVudClcXCgoKD86XFxkezEsM30lPylcXHMoPzpcXGR7MSwzfSU/KSkoW1xcd1xcZFxcLlxccywlXFwoXFwpXSspXFwpJC8sXG4gIC9eKC13ZWJraXQtcmFkaWFsLWdyYWRpZW50KVxcKCgoPzpcXGR7MSwzfSU/KVxccyg/OlxcZHsxLDN9JT8pKSxcXHMoXFx3KylcXHMoW2EtelxcLV0rKShbXFx3XFxkXFwuXFxzLCVcXChcXCldKylcXCkkLyxcbiAgL14oLW1vei1yYWRpYWwtZ3JhZGllbnQpXFwoKCg/OlxcZHsxLDN9JT8pXFxzKD86XFxkezEsM30lPykpLFxccyhcXHcrKVxccz8oW2EtelxcLV0qKShbXFx3XFxkXFwuXFxzLCVcXChcXCldKylcXCkkLyxcbiAgL14oLW8tcmFkaWFsLWdyYWRpZW50KVxcKCgoPzpcXGR7MSwzfSU/KVxccyg/OlxcZHsxLDN9JT8pKSxcXHMoXFx3KylcXHMoW2EtelxcLV0rKShbXFx3XFxkXFwuXFxzLCVcXChcXCldKylcXCkkL1xuICBdO1xuXG4gIC8qXG4gKiBUT0RPOiBBZGQgSUUxMCB2ZW5kb3IgcHJlZml4ICgtbXMpIHN1cHBvcnRcbiAqIFRPRE86IEFkZCBXM0MgZ3JhZGllbnQgKGxpbmVhci1ncmFkaWVudCkgc3VwcG9ydFxuICogVE9ETzogQWRkIG9sZCBXZWJraXQgLXdlYmtpdC1ncmFkaWVudChyYWRpYWwsIC4uLikgc3VwcG9ydFxuICogVE9ETzogTWF5YmUgc29tZSBSZWdFeHAgb3B0aW1pemF0aW9ucyBhcmUgcG9zc2libGUgO28pXG4gKi9cbiAgR2VuZXJhdGUucGFyc2VHcmFkaWVudCA9IGZ1bmN0aW9uKGNzcywgYm91bmRzKSB7XG4gICAgdmFyIGdyYWRpZW50LCBpLCBsZW4gPSByZUdyYWRpZW50cy5sZW5ndGgsIG0xLCBzdG9wLCBtMiwgbTJMZW4sIHN0ZXAsIG0zLCB0bCx0cixicixibDtcblxuICAgIGZvcihpID0gMDsgaSA8IGxlbjsgaSs9MSl7XG4gICAgICBtMSA9IGNzcy5tYXRjaChyZUdyYWRpZW50c1tpXSk7XG4gICAgICBpZihtMSkge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZihtMSkge1xuICAgICAgc3dpdGNoKG0xWzFdKSB7XG4gICAgICAgIGNhc2UgJy13ZWJraXQtbGluZWFyLWdyYWRpZW50JzpcbiAgICAgICAgY2FzZSAnLW8tbGluZWFyLWdyYWRpZW50JzpcblxuICAgICAgICAgIGdyYWRpZW50ID0ge1xuICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXG4gICAgICAgICAgICB4MDogbnVsbCxcbiAgICAgICAgICAgIHkwOiBudWxsLFxuICAgICAgICAgICAgeDE6IG51bGwsXG4gICAgICAgICAgICB5MTogbnVsbCxcbiAgICAgICAgICAgIGNvbG9yU3RvcHM6IFtdXG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8vIGdldCBjb29yZGluYXRlc1xuICAgICAgICAgIG0yID0gbTFbMl0ubWF0Y2goL1xcdysvZyk7XG4gICAgICAgICAgaWYobTIpe1xuICAgICAgICAgICAgbTJMZW4gPSBtMi5sZW5ndGg7XG4gICAgICAgICAgICBmb3IoaSA9IDA7IGkgPCBtMkxlbjsgaSs9MSl7XG4gICAgICAgICAgICAgIHN3aXRjaChtMltpXSkge1xuICAgICAgICAgICAgICAgIGNhc2UgJ3RvcCc6XG4gICAgICAgICAgICAgICAgICBncmFkaWVudC55MCA9IDA7XG4gICAgICAgICAgICAgICAgICBncmFkaWVudC55MSA9IGJvdW5kcy5oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgICAgIGNhc2UgJ3JpZ2h0JzpcbiAgICAgICAgICAgICAgICAgIGdyYWRpZW50LngwID0gYm91bmRzLndpZHRoO1xuICAgICAgICAgICAgICAgICAgZ3JhZGllbnQueDEgPSAwO1xuICAgICAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgICAgICBjYXNlICdib3R0b20nOlxuICAgICAgICAgICAgICAgICAgZ3JhZGllbnQueTAgPSBib3VuZHMuaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgZ3JhZGllbnQueTEgPSAwO1xuICAgICAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgICAgICBjYXNlICdsZWZ0JzpcbiAgICAgICAgICAgICAgICAgIGdyYWRpZW50LngwID0gMDtcbiAgICAgICAgICAgICAgICAgIGdyYWRpZW50LngxID0gYm91bmRzLndpZHRoO1xuICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgaWYoZ3JhZGllbnQueDAgPT09IG51bGwgJiYgZ3JhZGllbnQueDEgPT09IG51bGwpeyAvLyBjZW50ZXJcbiAgICAgICAgICAgIGdyYWRpZW50LngwID0gZ3JhZGllbnQueDEgPSBib3VuZHMud2lkdGggLyAyO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZihncmFkaWVudC55MCA9PT0gbnVsbCAmJiBncmFkaWVudC55MSA9PT0gbnVsbCl7IC8vIGNlbnRlclxuICAgICAgICAgICAgZ3JhZGllbnQueTAgPSBncmFkaWVudC55MSA9IGJvdW5kcy5oZWlnaHQgLyAyO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIGdldCBjb2xvcnMgYW5kIHN0b3BzXG4gICAgICAgICAgbTIgPSBtMVszXS5tYXRjaCgvKCg/OnJnYnxyZ2JhKVxcKFxcZHsxLDN9LFxcc1xcZHsxLDN9LFxcc1xcZHsxLDN9KD86LFxcc1swLTlcXC5dKyk/XFwpKD86XFxzXFxkezEsM30oPzolfHB4KSk/KSsvZyk7XG4gICAgICAgICAgaWYobTIpe1xuICAgICAgICAgICAgbTJMZW4gPSBtMi5sZW5ndGg7XG4gICAgICAgICAgICBzdGVwID0gMSAvIE1hdGgubWF4KG0yTGVuIC0gMSwgMSk7XG4gICAgICAgICAgICBmb3IoaSA9IDA7IGkgPCBtMkxlbjsgaSs9MSl7XG4gICAgICAgICAgICAgIG0zID0gbTJbaV0ubWF0Y2goLygoPzpyZ2J8cmdiYSlcXChcXGR7MSwzfSxcXHNcXGR7MSwzfSxcXHNcXGR7MSwzfSg/OixcXHNbMC05XFwuXSspP1xcKSlcXHMqKFxcZHsxLDN9KT8oJXxweCk/Lyk7XG4gICAgICAgICAgICAgIGlmKG0zWzJdKXtcbiAgICAgICAgICAgICAgICBzdG9wID0gcGFyc2VGbG9hdChtM1syXSk7XG4gICAgICAgICAgICAgICAgaWYobTNbM10gPT09ICclJyl7XG4gICAgICAgICAgICAgICAgICBzdG9wIC89IDEwMDtcbiAgICAgICAgICAgICAgICB9IGVsc2UgeyAvLyBweCAtIHN0dXBpZCBvcGVyYVxuICAgICAgICAgICAgICAgICAgc3RvcCAvPSBib3VuZHMud2lkdGg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHN0b3AgPSBpICogc3RlcDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBncmFkaWVudC5jb2xvclN0b3BzLnB1c2goe1xuICAgICAgICAgICAgICAgIGNvbG9yOiBtM1sxXSxcbiAgICAgICAgICAgICAgICBzdG9wOiBzdG9wXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBicmVhaztcblxuICAgICAgICBjYXNlICctd2Via2l0LWdyYWRpZW50JzpcblxuICAgICAgICAgIGdyYWRpZW50ID0ge1xuICAgICAgICAgICAgdHlwZTogbTFbMl0gPT09ICdyYWRpYWwnID8gJ2NpcmNsZScgOiBtMVsyXSwgLy8gVE9ETzogQWRkIHJhZGlhbCBncmFkaWVudCBzdXBwb3J0IGZvciBvbGRlciBtb3ppbGxhIGRlZmluaXRpb25zXG4gICAgICAgICAgICB4MDogMCxcbiAgICAgICAgICAgIHkwOiAwLFxuICAgICAgICAgICAgeDE6IDAsXG4gICAgICAgICAgICB5MTogMCxcbiAgICAgICAgICAgIGNvbG9yU3RvcHM6IFtdXG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8vIGdldCBjb29yZGluYXRlc1xuICAgICAgICAgIG0yID0gbTFbM10ubWF0Y2goLyhcXGR7MSwzfSklP1xccyhcXGR7MSwzfSklPyxcXHMoXFxkezEsM30pJT9cXHMoXFxkezEsM30pJT8vKTtcbiAgICAgICAgICBpZihtMil7XG4gICAgICAgICAgICBncmFkaWVudC54MCA9IChtMlsxXSAqIGJvdW5kcy53aWR0aCkgLyAxMDA7XG4gICAgICAgICAgICBncmFkaWVudC55MCA9IChtMlsyXSAqIGJvdW5kcy5oZWlnaHQpIC8gMTAwO1xuICAgICAgICAgICAgZ3JhZGllbnQueDEgPSAobTJbM10gKiBib3VuZHMud2lkdGgpIC8gMTAwO1xuICAgICAgICAgICAgZ3JhZGllbnQueTEgPSAobTJbNF0gKiBib3VuZHMuaGVpZ2h0KSAvIDEwMDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBnZXQgY29sb3JzIGFuZCBzdG9wc1xuICAgICAgICAgIG0yID0gbTFbNF0ubWF0Y2goLygoPzpmcm9tfHRvfGNvbG9yLXN0b3ApXFwoKD86WzAtOVxcLl0rLFxccyk/KD86cmdifHJnYmEpXFwoXFxkezEsM30sXFxzXFxkezEsM30sXFxzXFxkezEsM30oPzosXFxzWzAtOVxcLl0rKT9cXClcXCkpKy9nKTtcbiAgICAgICAgICBpZihtMil7XG4gICAgICAgICAgICBtMkxlbiA9IG0yLmxlbmd0aDtcbiAgICAgICAgICAgIGZvcihpID0gMDsgaSA8IG0yTGVuOyBpKz0xKXtcbiAgICAgICAgICAgICAgbTMgPSBtMltpXS5tYXRjaCgvKGZyb218dG98Y29sb3Itc3RvcClcXCgoWzAtOVxcLl0rKT8oPzosXFxzKT8oKD86cmdifHJnYmEpXFwoXFxkezEsM30sXFxzXFxkezEsM30sXFxzXFxkezEsM30oPzosXFxzWzAtOVxcLl0rKT9cXCkpXFwpLyk7XG4gICAgICAgICAgICAgIHN0b3AgPSBwYXJzZUZsb2F0KG0zWzJdKTtcbiAgICAgICAgICAgICAgaWYobTNbMV0gPT09ICdmcm9tJykge1xuICAgICAgICAgICAgICAgIHN0b3AgPSAwLjA7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWYobTNbMV0gPT09ICd0bycpIHtcbiAgICAgICAgICAgICAgICBzdG9wID0gMS4wO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGdyYWRpZW50LmNvbG9yU3RvcHMucHVzaCh7XG4gICAgICAgICAgICAgICAgY29sb3I6IG0zWzNdLFxuICAgICAgICAgICAgICAgIHN0b3A6IHN0b3BcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgJy1tb3otbGluZWFyLWdyYWRpZW50JzpcblxuICAgICAgICAgIGdyYWRpZW50ID0ge1xuICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXG4gICAgICAgICAgICB4MDogMCxcbiAgICAgICAgICAgIHkwOiAwLFxuICAgICAgICAgICAgeDE6IDAsXG4gICAgICAgICAgICB5MTogMCxcbiAgICAgICAgICAgIGNvbG9yU3RvcHM6IFtdXG4gICAgICAgICAgfTtcblxuICAgICAgICAgIC8vIGdldCBjb29yZGluYXRlc1xuICAgICAgICAgIG0yID0gbTFbMl0ubWF0Y2goLyhcXGR7MSwzfSklP1xccyhcXGR7MSwzfSklPy8pO1xuXG4gICAgICAgICAgLy8gbTJbMV0gPT0gMCUgICAtPiBsZWZ0XG4gICAgICAgICAgLy8gbTJbMV0gPT0gNTAlICAtPiBjZW50ZXJcbiAgICAgICAgICAvLyBtMlsxXSA9PSAxMDAlIC0+IHJpZ2h0XG5cbiAgICAgICAgICAvLyBtMlsyXSA9PSAwJSAgIC0+IHRvcFxuICAgICAgICAgIC8vIG0yWzJdID09IDUwJSAgLT4gY2VudGVyXG4gICAgICAgICAgLy8gbTJbMl0gPT0gMTAwJSAtPiBib3R0b21cblxuICAgICAgICAgIGlmKG0yKXtcbiAgICAgICAgICAgIGdyYWRpZW50LngwID0gKG0yWzFdICogYm91bmRzLndpZHRoKSAvIDEwMDtcbiAgICAgICAgICAgIGdyYWRpZW50LnkwID0gKG0yWzJdICogYm91bmRzLmhlaWdodCkgLyAxMDA7XG4gICAgICAgICAgICBncmFkaWVudC54MSA9IGJvdW5kcy53aWR0aCAtIGdyYWRpZW50LngwO1xuICAgICAgICAgICAgZ3JhZGllbnQueTEgPSBib3VuZHMuaGVpZ2h0IC0gZ3JhZGllbnQueTA7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gZ2V0IGNvbG9ycyBhbmQgc3RvcHNcbiAgICAgICAgICBtMiA9IG0xWzNdLm1hdGNoKC8oKD86cmdifHJnYmEpXFwoXFxkezEsM30sXFxzXFxkezEsM30sXFxzXFxkezEsM30oPzosXFxzWzAtOVxcLl0rKT9cXCkoPzpcXHNcXGR7MSwzfSUpPykrL2cpO1xuICAgICAgICAgIGlmKG0yKXtcbiAgICAgICAgICAgIG0yTGVuID0gbTIubGVuZ3RoO1xuICAgICAgICAgICAgc3RlcCA9IDEgLyBNYXRoLm1heChtMkxlbiAtIDEsIDEpO1xuICAgICAgICAgICAgZm9yKGkgPSAwOyBpIDwgbTJMZW47IGkrPTEpe1xuICAgICAgICAgICAgICBtMyA9IG0yW2ldLm1hdGNoKC8oKD86cmdifHJnYmEpXFwoXFxkezEsM30sXFxzXFxkezEsM30sXFxzXFxkezEsM30oPzosXFxzWzAtOVxcLl0rKT9cXCkpXFxzKihcXGR7MSwzfSk/KCUpPy8pO1xuICAgICAgICAgICAgICBpZihtM1syXSl7XG4gICAgICAgICAgICAgICAgc3RvcCA9IHBhcnNlRmxvYXQobTNbMl0pO1xuICAgICAgICAgICAgICAgIGlmKG0zWzNdKXsgLy8gcGVyY2VudGFnZVxuICAgICAgICAgICAgICAgICAgc3RvcCAvPSAxMDA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHN0b3AgPSBpICogc3RlcDtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBncmFkaWVudC5jb2xvclN0b3BzLnB1c2goe1xuICAgICAgICAgICAgICAgIGNvbG9yOiBtM1sxXSxcbiAgICAgICAgICAgICAgICBzdG9wOiBzdG9wXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBicmVhaztcblxuICAgICAgICBjYXNlICctd2Via2l0LXJhZGlhbC1ncmFkaWVudCc6XG4gICAgICAgIGNhc2UgJy1tb3otcmFkaWFsLWdyYWRpZW50JzpcbiAgICAgICAgY2FzZSAnLW8tcmFkaWFsLWdyYWRpZW50JzpcblxuICAgICAgICAgIGdyYWRpZW50ID0ge1xuICAgICAgICAgICAgdHlwZTogJ2NpcmNsZScsXG4gICAgICAgICAgICB4MDogMCxcbiAgICAgICAgICAgIHkwOiAwLFxuICAgICAgICAgICAgeDE6IGJvdW5kcy53aWR0aCxcbiAgICAgICAgICAgIHkxOiBib3VuZHMuaGVpZ2h0LFxuICAgICAgICAgICAgY3g6IDAsXG4gICAgICAgICAgICBjeTogMCxcbiAgICAgICAgICAgIHJ4OiAwLFxuICAgICAgICAgICAgcnk6IDAsXG4gICAgICAgICAgICBjb2xvclN0b3BzOiBbXVxuICAgICAgICAgIH07XG5cbiAgICAgICAgICAvLyBjZW50ZXJcbiAgICAgICAgICBtMiA9IG0xWzJdLm1hdGNoKC8oXFxkezEsM30pJT9cXHMoXFxkezEsM30pJT8vKTtcbiAgICAgICAgICBpZihtMil7XG4gICAgICAgICAgICBncmFkaWVudC5jeCA9IChtMlsxXSAqIGJvdW5kcy53aWR0aCkgLyAxMDA7XG4gICAgICAgICAgICBncmFkaWVudC5jeSA9IChtMlsyXSAqIGJvdW5kcy5oZWlnaHQpIC8gMTAwO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIHNpemVcbiAgICAgICAgICBtMiA9IG0xWzNdLm1hdGNoKC9cXHcrLyk7XG4gICAgICAgICAgbTMgPSBtMVs0XS5tYXRjaCgvW2EtelxcLV0qLyk7XG4gICAgICAgICAgaWYobTIgJiYgbTMpe1xuICAgICAgICAgICAgc3dpdGNoKG0zWzBdKXtcbiAgICAgICAgICAgICAgY2FzZSAnZmFydGhlc3QtY29ybmVyJzpcbiAgICAgICAgICAgICAgY2FzZSAnY292ZXInOiAvLyBpcyBlcXVpdmFsZW50IHRvIGZhcnRoZXN0LWNvcm5lclxuICAgICAgICAgICAgICBjYXNlICcnOiAvLyBtb3ppbGxhIHJlbW92ZXMgXCJjb3ZlclwiIGZyb20gZGVmaW5pdGlvbiA6KFxuICAgICAgICAgICAgICAgIHRsID0gTWF0aC5zcXJ0KE1hdGgucG93KGdyYWRpZW50LmN4LCAyKSArIE1hdGgucG93KGdyYWRpZW50LmN5LCAyKSk7XG4gICAgICAgICAgICAgICAgdHIgPSBNYXRoLnNxcnQoTWF0aC5wb3coZ3JhZGllbnQuY3gsIDIpICsgTWF0aC5wb3coZ3JhZGllbnQueTEgLSBncmFkaWVudC5jeSwgMikpO1xuICAgICAgICAgICAgICAgIGJyID0gTWF0aC5zcXJ0KE1hdGgucG93KGdyYWRpZW50LngxIC0gZ3JhZGllbnQuY3gsIDIpICsgTWF0aC5wb3coZ3JhZGllbnQueTEgLSBncmFkaWVudC5jeSwgMikpO1xuICAgICAgICAgICAgICAgIGJsID0gTWF0aC5zcXJ0KE1hdGgucG93KGdyYWRpZW50LngxIC0gZ3JhZGllbnQuY3gsIDIpICsgTWF0aC5wb3coZ3JhZGllbnQuY3ksIDIpKTtcbiAgICAgICAgICAgICAgICBncmFkaWVudC5yeCA9IGdyYWRpZW50LnJ5ID0gTWF0aC5tYXgodGwsIHRyLCBiciwgYmwpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICBjYXNlICdjbG9zZXN0LWNvcm5lcic6XG4gICAgICAgICAgICAgICAgdGwgPSBNYXRoLnNxcnQoTWF0aC5wb3coZ3JhZGllbnQuY3gsIDIpICsgTWF0aC5wb3coZ3JhZGllbnQuY3ksIDIpKTtcbiAgICAgICAgICAgICAgICB0ciA9IE1hdGguc3FydChNYXRoLnBvdyhncmFkaWVudC5jeCwgMikgKyBNYXRoLnBvdyhncmFkaWVudC55MSAtIGdyYWRpZW50LmN5LCAyKSk7XG4gICAgICAgICAgICAgICAgYnIgPSBNYXRoLnNxcnQoTWF0aC5wb3coZ3JhZGllbnQueDEgLSBncmFkaWVudC5jeCwgMikgKyBNYXRoLnBvdyhncmFkaWVudC55MSAtIGdyYWRpZW50LmN5LCAyKSk7XG4gICAgICAgICAgICAgICAgYmwgPSBNYXRoLnNxcnQoTWF0aC5wb3coZ3JhZGllbnQueDEgLSBncmFkaWVudC5jeCwgMikgKyBNYXRoLnBvdyhncmFkaWVudC5jeSwgMikpO1xuICAgICAgICAgICAgICAgIGdyYWRpZW50LnJ4ID0gZ3JhZGllbnQucnkgPSBNYXRoLm1pbih0bCwgdHIsIGJyLCBibCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIGNhc2UgJ2ZhcnRoZXN0LXNpZGUnOlxuICAgICAgICAgICAgICAgIGlmKG0yWzBdID09PSAnY2lyY2xlJyl7XG4gICAgICAgICAgICAgICAgICBncmFkaWVudC5yeCA9IGdyYWRpZW50LnJ5ID0gTWF0aC5tYXgoXG4gICAgICAgICAgICAgICAgICAgIGdyYWRpZW50LmN4LFxuICAgICAgICAgICAgICAgICAgICBncmFkaWVudC5jeSxcbiAgICAgICAgICAgICAgICAgICAgZ3JhZGllbnQueDEgLSBncmFkaWVudC5jeCxcbiAgICAgICAgICAgICAgICAgICAgZ3JhZGllbnQueTEgLSBncmFkaWVudC5jeVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7IC8vIGVsbGlwc2VcblxuICAgICAgICAgICAgICAgICAgZ3JhZGllbnQudHlwZSA9IG0yWzBdO1xuXG4gICAgICAgICAgICAgICAgICBncmFkaWVudC5yeCA9IE1hdGgubWF4KFxuICAgICAgICAgICAgICAgICAgICBncmFkaWVudC5jeCxcbiAgICAgICAgICAgICAgICAgICAgZ3JhZGllbnQueDEgLSBncmFkaWVudC5jeFxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgZ3JhZGllbnQucnkgPSBNYXRoLm1heChcbiAgICAgICAgICAgICAgICAgICAgZ3JhZGllbnQuY3ksXG4gICAgICAgICAgICAgICAgICAgIGdyYWRpZW50LnkxIC0gZ3JhZGllbnQuY3lcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgIGNhc2UgJ2Nsb3Nlc3Qtc2lkZSc6XG4gICAgICAgICAgICAgIGNhc2UgJ2NvbnRhaW4nOiAvLyBpcyBlcXVpdmFsZW50IHRvIGNsb3Nlc3Qtc2lkZVxuICAgICAgICAgICAgICAgIGlmKG0yWzBdID09PSAnY2lyY2xlJyl7XG4gICAgICAgICAgICAgICAgICBncmFkaWVudC5yeCA9IGdyYWRpZW50LnJ5ID0gTWF0aC5taW4oXG4gICAgICAgICAgICAgICAgICAgIGdyYWRpZW50LmN4LFxuICAgICAgICAgICAgICAgICAgICBncmFkaWVudC5jeSxcbiAgICAgICAgICAgICAgICAgICAgZ3JhZGllbnQueDEgLSBncmFkaWVudC5jeCxcbiAgICAgICAgICAgICAgICAgICAgZ3JhZGllbnQueTEgLSBncmFkaWVudC5jeVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7IC8vIGVsbGlwc2VcblxuICAgICAgICAgICAgICAgICAgZ3JhZGllbnQudHlwZSA9IG0yWzBdO1xuXG4gICAgICAgICAgICAgICAgICBncmFkaWVudC5yeCA9IE1hdGgubWluKFxuICAgICAgICAgICAgICAgICAgICBncmFkaWVudC5jeCxcbiAgICAgICAgICAgICAgICAgICAgZ3JhZGllbnQueDEgLSBncmFkaWVudC5jeFxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgZ3JhZGllbnQucnkgPSBNYXRoLm1pbihcbiAgICAgICAgICAgICAgICAgICAgZ3JhZGllbnQuY3ksXG4gICAgICAgICAgICAgICAgICAgIGdyYWRpZW50LnkxIC0gZ3JhZGllbnQuY3lcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgICAgIC8vIFRPRE86IGFkZCBzdXBwb3J0IGZvciBcIjMwcHggNDBweFwiIHNpemVzICh3ZWJraXQgb25seSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBjb2xvciBzdG9wc1xuICAgICAgICAgIG0yID0gbTFbNV0ubWF0Y2goLygoPzpyZ2J8cmdiYSlcXChcXGR7MSwzfSxcXHNcXGR7MSwzfSxcXHNcXGR7MSwzfSg/OixcXHNbMC05XFwuXSspP1xcKSg/Olxcc1xcZHsxLDN9KD86JXxweCkpPykrL2cpO1xuICAgICAgICAgIGlmKG0yKXtcbiAgICAgICAgICAgIG0yTGVuID0gbTIubGVuZ3RoO1xuICAgICAgICAgICAgc3RlcCA9IDEgLyBNYXRoLm1heChtMkxlbiAtIDEsIDEpO1xuICAgICAgICAgICAgZm9yKGkgPSAwOyBpIDwgbTJMZW47IGkrPTEpe1xuICAgICAgICAgICAgICBtMyA9IG0yW2ldLm1hdGNoKC8oKD86cmdifHJnYmEpXFwoXFxkezEsM30sXFxzXFxkezEsM30sXFxzXFxkezEsM30oPzosXFxzWzAtOVxcLl0rKT9cXCkpXFxzKihcXGR7MSwzfSk/KCV8cHgpPy8pO1xuICAgICAgICAgICAgICBpZihtM1syXSl7XG4gICAgICAgICAgICAgICAgc3RvcCA9IHBhcnNlRmxvYXQobTNbMl0pO1xuICAgICAgICAgICAgICAgIGlmKG0zWzNdID09PSAnJScpe1xuICAgICAgICAgICAgICAgICAgc3RvcCAvPSAxMDA7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHsgLy8gcHggLSBzdHVwaWQgb3BlcmFcbiAgICAgICAgICAgICAgICAgIHN0b3AgLz0gYm91bmRzLndpZHRoO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBzdG9wID0gaSAqIHN0ZXA7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgZ3JhZGllbnQuY29sb3JTdG9wcy5wdXNoKHtcbiAgICAgICAgICAgICAgICBjb2xvcjogbTNbMV0sXG4gICAgICAgICAgICAgICAgc3RvcDogc3RvcFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGdyYWRpZW50O1xuICB9O1xuXG4gIGZ1bmN0aW9uIGFkZFNjcm9sbFN0b3BzKGdyYWQpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24oY29sb3JTdG9wKSB7XG4gICAgICB0cnkge1xuICAgICAgICBncmFkLmFkZENvbG9yU3RvcChjb2xvclN0b3Auc3RvcCwgY29sb3JTdG9wLmNvbG9yKTtcbiAgICAgIH1cbiAgICAgIGNhdGNoKGUpIHtcbiAgICAgICAgVXRpbC5sb2coWydmYWlsZWQgdG8gYWRkIGNvbG9yIHN0b3A6ICcsIGUsICc7IHRyaWVkIHRvIGFkZDogJywgY29sb3JTdG9wXSk7XG4gICAgICB9XG4gICAgfTtcbiAgfVxuXG4gIEdlbmVyYXRlLkdyYWRpZW50ID0gZnVuY3Rpb24oc3JjLCBib3VuZHMpIHtcbiAgICBpZihib3VuZHMud2lkdGggPT09IDAgfHwgYm91bmRzLmhlaWdodCA9PT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHZhciBjYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdjYW52YXMnKSxcbiAgICBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKSxcbiAgICBncmFkaWVudCwgZ3JhZDtcblxuICAgIGNhbnZhcy53aWR0aCA9IGJvdW5kcy53aWR0aDtcbiAgICBjYW52YXMuaGVpZ2h0ID0gYm91bmRzLmhlaWdodDtcblxuICAgIC8vIFRPRE86IGFkZCBzdXBwb3J0IGZvciBtdWx0aSBkZWZpbmVkIGJhY2tncm91bmQgZ3JhZGllbnRzXG4gICAgZ3JhZGllbnQgPSBfaHRtbDJjYW52YXMuR2VuZXJhdGUucGFyc2VHcmFkaWVudChzcmMsIGJvdW5kcyk7XG5cbiAgICBpZihncmFkaWVudCkge1xuICAgICAgc3dpdGNoKGdyYWRpZW50LnR5cGUpIHtcbiAgICAgICAgY2FzZSAnbGluZWFyJzpcbiAgICAgICAgICBncmFkID0gY3R4LmNyZWF0ZUxpbmVhckdyYWRpZW50KGdyYWRpZW50LngwLCBncmFkaWVudC55MCwgZ3JhZGllbnQueDEsIGdyYWRpZW50LnkxKTtcbiAgICAgICAgICBncmFkaWVudC5jb2xvclN0b3BzLmZvckVhY2goYWRkU2Nyb2xsU3RvcHMoZ3JhZCkpO1xuICAgICAgICAgIGN0eC5maWxsU3R5bGUgPSBncmFkO1xuICAgICAgICAgIGN0eC5maWxsUmVjdCgwLCAwLCBib3VuZHMud2lkdGgsIGJvdW5kcy5oZWlnaHQpO1xuICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgJ2NpcmNsZSc6XG4gICAgICAgICAgZ3JhZCA9IGN0eC5jcmVhdGVSYWRpYWxHcmFkaWVudChncmFkaWVudC5jeCwgZ3JhZGllbnQuY3ksIDAsIGdyYWRpZW50LmN4LCBncmFkaWVudC5jeSwgZ3JhZGllbnQucngpO1xuICAgICAgICAgIGdyYWRpZW50LmNvbG9yU3RvcHMuZm9yRWFjaChhZGRTY3JvbGxTdG9wcyhncmFkKSk7XG4gICAgICAgICAgY3R4LmZpbGxTdHlsZSA9IGdyYWQ7XG4gICAgICAgICAgY3R4LmZpbGxSZWN0KDAsIDAsIGJvdW5kcy53aWR0aCwgYm91bmRzLmhlaWdodCk7XG4gICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgY2FzZSAnZWxsaXBzZSc6XG4gICAgICAgICAgdmFyIGNhbnZhc1JhZGlhbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpLFxuICAgICAgICAgICAgY3R4UmFkaWFsID0gY2FudmFzUmFkaWFsLmdldENvbnRleHQoJzJkJyksXG4gICAgICAgICAgICByaSA9IE1hdGgubWF4KGdyYWRpZW50LnJ4LCBncmFkaWVudC5yeSksXG4gICAgICAgICAgICBkaSA9IHJpICogMjtcblxuICAgICAgICAgIGNhbnZhc1JhZGlhbC53aWR0aCA9IGNhbnZhc1JhZGlhbC5oZWlnaHQgPSBkaTtcblxuICAgICAgICAgIGdyYWQgPSBjdHhSYWRpYWwuY3JlYXRlUmFkaWFsR3JhZGllbnQoZ3JhZGllbnQucngsIGdyYWRpZW50LnJ5LCAwLCBncmFkaWVudC5yeCwgZ3JhZGllbnQucnksIHJpKTtcbiAgICAgICAgICBncmFkaWVudC5jb2xvclN0b3BzLmZvckVhY2goYWRkU2Nyb2xsU3RvcHMoZ3JhZCkpO1xuXG4gICAgICAgICAgY3R4UmFkaWFsLmZpbGxTdHlsZSA9IGdyYWQ7XG4gICAgICAgICAgY3R4UmFkaWFsLmZpbGxSZWN0KDAsIDAsIGRpLCBkaSk7XG5cbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gZ3JhZGllbnQuY29sb3JTdG9wc1tncmFkaWVudC5jb2xvclN0b3BzLmxlbmd0aCAtIDFdLmNvbG9yO1xuICAgICAgICAgIGN0eC5maWxsUmVjdCgwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgICAgICAgIGN0eC5kcmF3SW1hZ2UoY2FudmFzUmFkaWFsLCBncmFkaWVudC5jeCAtIGdyYWRpZW50LnJ4LCBncmFkaWVudC5jeSAtIGdyYWRpZW50LnJ5LCAyICogZ3JhZGllbnQucngsIDIgKiBncmFkaWVudC5yeSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGNhbnZhcztcbiAgfTtcblxuICBHZW5lcmF0ZS5MaXN0QWxwaGEgPSBmdW5jdGlvbihudW1iZXIpIHtcbiAgICB2YXIgdG1wID0gXCJcIixcbiAgICBtb2R1bHVzO1xuXG4gICAgZG8ge1xuICAgICAgbW9kdWx1cyA9IG51bWJlciAlIDI2O1xuICAgICAgdG1wID0gU3RyaW5nLmZyb21DaGFyQ29kZSgobW9kdWx1cykgKyA2NCkgKyB0bXA7XG4gICAgICBudW1iZXIgPSBudW1iZXIgLyAyNjtcbiAgICB9d2hpbGUoKG51bWJlcioyNikgPiAyNik7XG5cbiAgICByZXR1cm4gdG1wO1xuICB9O1xuXG4gIEdlbmVyYXRlLkxpc3RSb21hbiA9IGZ1bmN0aW9uKG51bWJlcikge1xuICAgIHZhciByb21hbkFycmF5ID0gW1wiTVwiLCBcIkNNXCIsIFwiRFwiLCBcIkNEXCIsIFwiQ1wiLCBcIlhDXCIsIFwiTFwiLCBcIlhMXCIsIFwiWFwiLCBcIklYXCIsIFwiVlwiLCBcIklWXCIsIFwiSVwiXSxcbiAgICBkZWNpbWFsID0gWzEwMDAsIDkwMCwgNTAwLCA0MDAsIDEwMCwgOTAsIDUwLCA0MCwgMTAsIDksIDUsIDQsIDFdLFxuICAgIHJvbWFuID0gXCJcIixcbiAgICB2LFxuICAgIGxlbiA9IHJvbWFuQXJyYXkubGVuZ3RoO1xuXG4gICAgaWYgKG51bWJlciA8PSAwIHx8IG51bWJlciA+PSA0MDAwKSB7XG4gICAgICByZXR1cm4gbnVtYmVyO1xuICAgIH1cblxuICAgIGZvciAodj0wOyB2IDwgbGVuOyB2Kz0xKSB7XG4gICAgICB3aGlsZSAobnVtYmVyID49IGRlY2ltYWxbdl0pIHtcbiAgICAgICAgbnVtYmVyIC09IGRlY2ltYWxbdl07XG4gICAgICAgIHJvbWFuICs9IHJvbWFuQXJyYXlbdl07XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHJvbWFuO1xuICB9O1xufSkoKTtcbmZ1bmN0aW9uIGgyY1JlbmRlckNvbnRleHQod2lkdGgsIGhlaWdodCkge1xuICB2YXIgc3RvcmFnZSA9IFtdO1xuICByZXR1cm4ge1xuICAgIHN0b3JhZ2U6IHN0b3JhZ2UsXG4gICAgd2lkdGg6IHdpZHRoLFxuICAgIGhlaWdodDogaGVpZ2h0LFxuICAgIGNsaXA6IGZ1bmN0aW9uKCkge1xuICAgICAgc3RvcmFnZS5wdXNoKHtcbiAgICAgICAgdHlwZTogXCJmdW5jdGlvblwiLFxuICAgICAgICBuYW1lOiBcImNsaXBcIixcbiAgICAgICAgJ2FyZ3VtZW50cyc6IGFyZ3VtZW50c1xuICAgICAgfSk7XG4gICAgfSxcbiAgICB0cmFuc2xhdGU6IGZ1bmN0aW9uKCkge1xuICAgICAgc3RvcmFnZS5wdXNoKHtcbiAgICAgICAgdHlwZTogXCJmdW5jdGlvblwiLFxuICAgICAgICBuYW1lOiBcInRyYW5zbGF0ZVwiLFxuICAgICAgICAnYXJndW1lbnRzJzogYXJndW1lbnRzXG4gICAgICB9KTtcbiAgICB9LFxuICAgIGZpbGw6IGZ1bmN0aW9uKCkge1xuICAgICAgc3RvcmFnZS5wdXNoKHtcbiAgICAgICAgdHlwZTogXCJmdW5jdGlvblwiLFxuICAgICAgICBuYW1lOiBcImZpbGxcIixcbiAgICAgICAgJ2FyZ3VtZW50cyc6IGFyZ3VtZW50c1xuICAgICAgfSk7XG4gICAgfSxcbiAgICBzYXZlOiBmdW5jdGlvbigpIHtcbiAgICAgIHN0b3JhZ2UucHVzaCh7XG4gICAgICAgIHR5cGU6IFwiZnVuY3Rpb25cIixcbiAgICAgICAgbmFtZTogXCJzYXZlXCIsXG4gICAgICAgICdhcmd1bWVudHMnOiBhcmd1bWVudHNcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgcmVzdG9yZTogZnVuY3Rpb24oKSB7XG4gICAgICBzdG9yYWdlLnB1c2goe1xuICAgICAgICB0eXBlOiBcImZ1bmN0aW9uXCIsXG4gICAgICAgIG5hbWU6IFwicmVzdG9yZVwiLFxuICAgICAgICAnYXJndW1lbnRzJzogYXJndW1lbnRzXG4gICAgICB9KTtcbiAgICB9LFxuICAgIGZpbGxSZWN0OiBmdW5jdGlvbiAoKSB7XG4gICAgICBzdG9yYWdlLnB1c2goe1xuICAgICAgICB0eXBlOiBcImZ1bmN0aW9uXCIsXG4gICAgICAgIG5hbWU6IFwiZmlsbFJlY3RcIixcbiAgICAgICAgJ2FyZ3VtZW50cyc6IGFyZ3VtZW50c1xuICAgICAgfSk7XG4gICAgfSxcbiAgICBjcmVhdGVQYXR0ZXJuOiBmdW5jdGlvbigpIHtcbiAgICAgIHN0b3JhZ2UucHVzaCh7XG4gICAgICAgIHR5cGU6IFwiZnVuY3Rpb25cIixcbiAgICAgICAgbmFtZTogXCJjcmVhdGVQYXR0ZXJuXCIsXG4gICAgICAgICdhcmd1bWVudHMnOiBhcmd1bWVudHNcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgZHJhd1NoYXBlOiBmdW5jdGlvbigpIHtcblxuICAgICAgdmFyIHNoYXBlID0gW107XG5cbiAgICAgIHN0b3JhZ2UucHVzaCh7XG4gICAgICAgIHR5cGU6IFwiZnVuY3Rpb25cIixcbiAgICAgICAgbmFtZTogXCJkcmF3U2hhcGVcIixcbiAgICAgICAgJ2FyZ3VtZW50cyc6IHNoYXBlXG4gICAgICB9KTtcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbW92ZVRvOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICBzaGFwZS5wdXNoKHtcbiAgICAgICAgICAgIG5hbWU6IFwibW92ZVRvXCIsXG4gICAgICAgICAgICAnYXJndW1lbnRzJzogYXJndW1lbnRzXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGxpbmVUbzogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgc2hhcGUucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiBcImxpbmVUb1wiLFxuICAgICAgICAgICAgJ2FyZ3VtZW50cyc6IGFyZ3VtZW50c1xuICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICBhcmNUbzogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgc2hhcGUucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiBcImFyY1RvXCIsXG4gICAgICAgICAgICAnYXJndW1lbnRzJzogYXJndW1lbnRzXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGJlemllckN1cnZlVG86IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHNoYXBlLnB1c2goe1xuICAgICAgICAgICAgbmFtZTogXCJiZXppZXJDdXJ2ZVRvXCIsXG4gICAgICAgICAgICAnYXJndW1lbnRzJzogYXJndW1lbnRzXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIHF1YWRyYXRpY0N1cnZlVG86IGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHNoYXBlLnB1c2goe1xuICAgICAgICAgICAgbmFtZTogXCJxdWFkcmF0aWNDdXJ2ZVRvXCIsXG4gICAgICAgICAgICAnYXJndW1lbnRzJzogYXJndW1lbnRzXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICB9LFxuICAgIGRyYXdJbWFnZTogZnVuY3Rpb24gKCkge1xuICAgICAgc3RvcmFnZS5wdXNoKHtcbiAgICAgICAgdHlwZTogXCJmdW5jdGlvblwiLFxuICAgICAgICBuYW1lOiBcImRyYXdJbWFnZVwiLFxuICAgICAgICAnYXJndW1lbnRzJzogYXJndW1lbnRzXG4gICAgICB9KTtcbiAgICB9LFxuICAgIGZpbGxUZXh0OiBmdW5jdGlvbiAoKSB7XG4gICAgICBzdG9yYWdlLnB1c2goe1xuICAgICAgICB0eXBlOiBcImZ1bmN0aW9uXCIsXG4gICAgICAgIG5hbWU6IFwiZmlsbFRleHRcIixcbiAgICAgICAgJ2FyZ3VtZW50cyc6IGFyZ3VtZW50c1xuICAgICAgfSk7XG4gICAgfSxcbiAgICBzZXRWYXJpYWJsZTogZnVuY3Rpb24gKHZhcmlhYmxlLCB2YWx1ZSkge1xuICAgICAgc3RvcmFnZS5wdXNoKHtcbiAgICAgICAgdHlwZTogXCJ2YXJpYWJsZVwiLFxuICAgICAgICBuYW1lOiB2YXJpYWJsZSxcbiAgICAgICAgJ2FyZ3VtZW50cyc6IHZhbHVlXG4gICAgICB9KTtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gIH07XG59XG5faHRtbDJjYW52YXMuUGFyc2UgPSBmdW5jdGlvbiAoaW1hZ2VzLCBvcHRpb25zLCBjYikge1xuICB3aW5kb3cuc2Nyb2xsKDAsMCk7XG5cbiAgdmFyIGVsZW1lbnQgPSAoKCBvcHRpb25zLmVsZW1lbnRzID09PSB1bmRlZmluZWQgKSA/IGRvY3VtZW50LmJvZHkgOiBvcHRpb25zLmVsZW1lbnRzWzBdKSwgLy8gc2VsZWN0IGJvZHkgYnkgZGVmYXVsdFxuICBudW1EcmF3cyA9IDAsXG4gIGRvYyA9IGVsZW1lbnQub3duZXJEb2N1bWVudCxcbiAgVXRpbCA9IF9odG1sMmNhbnZhcy5VdGlsLFxuICBzdXBwb3J0ID0gVXRpbC5TdXBwb3J0KG9wdGlvbnMsIGRvYyksXG4gIGlnbm9yZUVsZW1lbnRzUmVnRXhwID0gbmV3IFJlZ0V4cChcIihcIiArIG9wdGlvbnMuaWdub3JlRWxlbWVudHMgKyBcIilcIiksXG4gIGJvZHkgPSBkb2MuYm9keSxcbiAgZ2V0Q1NTID0gVXRpbC5nZXRDU1MsXG4gIHBzZXVkb0hpZGUgPSBcIl9fX2h0bWwyY2FudmFzX19fcHNldWRvZWxlbWVudFwiLFxuICBoaWRlUHNldWRvRWxlbWVudHNTdHlsZXMgPSBkb2MuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTtcblxuICBoaWRlUHNldWRvRWxlbWVudHNTdHlsZXMuaW5uZXJIVE1MID0gJy4nICsgcHNldWRvSGlkZSArXG4gICctcGFyZW50OmJlZm9yZSB7IGNvbnRlbnQ6IFwiXCIgIWltcG9ydGFudDsgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50OyB9JyArXG4gICcuJyArIHBzZXVkb0hpZGUgKyAnLXBhcmVudDphZnRlciB7IGNvbnRlbnQ6IFwiXCIgIWltcG9ydGFudDsgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50OyB9JztcblxuICBib2R5LmFwcGVuZENoaWxkKGhpZGVQc2V1ZG9FbGVtZW50c1N0eWxlcyk7XG5cbiAgaW1hZ2VzID0gaW1hZ2VzIHx8IHt9O1xuXG4gIGluaXQoKTtcblxuICBmdW5jdGlvbiBpbml0KCkge1xuICAgIHZhciBiYWNrZ3JvdW5kID0gZ2V0Q1NTKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCwgXCJiYWNrZ3JvdW5kQ29sb3JcIiksXG4gICAgICB0cmFuc3BhcmVudEJhY2tncm91bmQgPSAoVXRpbC5pc1RyYW5zcGFyZW50KGJhY2tncm91bmQpICYmIGVsZW1lbnQgPT09IGRvY3VtZW50LmJvZHkpLFxuICAgICAgc3RhY2sgPSByZW5kZXJFbGVtZW50KGVsZW1lbnQsIG51bGwsIGZhbHNlLCB0cmFuc3BhcmVudEJhY2tncm91bmQpO1xuXG4gICAgLy8gY3JlYXRlIHBzZXVkbyBlbGVtZW50cyBpbiBhIHNpbmdsZSBwYXNzIHRvIHByZXZlbnQgc3luY2hyb25vdXMgbGF5b3V0c1xuICAgIGFkZFBzZXVkb0VsZW1lbnRzKGVsZW1lbnQpO1xuXG4gICAgcGFyc2VDaGlsZHJlbihlbGVtZW50LCBzdGFjaywgZnVuY3Rpb24oKSB7XG4gICAgICBpZiAodHJhbnNwYXJlbnRCYWNrZ3JvdW5kKSB7XG4gICAgICAgIGJhY2tncm91bmQgPSBzdGFjay5iYWNrZ3JvdW5kQ29sb3I7XG4gICAgICB9XG5cbiAgICAgIHJlbW92ZVBzZXVkb0VsZW1lbnRzKCk7XG5cbiAgICAgIFV0aWwubG9nKCdEb25lIHBhcnNpbmcsIG1vdmluZyB0byBSZW5kZXIuJyk7XG5cbiAgICAgIGNiKHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBiYWNrZ3JvdW5kLFxuICAgICAgICBzdGFjazogc3RhY2tcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG5cbiAgLy8gR2l2ZW4gYSByb290IGVsZW1lbnQsIGZpbmQgYWxsIHBzZXVkbyBlbGVtZW50cyBiZWxvdywgY3JlYXRlIGVsZW1lbnRzIG1vY2tpbmcgcHNldWRvIGVsZW1lbnQgc3R5bGVzXG4gIC8vIHNvIHdlIGNhbiBwcm9jZXNzIHRoZW0gYXMgbm9ybWFsIGVsZW1lbnRzLCBhbmQgaGlkZSB0aGUgb3JpZ2luYWwgcHNldWRvIGVsZW1lbnRzIHNvIHRoZXkgZG9uJ3QgaW50ZXJmZXJlXG4gIC8vIHdpdGggbGF5b3V0LlxuICBmdW5jdGlvbiBhZGRQc2V1ZG9FbGVtZW50cyhlbCkge1xuICAgIC8vIFRoZXNlIGFyZSBkb25lIGluIGRpc2NyZXRlIHN0ZXBzIHRvIHByZXZlbnQgYSByZWxheW91dCBsb29wIGNhdXNlZCBieSBhZGRDbGFzcygpIGludmFsaWRhdGluZ1xuICAgIC8vIGxheW91dHMgJiBnZXRQc2V1ZG9FbGVtZW50IGNhbGxpbmcgZ2V0Q29tcHV0ZWRTdHlsZS5cbiAgICB2YXIgam9icyA9IFtdLCBjbGFzc2VzID0gW107XG4gICAgZ2V0UHNldWRvRWxlbWVudENsYXNzZXMoKTtcbiAgICBmaW5kUHNldWRvRWxlbWVudHMoZWwpO1xuICAgIHJ1bkpvYnMoKTtcblxuICAgIGZ1bmN0aW9uIGdldFBzZXVkb0VsZW1lbnRDbGFzc2VzKCl7XG4gICAgICB2YXIgZmluZFBzdWVkb0VscyA9IC86YmVmb3JlfDphZnRlci87XG4gICAgICB2YXIgc2hlZXRzID0gZG9jdW1lbnQuc3R5bGVTaGVldHM7XG4gICAgICBmb3IgKHZhciBpID0gMCwgaiA9IHNoZWV0cy5sZW5ndGg7IGkgPCBqOyBpKyspIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICB2YXIgcnVsZXMgPSBzaGVldHNbaV0uY3NzUnVsZXM7XG4gICAgICAgICAgZm9yICh2YXIgayA9IDAsIGwgPSBydWxlcy5sZW5ndGg7IGsgPCBsOyBrKyspIHtcbiAgICAgICAgICAgIGlmKGZpbmRQc3VlZG9FbHMudGVzdChydWxlc1trXS5zZWxlY3RvclRleHQpKSB7XG4gICAgICAgICAgICAgIGNsYXNzZXMucHVzaChydWxlc1trXS5zZWxlY3RvclRleHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaChlKSB7IC8vIHdpbGwgdGhyb3cgc2VjdXJpdHkgZXhjZXB0aW9uIGZvciBzdHlsZSBzaGVldHMgbG9hZGVkIGZyb20gZXh0ZXJuYWwgZG9tYWluc1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIFRyaW0gb2ZmIHRoZSA6YWZ0ZXIgYW5kIDpiZWZvcmUgKG9yIDo6YWZ0ZXIgYW5kIDo6YmVmb3JlKVxuICAgICAgZm9yIChpID0gMCwgaiA9IGNsYXNzZXMubGVuZ3RoOyBpIDwgajsgaSsrKSB7XG4gICAgICAgIGNsYXNzZXNbaV0gPSBjbGFzc2VzW2ldLm1hdGNoKC8oXlteOl0qKS8pWzFdO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFVzaW5nIHRoZSBsaXN0IG9mIGVsZW1lbnRzIHdlIGtub3cgaG93IHBzZXVkbyBlbCBzdHlsZXMsIGNyZWF0ZSBmYWtlIHBzZXVkbyBlbGVtZW50cy5cbiAgICBmdW5jdGlvbiBmaW5kUHNldWRvRWxlbWVudHMoZWwpIHtcbiAgICAgIHZhciBlbHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKGNsYXNzZXMuam9pbignLCcpKTtcbiAgICAgIGZvcih2YXIgaSA9IDAsIGogPSBlbHMubGVuZ3RoOyBpIDwgajsgaSsrKSB7XG4gICAgICAgIGNyZWF0ZVBzZXVkb0VsZW1lbnRzKGVsc1tpXSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlIHBzZXVkbyBlbGVtZW50cyAmIGFkZCB0aGVtIHRvIGEgam9iIHF1ZXVlLlxuICAgIGZ1bmN0aW9uIGNyZWF0ZVBzZXVkb0VsZW1lbnRzKGVsKSB7XG4gICAgICB2YXIgYmVmb3JlID0gZ2V0UHNldWRvRWxlbWVudChlbCwgJzpiZWZvcmUnKSxcbiAgICAgIGFmdGVyID0gZ2V0UHNldWRvRWxlbWVudChlbCwgJzphZnRlcicpO1xuXG4gICAgICBpZihiZWZvcmUpIHtcbiAgICAgICAgam9icy5wdXNoKHt0eXBlOiAnYmVmb3JlJywgcHNldWRvOiBiZWZvcmUsIGVsOiBlbH0pO1xuICAgICAgfVxuXG4gICAgICBpZiAoYWZ0ZXIpIHtcbiAgICAgICAgam9icy5wdXNoKHt0eXBlOiAnYWZ0ZXInLCBwc2V1ZG86IGFmdGVyLCBlbDogZWx9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBBZGRzIGEgY2xhc3MgdG8gdGhlIHBzZXVkbydzIHBhcmVudCB0byBwcmV2ZW50IHRoZSBvcmlnaW5hbCBiZWZvcmUvYWZ0ZXIgZnJvbSBtZXNzaW5nXG4gICAgLy8gd2l0aCBsYXlvdXRzLlxuICAgIC8vIEV4ZWN1dGUgdGhlIGluc2VydHMgJiBhZGRDbGFzcygpIGNhbGxzIGluIGEgYmF0Y2ggdG8gcHJldmVudCByZWxheW91dHMuXG4gICAgZnVuY3Rpb24gcnVuSm9icygpIHtcbiAgICAgIC8vIEFkZCBDbGFzc1xuICAgICAgam9icy5mb3JFYWNoKGZ1bmN0aW9uKGpvYil7XG4gICAgICAgIGFkZENsYXNzKGpvYi5lbCwgcHNldWRvSGlkZSArIFwiLXBhcmVudFwiKTtcbiAgICAgIH0pO1xuXG4gICAgICAvLyBJbnNlcnQgZWxcbiAgICAgIGpvYnMuZm9yRWFjaChmdW5jdGlvbihqb2Ipe1xuICAgICAgICBpZihqb2IudHlwZSA9PT0gJ2JlZm9yZScpe1xuICAgICAgICAgIGpvYi5lbC5pbnNlcnRCZWZvcmUoam9iLnBzZXVkbywgam9iLmVsLmZpcnN0Q2hpbGQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGpvYi5lbC5hcHBlbmRDaGlsZChqb2IucHNldWRvKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cblxuXG4gIC8vIERlbGV0ZSBvdXIgZmFrZSBwc2V1ZG8gZWxlbWVudHMgZnJvbSB0aGUgRE9NLiBUaGlzIHdpbGwgcmVtb3ZlIHRob3NlIGFjdHVhbCBlbGVtZW50c1xuICAvLyBhbmQgdGhlIGNsYXNzZXMgb24gdGhlaXIgcGFyZW50cyB0aGF0IGhpZGUgdGhlIGFjdHVhbCBwc2V1ZG8gZWxlbWVudHMuXG4gIC8vIE5vdGUgdGhhdCBOb2RlTGlzdHMgYXJlICdsaXZlJyBjb2xsZWN0aW9ucyBzbyB5b3UgY2FuJ3QgdXNlIGEgZm9yIGxvb3AgaGVyZS4gVGhleSBhcmVcbiAgLy8gYWN0dWFsbHkgZGVsZXRlZCBmcm9tIHRoZSBOb2RlTGlzdCBhZnRlciBlYWNoIGl0ZXJhdGlvbi5cbiAgZnVuY3Rpb24gcmVtb3ZlUHNldWRvRWxlbWVudHMoKXtcbiAgICAvLyBkZWxldGUgcHNldWRvIGVsZW1lbnRzXG4gICAgYm9keS5yZW1vdmVDaGlsZChoaWRlUHNldWRvRWxlbWVudHNTdHlsZXMpO1xuICAgIHZhciBwc2V1ZG9zID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShwc2V1ZG9IaWRlICsgXCItZWxlbWVudFwiKTtcbiAgICB3aGlsZSAocHNldWRvcy5sZW5ndGgpIHtcbiAgICAgIHBzZXVkb3NbMF0ucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChwc2V1ZG9zWzBdKTtcbiAgICB9XG5cbiAgICAvLyBSZW1vdmUgcHNldWRvIGhpZGluZyBjbGFzc2VzXG4gICAgdmFyIHBhcmVudHMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKHBzZXVkb0hpZGUgKyBcIi1wYXJlbnRcIik7XG4gICAgd2hpbGUocGFyZW50cy5sZW5ndGgpIHtcbiAgICAgIHJlbW92ZUNsYXNzKHBhcmVudHNbMF0sIHBzZXVkb0hpZGUgKyBcIi1wYXJlbnRcIik7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gYWRkQ2xhc3MgKGVsLCBjbGFzc05hbWUpIHtcbiAgICBpZiAoZWwuY2xhc3NMaXN0KSB7XG4gICAgICBlbC5jbGFzc0xpc3QuYWRkKGNsYXNzTmFtZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGVsLmNsYXNzTmFtZSA9IGVsLmNsYXNzTmFtZSArIFwiIFwiICsgY2xhc3NOYW1lO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHJlbW92ZUNsYXNzIChlbCwgY2xhc3NOYW1lKSB7XG4gICAgaWYgKGVsLmNsYXNzTGlzdCkge1xuICAgICAgZWwuY2xhc3NMaXN0LnJlbW92ZShjbGFzc05hbWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBlbC5jbGFzc05hbWUgPSBlbC5jbGFzc05hbWUucmVwbGFjZShjbGFzc05hbWUsIFwiXCIpLnRyaW0oKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBoYXNDbGFzcyAoZWwsIGNsYXNzTmFtZSkge1xuICAgIHJldHVybiBlbC5jbGFzc05hbWUuaW5kZXhPZihjbGFzc05hbWUpID4gLTE7XG4gIH1cblxuICAvLyBOb3RlIHRoYXQgdGhpcyBkb2Vzbid0IHdvcmsgaW4gPCBJRTgsIGJ1dCB3ZSBkb24ndCBzdXBwb3J0IHRoYXQgYW55aG93XG4gIGZ1bmN0aW9uIG5vZGVMaXN0VG9BcnJheSAobm9kZUxpc3QpIHtcbiAgICByZXR1cm4gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwobm9kZUxpc3QpO1xuICB9XG5cbiAgZnVuY3Rpb24gZG9jdW1lbnRXaWR0aCAoKSB7XG4gICAgcmV0dXJuIE1hdGgubWF4KFxuICAgICAgTWF0aC5tYXgoZG9jLmJvZHkuc2Nyb2xsV2lkdGgsIGRvYy5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsV2lkdGgpLFxuICAgICAgTWF0aC5tYXgoZG9jLmJvZHkub2Zmc2V0V2lkdGgsIGRvYy5kb2N1bWVudEVsZW1lbnQub2Zmc2V0V2lkdGgpLFxuICAgICAgTWF0aC5tYXgoZG9jLmJvZHkuY2xpZW50V2lkdGgsIGRvYy5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGgpXG4gICAgICApO1xuICB9XG5cbiAgZnVuY3Rpb24gZG9jdW1lbnRIZWlnaHQgKCkge1xuICAgIHJldHVybiBNYXRoLm1heChcbiAgICAgIE1hdGgubWF4KGRvYy5ib2R5LnNjcm9sbEhlaWdodCwgZG9jLmRvY3VtZW50RWxlbWVudC5zY3JvbGxIZWlnaHQpLFxuICAgICAgTWF0aC5tYXgoZG9jLmJvZHkub2Zmc2V0SGVpZ2h0LCBkb2MuZG9jdW1lbnRFbGVtZW50Lm9mZnNldEhlaWdodCksXG4gICAgICBNYXRoLm1heChkb2MuYm9keS5jbGllbnRIZWlnaHQsIGRvYy5kb2N1bWVudEVsZW1lbnQuY2xpZW50SGVpZ2h0KVxuICAgICAgKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGdldENTU0ludChlbGVtZW50LCBhdHRyaWJ1dGUpIHtcbiAgICB2YXIgdmFsID0gcGFyc2VJbnQoZ2V0Q1NTKGVsZW1lbnQsIGF0dHJpYnV0ZSksIDEwKTtcbiAgICByZXR1cm4gKGlzTmFOKHZhbCkpID8gMCA6IHZhbDsgLy8gYm9yZGVycyBpbiBvbGQgSUUgYXJlIHRocm93aW5nICdtZWRpdW0nIGZvciBkZW1vLmh0bWxcbiAgfVxuXG4gIGZ1bmN0aW9uIHJlbmRlclJlY3QgKGN0eCwgeCwgeSwgdywgaCwgYmdjb2xvcikge1xuICAgIGlmIChiZ2NvbG9yICE9PSBcInRyYW5zcGFyZW50XCIpe1xuICAgICAgY3R4LnNldFZhcmlhYmxlKFwiZmlsbFN0eWxlXCIsIGJnY29sb3IpO1xuICAgICAgY3R4LmZpbGxSZWN0KHgsIHksIHcsIGgpO1xuICAgICAgbnVtRHJhd3MrPTE7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gY2FwaXRhbGl6ZShtLCBwMSwgcDIpIHtcbiAgICBpZiAobS5sZW5ndGggPiAwKSB7XG4gICAgICByZXR1cm4gcDEgKyBwMi50b1VwcGVyQ2FzZSgpO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHRleHRUcmFuc2Zvcm0gKHRleHQsIHRyYW5zZm9ybSkge1xuICAgIHN3aXRjaCh0cmFuc2Zvcm0pe1xuICAgICAgY2FzZSBcImxvd2VyY2FzZVwiOlxuICAgICAgICByZXR1cm4gdGV4dC50b0xvd2VyQ2FzZSgpO1xuICAgICAgY2FzZSBcImNhcGl0YWxpemVcIjpcbiAgICAgICAgcmV0dXJuIHRleHQucmVwbGFjZSggLyhefFxcc3w6fC18XFwofFxcKSkoW2Etel0pL2csIGNhcGl0YWxpemUpO1xuICAgICAgY2FzZSBcInVwcGVyY2FzZVwiOlxuICAgICAgICByZXR1cm4gdGV4dC50b1VwcGVyQ2FzZSgpO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIHRleHQ7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gbm9MZXR0ZXJTcGFjaW5nKGxldHRlcl9zcGFjaW5nKSB7XG4gICAgcmV0dXJuICgvXihub3JtYWx8bm9uZXwwcHgpJC8udGVzdChsZXR0ZXJfc3BhY2luZykpO1xuICB9XG5cbiAgZnVuY3Rpb24gZHJhd1RleHQoY3VycmVudFRleHQsIHgsIHksIGN0eCl7XG4gICAgaWYgKGN1cnJlbnRUZXh0ICE9PSBudWxsICYmIFV0aWwudHJpbVRleHQoY3VycmVudFRleHQpLmxlbmd0aCA+IDApIHtcbiAgICAgIGN0eC5maWxsVGV4dChjdXJyZW50VGV4dCwgeCwgeSk7XG4gICAgICBudW1EcmF3cys9MTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBzZXRUZXh0VmFyaWFibGVzKGN0eCwgZWwsIHRleHRfZGVjb3JhdGlvbiwgY29sb3IpIHtcbiAgICB2YXIgYWxpZ24gPSBmYWxzZSxcbiAgICBib2xkID0gZ2V0Q1NTKGVsLCBcImZvbnRXZWlnaHRcIiksXG4gICAgZmFtaWx5ID0gZ2V0Q1NTKGVsLCBcImZvbnRGYW1pbHlcIiksXG4gICAgc2l6ZSA9IGdldENTUyhlbCwgXCJmb250U2l6ZVwiKSxcbiAgICBzaGFkb3dzID0gVXRpbC5wYXJzZVRleHRTaGFkb3dzKGdldENTUyhlbCwgXCJ0ZXh0U2hhZG93XCIpKTtcblxuICAgIHN3aXRjaChwYXJzZUludChib2xkLCAxMCkpe1xuICAgICAgY2FzZSA0MDE6XG4gICAgICAgIGJvbGQgPSBcImJvbGRcIjtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDQwMDpcbiAgICAgICAgYm9sZCA9IFwibm9ybWFsXCI7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIGN0eC5zZXRWYXJpYWJsZShcImZpbGxTdHlsZVwiLCBjb2xvcik7XG4gICAgY3R4LnNldFZhcmlhYmxlKFwiZm9udFwiLCBbZ2V0Q1NTKGVsLCBcImZvbnRTdHlsZVwiKSwgZ2V0Q1NTKGVsLCBcImZvbnRWYXJpYW50XCIpLCBib2xkLCBzaXplLCBmYW1pbHldLmpvaW4oXCIgXCIpKTtcbiAgICBjdHguc2V0VmFyaWFibGUoXCJ0ZXh0QWxpZ25cIiwgKGFsaWduKSA/IFwicmlnaHRcIiA6IFwibGVmdFwiKTtcblxuICAgIGlmIChzaGFkb3dzLmxlbmd0aCkge1xuICAgICAgLy8gVE9ETzogc3VwcG9ydCBtdWx0aXBsZSB0ZXh0IHNoYWRvd3NcbiAgICAgIC8vIGFwcGx5IHRoZSBmaXJzdCB0ZXh0IHNoYWRvd1xuICAgICAgY3R4LnNldFZhcmlhYmxlKFwic2hhZG93Q29sb3JcIiwgc2hhZG93c1swXS5jb2xvcik7XG4gICAgICBjdHguc2V0VmFyaWFibGUoXCJzaGFkb3dPZmZzZXRYXCIsIHNoYWRvd3NbMF0ub2Zmc2V0WCk7XG4gICAgICBjdHguc2V0VmFyaWFibGUoXCJzaGFkb3dPZmZzZXRZXCIsIHNoYWRvd3NbMF0ub2Zmc2V0WSk7XG4gICAgICBjdHguc2V0VmFyaWFibGUoXCJzaGFkb3dCbHVyXCIsIHNoYWRvd3NbMF0uYmx1cik7XG4gICAgfVxuXG4gICAgaWYgKHRleHRfZGVjb3JhdGlvbiAhPT0gXCJub25lXCIpe1xuICAgICAgcmV0dXJuIFV0aWwuRm9udChmYW1pbHksIHNpemUsIGRvYyk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gcmVuZGVyVGV4dERlY29yYXRpb24oY3R4LCB0ZXh0X2RlY29yYXRpb24sIGJvdW5kcywgbWV0cmljcywgY29sb3IpIHtcbiAgICBzd2l0Y2godGV4dF9kZWNvcmF0aW9uKSB7XG4gICAgICBjYXNlIFwidW5kZXJsaW5lXCI6XG4gICAgICAgIC8vIERyYXdzIGEgbGluZSBhdCB0aGUgYmFzZWxpbmUgb2YgdGhlIGZvbnRcbiAgICAgICAgLy8gVE9ETyBBcyBzb21lIGJyb3dzZXJzIGRpc3BsYXkgdGhlIGxpbmUgYXMgbW9yZSB0aGFuIDFweCBpZiB0aGUgZm9udC1zaXplIGlzIGJpZywgbmVlZCB0byB0YWtlIHRoYXQgaW50byBhY2NvdW50IGJvdGggaW4gcG9zaXRpb24gYW5kIHNpemVcbiAgICAgICAgcmVuZGVyUmVjdChjdHgsIGJvdW5kcy5sZWZ0LCBNYXRoLnJvdW5kKGJvdW5kcy50b3AgKyBtZXRyaWNzLmJhc2VsaW5lICsgbWV0cmljcy5saW5lV2lkdGgpLCBib3VuZHMud2lkdGgsIDEsIGNvbG9yKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwib3ZlcmxpbmVcIjpcbiAgICAgICAgcmVuZGVyUmVjdChjdHgsIGJvdW5kcy5sZWZ0LCBNYXRoLnJvdW5kKGJvdW5kcy50b3ApLCBib3VuZHMud2lkdGgsIDEsIGNvbG9yKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwibGluZS10aHJvdWdoXCI6XG4gICAgICAgIC8vIFRPRE8gdHJ5IGFuZCBmaW5kIGV4YWN0IHBvc2l0aW9uIGZvciBsaW5lLXRocm91Z2hcbiAgICAgICAgcmVuZGVyUmVjdChjdHgsIGJvdW5kcy5sZWZ0LCBNYXRoLmNlaWwoYm91bmRzLnRvcCArIG1ldHJpY3MubWlkZGxlICsgbWV0cmljcy5saW5lV2lkdGgpLCBib3VuZHMud2lkdGgsIDEsIGNvbG9yKTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gZ2V0VGV4dEJvdW5kcyhzdGF0ZSwgdGV4dCwgdGV4dERlY29yYXRpb24sIGlzTGFzdCwgdHJhbnNmb3JtKSB7XG4gICAgdmFyIGJvdW5kcztcbiAgICBpZiAoc3VwcG9ydC5yYW5nZUJvdW5kcyAmJiAhdHJhbnNmb3JtKSB7XG4gICAgICBpZiAodGV4dERlY29yYXRpb24gIT09IFwibm9uZVwiIHx8IFV0aWwudHJpbVRleHQodGV4dCkubGVuZ3RoICE9PSAwKSB7XG4gICAgICAgIGJvdW5kcyA9IHRleHRSYW5nZUJvdW5kcyh0ZXh0LCBzdGF0ZS5ub2RlLCBzdGF0ZS50ZXh0T2Zmc2V0KTtcbiAgICAgIH1cbiAgICAgIHN0YXRlLnRleHRPZmZzZXQgKz0gdGV4dC5sZW5ndGg7XG4gICAgfSBlbHNlIGlmIChzdGF0ZS5ub2RlICYmIHR5cGVvZiBzdGF0ZS5ub2RlLm5vZGVWYWx1ZSA9PT0gXCJzdHJpbmdcIiApe1xuICAgICAgdmFyIG5ld1RleHROb2RlID0gKGlzTGFzdCkgPyBzdGF0ZS5ub2RlLnNwbGl0VGV4dCh0ZXh0Lmxlbmd0aCkgOiBudWxsO1xuICAgICAgYm91bmRzID0gdGV4dFdyYXBwZXJCb3VuZHMoc3RhdGUubm9kZSwgdHJhbnNmb3JtKTtcbiAgICAgIHN0YXRlLm5vZGUgPSBuZXdUZXh0Tm9kZTtcbiAgICB9XG4gICAgcmV0dXJuIGJvdW5kcztcbiAgfVxuXG4gIGZ1bmN0aW9uIHRleHRSYW5nZUJvdW5kcyh0ZXh0LCB0ZXh0Tm9kZSwgdGV4dE9mZnNldCkge1xuICAgIHZhciByYW5nZSA9IGRvYy5jcmVhdGVSYW5nZSgpO1xuICAgIHJhbmdlLnNldFN0YXJ0KHRleHROb2RlLCB0ZXh0T2Zmc2V0KTtcbiAgICByYW5nZS5zZXRFbmQodGV4dE5vZGUsIHRleHRPZmZzZXQgKyB0ZXh0Lmxlbmd0aCk7XG4gICAgcmV0dXJuIHJhbmdlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICB9XG5cbiAgZnVuY3Rpb24gdGV4dFdyYXBwZXJCb3VuZHMob2xkVGV4dE5vZGUsIHRyYW5zZm9ybSkge1xuICAgIHZhciBwYXJlbnQgPSBvbGRUZXh0Tm9kZS5wYXJlbnROb2RlLFxuICAgIHdyYXBFbGVtZW50ID0gZG9jLmNyZWF0ZUVsZW1lbnQoJ3dyYXBwZXInKSxcbiAgICBiYWNrdXBUZXh0ID0gb2xkVGV4dE5vZGUuY2xvbmVOb2RlKHRydWUpO1xuXG4gICAgd3JhcEVsZW1lbnQuYXBwZW5kQ2hpbGQob2xkVGV4dE5vZGUuY2xvbmVOb2RlKHRydWUpKTtcbiAgICBwYXJlbnQucmVwbGFjZUNoaWxkKHdyYXBFbGVtZW50LCBvbGRUZXh0Tm9kZSk7XG5cbiAgICB2YXIgYm91bmRzID0gdHJhbnNmb3JtID8gVXRpbC5PZmZzZXRCb3VuZHMod3JhcEVsZW1lbnQpIDogVXRpbC5Cb3VuZHMod3JhcEVsZW1lbnQpO1xuICAgIHBhcmVudC5yZXBsYWNlQ2hpbGQoYmFja3VwVGV4dCwgd3JhcEVsZW1lbnQpO1xuICAgIHJldHVybiBib3VuZHM7XG4gIH1cblxuICBmdW5jdGlvbiByZW5kZXJUZXh0KGVsLCB0ZXh0Tm9kZSwgc3RhY2spIHtcbiAgICB2YXIgY3R4ID0gc3RhY2suY3R4LFxuICAgIGNvbG9yID0gZ2V0Q1NTKGVsLCBcImNvbG9yXCIpLFxuICAgIHRleHREZWNvcmF0aW9uID0gZ2V0Q1NTKGVsLCBcInRleHREZWNvcmF0aW9uXCIpLFxuICAgIHRleHRBbGlnbiA9IGdldENTUyhlbCwgXCJ0ZXh0QWxpZ25cIiksXG4gICAgbWV0cmljcyxcbiAgICB0ZXh0TGlzdCxcbiAgICBzdGF0ZSA9IHtcbiAgICAgIG5vZGU6IHRleHROb2RlLFxuICAgICAgdGV4dE9mZnNldDogMFxuICAgIH07XG5cbiAgICBpZiAoVXRpbC50cmltVGV4dCh0ZXh0Tm9kZS5ub2RlVmFsdWUpLmxlbmd0aCA+IDApIHtcbiAgICAgIHRleHROb2RlLm5vZGVWYWx1ZSA9IHRleHRUcmFuc2Zvcm0odGV4dE5vZGUubm9kZVZhbHVlLCBnZXRDU1MoZWwsIFwidGV4dFRyYW5zZm9ybVwiKSk7XG4gICAgICB0ZXh0QWxpZ24gPSB0ZXh0QWxpZ24ucmVwbGFjZShbXCItd2Via2l0LWF1dG9cIl0sW1wiYXV0b1wiXSk7XG5cbiAgICAgIHRleHRMaXN0ID0gKCFvcHRpb25zLmxldHRlclJlbmRlcmluZyAmJiAvXihsZWZ0fHJpZ2h0fGp1c3RpZnl8YXV0bykkLy50ZXN0KHRleHRBbGlnbikgJiYgbm9MZXR0ZXJTcGFjaW5nKGdldENTUyhlbCwgXCJsZXR0ZXJTcGFjaW5nXCIpKSkgP1xuICAgICAgdGV4dE5vZGUubm9kZVZhbHVlLnNwbGl0KC8oXFxifCApLylcbiAgICAgIDogdGV4dE5vZGUubm9kZVZhbHVlLnNwbGl0KFwiXCIpO1xuXG4gICAgICBtZXRyaWNzID0gc2V0VGV4dFZhcmlhYmxlcyhjdHgsIGVsLCB0ZXh0RGVjb3JhdGlvbiwgY29sb3IpO1xuXG4gICAgICBpZiAob3B0aW9ucy5jaGluZXNlKSB7XG4gICAgICAgIHRleHRMaXN0LmZvckVhY2goZnVuY3Rpb24od29yZCwgaW5kZXgpIHtcbiAgICAgICAgICBpZiAoLy4qW1xcdTRFMDAtXFx1OUZBNV0uKiQvLnRlc3Qod29yZCkpIHtcbiAgICAgICAgICAgIHdvcmQgPSB3b3JkLnNwbGl0KFwiXCIpO1xuICAgICAgICAgICAgd29yZC51bnNoaWZ0KGluZGV4LCAxKTtcbiAgICAgICAgICAgIHRleHRMaXN0LnNwbGljZS5hcHBseSh0ZXh0TGlzdCwgd29yZCk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgdGV4dExpc3QuZm9yRWFjaChmdW5jdGlvbih0ZXh0LCBpbmRleCkge1xuICAgICAgICB2YXIgYm91bmRzID0gZ2V0VGV4dEJvdW5kcyhzdGF0ZSwgdGV4dCwgdGV4dERlY29yYXRpb24sIChpbmRleCA8IHRleHRMaXN0Lmxlbmd0aCAtIDEpLCBzdGFjay50cmFuc2Zvcm0ubWF0cml4KTtcbiAgICAgICAgaWYgKGJvdW5kcykge1xuICAgICAgICAgIGRyYXdUZXh0KHRleHQsIGJvdW5kcy5sZWZ0LCBib3VuZHMuYm90dG9tLCBjdHgpO1xuICAgICAgICAgIHJlbmRlclRleHREZWNvcmF0aW9uKGN0eCwgdGV4dERlY29yYXRpb24sIGJvdW5kcywgbWV0cmljcywgY29sb3IpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBsaXN0UG9zaXRpb24gKGVsZW1lbnQsIHZhbCkge1xuICAgIHZhciBib3VuZEVsZW1lbnQgPSBkb2MuY3JlYXRlRWxlbWVudCggXCJib3VuZGVsZW1lbnRcIiApLFxuICAgIG9yaWdpbmFsVHlwZSxcbiAgICBib3VuZHM7XG5cbiAgICBib3VuZEVsZW1lbnQuc3R5bGUuZGlzcGxheSA9IFwiaW5saW5lXCI7XG5cbiAgICBvcmlnaW5hbFR5cGUgPSBlbGVtZW50LnN0eWxlLmxpc3RTdHlsZVR5cGU7XG4gICAgZWxlbWVudC5zdHlsZS5saXN0U3R5bGVUeXBlID0gXCJub25lXCI7XG5cbiAgICBib3VuZEVsZW1lbnQuYXBwZW5kQ2hpbGQoZG9jLmNyZWF0ZVRleHROb2RlKHZhbCkpO1xuXG4gICAgZWxlbWVudC5pbnNlcnRCZWZvcmUoYm91bmRFbGVtZW50LCBlbGVtZW50LmZpcnN0Q2hpbGQpO1xuXG4gICAgYm91bmRzID0gVXRpbC5Cb3VuZHMoYm91bmRFbGVtZW50KTtcbiAgICBlbGVtZW50LnJlbW92ZUNoaWxkKGJvdW5kRWxlbWVudCk7XG4gICAgZWxlbWVudC5zdHlsZS5saXN0U3R5bGVUeXBlID0gb3JpZ2luYWxUeXBlO1xuICAgIHJldHVybiBib3VuZHM7XG4gIH1cblxuICBmdW5jdGlvbiBlbGVtZW50SW5kZXgoZWwpIHtcbiAgICB2YXIgaSA9IC0xLFxuICAgIGNvdW50ID0gMSxcbiAgICBjaGlsZHMgPSBlbC5wYXJlbnROb2RlLmNoaWxkTm9kZXM7XG5cbiAgICBpZiAoZWwucGFyZW50Tm9kZSkge1xuICAgICAgd2hpbGUoY2hpbGRzWysraV0gIT09IGVsKSB7XG4gICAgICAgIGlmIChjaGlsZHNbaV0ubm9kZVR5cGUgPT09IDEpIHtcbiAgICAgICAgICBjb3VudCsrO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gY291bnQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiAtMTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBsaXN0SXRlbVRleHQoZWxlbWVudCwgdHlwZSkge1xuICAgIHZhciBjdXJyZW50SW5kZXggPSBlbGVtZW50SW5kZXgoZWxlbWVudCksIHRleHQ7XG4gICAgc3dpdGNoKHR5cGUpe1xuICAgICAgY2FzZSBcImRlY2ltYWxcIjpcbiAgICAgICAgdGV4dCA9IGN1cnJlbnRJbmRleDtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiZGVjaW1hbC1sZWFkaW5nLXplcm9cIjpcbiAgICAgICAgdGV4dCA9IChjdXJyZW50SW5kZXgudG9TdHJpbmcoKS5sZW5ndGggPT09IDEpID8gY3VycmVudEluZGV4ID0gXCIwXCIgKyBjdXJyZW50SW5kZXgudG9TdHJpbmcoKSA6IGN1cnJlbnRJbmRleC50b1N0cmluZygpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJ1cHBlci1yb21hblwiOlxuICAgICAgICB0ZXh0ID0gX2h0bWwyY2FudmFzLkdlbmVyYXRlLkxpc3RSb21hbiggY3VycmVudEluZGV4ICk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImxvd2VyLXJvbWFuXCI6XG4gICAgICAgIHRleHQgPSBfaHRtbDJjYW52YXMuR2VuZXJhdGUuTGlzdFJvbWFuKCBjdXJyZW50SW5kZXggKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJsb3dlci1hbHBoYVwiOlxuICAgICAgICB0ZXh0ID0gX2h0bWwyY2FudmFzLkdlbmVyYXRlLkxpc3RBbHBoYSggY3VycmVudEluZGV4ICkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwidXBwZXItYWxwaGFcIjpcbiAgICAgICAgdGV4dCA9IF9odG1sMmNhbnZhcy5HZW5lcmF0ZS5MaXN0QWxwaGEoIGN1cnJlbnRJbmRleCApO1xuICAgICAgICBicmVhaztcbiAgICB9XG5cbiAgICByZXR1cm4gdGV4dCArIFwiLiBcIjtcbiAgfVxuXG4gIGZ1bmN0aW9uIHJlbmRlckxpc3RJdGVtKGVsZW1lbnQsIHN0YWNrLCBlbEJvdW5kcykge1xuICAgIHZhciB4LFxuICAgIHRleHQsXG4gICAgY3R4ID0gc3RhY2suY3R4LFxuICAgIHR5cGUgPSBnZXRDU1MoZWxlbWVudCwgXCJsaXN0U3R5bGVUeXBlXCIpLFxuICAgIGxpc3RCb3VuZHM7XG5cbiAgICBpZiAoL14oZGVjaW1hbHxkZWNpbWFsLWxlYWRpbmctemVyb3x1cHBlci1hbHBoYXx1cHBlci1sYXRpbnx1cHBlci1yb21hbnxsb3dlci1hbHBoYXxsb3dlci1ncmVla3xsb3dlci1sYXRpbnxsb3dlci1yb21hbikkL2kudGVzdCh0eXBlKSkge1xuICAgICAgdGV4dCA9IGxpc3RJdGVtVGV4dChlbGVtZW50LCB0eXBlKTtcbiAgICAgIGxpc3RCb3VuZHMgPSBsaXN0UG9zaXRpb24oZWxlbWVudCwgdGV4dCk7XG4gICAgICBzZXRUZXh0VmFyaWFibGVzKGN0eCwgZWxlbWVudCwgXCJub25lXCIsIGdldENTUyhlbGVtZW50LCBcImNvbG9yXCIpKTtcblxuICAgICAgaWYgKGdldENTUyhlbGVtZW50LCBcImxpc3RTdHlsZVBvc2l0aW9uXCIpID09PSBcImluc2lkZVwiKSB7XG4gICAgICAgIGN0eC5zZXRWYXJpYWJsZShcInRleHRBbGlnblwiLCBcImxlZnRcIik7XG4gICAgICAgIHggPSBlbEJvdW5kcy5sZWZ0O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBkcmF3VGV4dCh0ZXh0LCB4LCBsaXN0Qm91bmRzLmJvdHRvbSwgY3R4KTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBsb2FkSW1hZ2UgKHNyYyl7XG4gICAgdmFyIGltZyA9IGltYWdlc1tzcmNdO1xuICAgIHJldHVybiAoaW1nICYmIGltZy5zdWNjZWVkZWQgPT09IHRydWUpID8gaW1nLmltZyA6IGZhbHNlO1xuICB9XG5cbiAgZnVuY3Rpb24gY2xpcEJvdW5kcyhzcmMsIGRzdCl7XG4gICAgdmFyIHggPSBNYXRoLm1heChzcmMubGVmdCwgZHN0LmxlZnQpLFxuICAgIHkgPSBNYXRoLm1heChzcmMudG9wLCBkc3QudG9wKSxcbiAgICB4MiA9IE1hdGgubWluKChzcmMubGVmdCArIHNyYy53aWR0aCksIChkc3QubGVmdCArIGRzdC53aWR0aCkpLFxuICAgIHkyID0gTWF0aC5taW4oKHNyYy50b3AgKyBzcmMuaGVpZ2h0KSwgKGRzdC50b3AgKyBkc3QuaGVpZ2h0KSk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgbGVmdDp4LFxuICAgICAgdG9wOnksXG4gICAgICB3aWR0aDp4Mi14LFxuICAgICAgaGVpZ2h0OnkyLXlcbiAgICB9O1xuICB9XG5cbiAgZnVuY3Rpb24gc2V0WihlbGVtZW50LCBzdGFjaywgcGFyZW50U3RhY2spe1xuICAgIHZhciBuZXdDb250ZXh0LFxuICAgIGlzUG9zaXRpb25lZCA9IHN0YWNrLmNzc1Bvc2l0aW9uICE9PSAnc3RhdGljJyxcbiAgICB6SW5kZXggPSBpc1Bvc2l0aW9uZWQgPyBnZXRDU1MoZWxlbWVudCwgJ3pJbmRleCcpIDogJ2F1dG8nLFxuICAgIG9wYWNpdHkgPSBnZXRDU1MoZWxlbWVudCwgJ29wYWNpdHknKSxcbiAgICBpc0Zsb2F0ZWQgPSBnZXRDU1MoZWxlbWVudCwgJ2Nzc0Zsb2F0JykgIT09ICdub25lJztcblxuICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0d1aWRlL0NTUy9VbmRlcnN0YW5kaW5nX3pfaW5kZXgvVGhlX3N0YWNraW5nX2NvbnRleHRcbiAgICAvLyBXaGVuIGEgbmV3IHN0YWNraW5nIGNvbnRleHQgc2hvdWxkIGJlIGNyZWF0ZWQ6XG4gICAgLy8gdGhlIHJvb3QgZWxlbWVudCAoSFRNTCksXG4gICAgLy8gcG9zaXRpb25lZCAoYWJzb2x1dGVseSBvciByZWxhdGl2ZWx5KSB3aXRoIGEgei1pbmRleCB2YWx1ZSBvdGhlciB0aGFuIFwiYXV0b1wiLFxuICAgIC8vIGVsZW1lbnRzIHdpdGggYW4gb3BhY2l0eSB2YWx1ZSBsZXNzIHRoYW4gMS4gKFNlZSB0aGUgc3BlY2lmaWNhdGlvbiBmb3Igb3BhY2l0eSksXG4gICAgLy8gb24gbW9iaWxlIFdlYktpdCBhbmQgQ2hyb21lIDIyKywgcG9zaXRpb246IGZpeGVkIGFsd2F5cyBjcmVhdGVzIGEgbmV3IHN0YWNraW5nIGNvbnRleHQsIGV2ZW4gd2hlbiB6LWluZGV4IGlzIFwiYXV0b1wiIChTZWUgdGhpcyBwb3N0KVxuXG4gICAgc3RhY2suekluZGV4ID0gbmV3Q29udGV4dCA9IGgyY3pDb250ZXh0KHpJbmRleCk7XG4gICAgbmV3Q29udGV4dC5pc1Bvc2l0aW9uZWQgPSBpc1Bvc2l0aW9uZWQ7XG4gICAgbmV3Q29udGV4dC5pc0Zsb2F0ZWQgPSBpc0Zsb2F0ZWQ7XG4gICAgbmV3Q29udGV4dC5vcGFjaXR5ID0gb3BhY2l0eTtcbiAgICBuZXdDb250ZXh0Lm93blN0YWNraW5nID0gKHpJbmRleCAhPT0gJ2F1dG8nIHx8IG9wYWNpdHkgPCAxKTtcbiAgICBuZXdDb250ZXh0LmRlcHRoID0gcGFyZW50U3RhY2sgPyAocGFyZW50U3RhY2suekluZGV4LmRlcHRoICsgMSkgOiAwO1xuXG4gICAgaWYgKHBhcmVudFN0YWNrKSB7XG4gICAgICBwYXJlbnRTdGFjay56SW5kZXguY2hpbGRyZW4ucHVzaChzdGFjayk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gaDJjekNvbnRleHQoemluZGV4KSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGRlcHRoOiAwLFxuICAgICAgemluZGV4OiB6aW5kZXgsXG4gICAgICBjaGlsZHJlbjogW11cbiAgICB9O1xuICB9XG5cbiAgZnVuY3Rpb24gcmVuZGVySW1hZ2UoY3R4LCBlbGVtZW50LCBpbWFnZSwgYm91bmRzLCBib3JkZXJzKSB7XG5cbiAgICB2YXIgcGFkZGluZ0xlZnQgPSBnZXRDU1NJbnQoZWxlbWVudCwgJ3BhZGRpbmdMZWZ0JyksXG4gICAgcGFkZGluZ1RvcCA9IGdldENTU0ludChlbGVtZW50LCAncGFkZGluZ1RvcCcpLFxuICAgIHBhZGRpbmdSaWdodCA9IGdldENTU0ludChlbGVtZW50LCAncGFkZGluZ1JpZ2h0JyksXG4gICAgcGFkZGluZ0JvdHRvbSA9IGdldENTU0ludChlbGVtZW50LCAncGFkZGluZ0JvdHRvbScpO1xuXG4gICAgZHJhd0ltYWdlKFxuICAgICAgY3R4LFxuICAgICAgaW1hZ2UsXG4gICAgICAwLCAvL3N4XG4gICAgICAwLCAvL3N5XG4gICAgICBpbWFnZS53aWR0aCwgLy9zd1xuICAgICAgaW1hZ2UuaGVpZ2h0LCAvL3NoXG4gICAgICBib3VuZHMubGVmdCArIHBhZGRpbmdMZWZ0ICsgYm9yZGVyc1szXS53aWR0aCwgLy9keFxuICAgICAgYm91bmRzLnRvcCArIHBhZGRpbmdUb3AgKyBib3JkZXJzWzBdLndpZHRoLCAvLyBkeVxuICAgICAgYm91bmRzLndpZHRoIC0gKGJvcmRlcnNbMV0ud2lkdGggKyBib3JkZXJzWzNdLndpZHRoICsgcGFkZGluZ0xlZnQgKyBwYWRkaW5nUmlnaHQpLCAvL2R3XG4gICAgICBib3VuZHMuaGVpZ2h0IC0gKGJvcmRlcnNbMF0ud2lkdGggKyBib3JkZXJzWzJdLndpZHRoICsgcGFkZGluZ1RvcCArIHBhZGRpbmdCb3R0b20pIC8vZGhcbiAgICAgICk7XG4gIH1cblxuICBmdW5jdGlvbiBnZXRCb3JkZXJEYXRhKGVsZW1lbnQpIHtcbiAgICByZXR1cm4gW1wiVG9wXCIsIFwiUmlnaHRcIiwgXCJCb3R0b21cIiwgXCJMZWZ0XCJdLm1hcChmdW5jdGlvbihzaWRlKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB3aWR0aDogZ2V0Q1NTSW50KGVsZW1lbnQsICdib3JkZXInICsgc2lkZSArICdXaWR0aCcpLFxuICAgICAgICBjb2xvcjogZ2V0Q1NTKGVsZW1lbnQsICdib3JkZXInICsgc2lkZSArICdDb2xvcicpXG4gICAgICB9O1xuICAgIH0pO1xuICB9XG5cbiAgZnVuY3Rpb24gZ2V0Qm9yZGVyUmFkaXVzRGF0YShlbGVtZW50KSB7XG4gICAgcmV0dXJuIFtcIlRvcExlZnRcIiwgXCJUb3BSaWdodFwiLCBcIkJvdHRvbVJpZ2h0XCIsIFwiQm90dG9tTGVmdFwiXS5tYXAoZnVuY3Rpb24oc2lkZSkge1xuICAgICAgcmV0dXJuIGdldENTUyhlbGVtZW50LCAnYm9yZGVyJyArIHNpZGUgKyAnUmFkaXVzJyk7XG4gICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBnZXRDdXJ2ZVBvaW50cyh4LCB5LCByMSwgcjIpIHtcbiAgICB2YXIga2FwcGEgPSA0ICogKChNYXRoLnNxcnQoMikgLSAxKSAvIDMpO1xuICAgIHZhciBveCA9IChyMSkgKiBrYXBwYSwgLy8gY29udHJvbCBwb2ludCBvZmZzZXQgaG9yaXpvbnRhbFxuICAgIG95ID0gKHIyKSAqIGthcHBhLCAvLyBjb250cm9sIHBvaW50IG9mZnNldCB2ZXJ0aWNhbFxuICAgIHhtID0geCArIHIxLCAvLyB4LW1pZGRsZVxuICAgIHltID0geSArIHIyOyAvLyB5LW1pZGRsZVxuICAgIHJldHVybiB7XG4gICAgICB0b3BMZWZ0OiBiZXppZXJDdXJ2ZSh7XG4gICAgICAgIHg6eCxcbiAgICAgICAgeTp5bVxuICAgICAgfSwge1xuICAgICAgICB4OngsXG4gICAgICAgIHk6eW0gLSBveVxuICAgICAgfSwge1xuICAgICAgICB4OnhtIC0gb3gsXG4gICAgICAgIHk6eVxuICAgICAgfSwge1xuICAgICAgICB4OnhtLFxuICAgICAgICB5OnlcbiAgICAgIH0pLFxuICAgICAgdG9wUmlnaHQ6IGJlemllckN1cnZlKHtcbiAgICAgICAgeDp4LFxuICAgICAgICB5OnlcbiAgICAgIH0sIHtcbiAgICAgICAgeDp4ICsgb3gsXG4gICAgICAgIHk6eVxuICAgICAgfSwge1xuICAgICAgICB4OnhtLFxuICAgICAgICB5OnltIC0gb3lcbiAgICAgIH0sIHtcbiAgICAgICAgeDp4bSxcbiAgICAgICAgeTp5bVxuICAgICAgfSksXG4gICAgICBib3R0b21SaWdodDogYmV6aWVyQ3VydmUoe1xuICAgICAgICB4OnhtLFxuICAgICAgICB5OnlcbiAgICAgIH0sIHtcbiAgICAgICAgeDp4bSxcbiAgICAgICAgeTp5ICsgb3lcbiAgICAgIH0sIHtcbiAgICAgICAgeDp4ICsgb3gsXG4gICAgICAgIHk6eW1cbiAgICAgIH0sIHtcbiAgICAgICAgeDp4LFxuICAgICAgICB5OnltXG4gICAgICB9KSxcbiAgICAgIGJvdHRvbUxlZnQ6IGJlemllckN1cnZlKHtcbiAgICAgICAgeDp4bSxcbiAgICAgICAgeTp5bVxuICAgICAgfSwge1xuICAgICAgICB4OnhtIC0gb3gsXG4gICAgICAgIHk6eW1cbiAgICAgIH0sIHtcbiAgICAgICAgeDp4LFxuICAgICAgICB5OnkgKyBveVxuICAgICAgfSwge1xuICAgICAgICB4OngsXG4gICAgICAgIHk6eVxuICAgICAgfSlcbiAgICB9O1xuICB9XG5cbiAgZnVuY3Rpb24gYmV6aWVyQ3VydmUoc3RhcnQsIHN0YXJ0Q29udHJvbCwgZW5kQ29udHJvbCwgZW5kKSB7XG5cbiAgICB2YXIgbGVycCA9IGZ1bmN0aW9uIChhLCBiLCB0KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB4OmEueCArIChiLnggLSBhLngpICogdCxcbiAgICAgICAgeTphLnkgKyAoYi55IC0gYS55KSAqIHRcbiAgICAgIH07XG4gICAgfTtcblxuICAgIHJldHVybiB7XG4gICAgICBzdGFydDogc3RhcnQsXG4gICAgICBzdGFydENvbnRyb2w6IHN0YXJ0Q29udHJvbCxcbiAgICAgIGVuZENvbnRyb2w6IGVuZENvbnRyb2wsXG4gICAgICBlbmQ6IGVuZCxcbiAgICAgIHN1YmRpdmlkZTogZnVuY3Rpb24odCkge1xuICAgICAgICB2YXIgYWIgPSBsZXJwKHN0YXJ0LCBzdGFydENvbnRyb2wsIHQpLFxuICAgICAgICBiYyA9IGxlcnAoc3RhcnRDb250cm9sLCBlbmRDb250cm9sLCB0KSxcbiAgICAgICAgY2QgPSBsZXJwKGVuZENvbnRyb2wsIGVuZCwgdCksXG4gICAgICAgIGFiYmMgPSBsZXJwKGFiLCBiYywgdCksXG4gICAgICAgIGJjY2QgPSBsZXJwKGJjLCBjZCwgdCksXG4gICAgICAgIGRlc3QgPSBsZXJwKGFiYmMsIGJjY2QsIHQpO1xuICAgICAgICByZXR1cm4gW2JlemllckN1cnZlKHN0YXJ0LCBhYiwgYWJiYywgZGVzdCksIGJlemllckN1cnZlKGRlc3QsIGJjY2QsIGNkLCBlbmQpXTtcbiAgICAgIH0sXG4gICAgICBjdXJ2ZVRvOiBmdW5jdGlvbihib3JkZXJBcmdzKSB7XG4gICAgICAgIGJvcmRlckFyZ3MucHVzaChbXCJiZXppZXJDdXJ2ZVwiLCBzdGFydENvbnRyb2wueCwgc3RhcnRDb250cm9sLnksIGVuZENvbnRyb2wueCwgZW5kQ29udHJvbC55LCBlbmQueCwgZW5kLnldKTtcbiAgICAgIH0sXG4gICAgICBjdXJ2ZVRvUmV2ZXJzZWQ6IGZ1bmN0aW9uKGJvcmRlckFyZ3MpIHtcbiAgICAgICAgYm9yZGVyQXJncy5wdXNoKFtcImJlemllckN1cnZlXCIsIGVuZENvbnRyb2wueCwgZW5kQ29udHJvbC55LCBzdGFydENvbnRyb2wueCwgc3RhcnRDb250cm9sLnksIHN0YXJ0LngsIHN0YXJ0LnldKTtcbiAgICAgIH1cbiAgICB9O1xuICB9XG5cbiAgZnVuY3Rpb24gcGFyc2VDb3JuZXIoYm9yZGVyQXJncywgcmFkaXVzMSwgcmFkaXVzMiwgY29ybmVyMSwgY29ybmVyMiwgeCwgeSkge1xuICAgIGlmIChyYWRpdXMxWzBdID4gMCB8fCByYWRpdXMxWzFdID4gMCkge1xuICAgICAgYm9yZGVyQXJncy5wdXNoKFtcImxpbmVcIiwgY29ybmVyMVswXS5zdGFydC54LCBjb3JuZXIxWzBdLnN0YXJ0LnldKTtcbiAgICAgIGNvcm5lcjFbMF0uY3VydmVUbyhib3JkZXJBcmdzKTtcbiAgICAgIGNvcm5lcjFbMV0uY3VydmVUbyhib3JkZXJBcmdzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYm9yZGVyQXJncy5wdXNoKFtcImxpbmVcIiwgeCwgeV0pO1xuICAgIH1cblxuICAgIGlmIChyYWRpdXMyWzBdID4gMCB8fCByYWRpdXMyWzFdID4gMCkge1xuICAgICAgYm9yZGVyQXJncy5wdXNoKFtcImxpbmVcIiwgY29ybmVyMlswXS5zdGFydC54LCBjb3JuZXIyWzBdLnN0YXJ0LnldKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBkcmF3U2lkZShib3JkZXJEYXRhLCByYWRpdXMxLCByYWRpdXMyLCBvdXRlcjEsIGlubmVyMSwgb3V0ZXIyLCBpbm5lcjIpIHtcbiAgICB2YXIgYm9yZGVyQXJncyA9IFtdO1xuXG4gICAgaWYgKHJhZGl1czFbMF0gPiAwIHx8IHJhZGl1czFbMV0gPiAwKSB7XG4gICAgICBib3JkZXJBcmdzLnB1c2goW1wibGluZVwiLCBvdXRlcjFbMV0uc3RhcnQueCwgb3V0ZXIxWzFdLnN0YXJ0LnldKTtcbiAgICAgIG91dGVyMVsxXS5jdXJ2ZVRvKGJvcmRlckFyZ3MpO1xuICAgIH0gZWxzZSB7XG4gICAgICBib3JkZXJBcmdzLnB1c2goWyBcImxpbmVcIiwgYm9yZGVyRGF0YS5jMVswXSwgYm9yZGVyRGF0YS5jMVsxXV0pO1xuICAgIH1cblxuICAgIGlmIChyYWRpdXMyWzBdID4gMCB8fCByYWRpdXMyWzFdID4gMCkge1xuICAgICAgYm9yZGVyQXJncy5wdXNoKFtcImxpbmVcIiwgb3V0ZXIyWzBdLnN0YXJ0LngsIG91dGVyMlswXS5zdGFydC55XSk7XG4gICAgICBvdXRlcjJbMF0uY3VydmVUbyhib3JkZXJBcmdzKTtcbiAgICAgIGJvcmRlckFyZ3MucHVzaChbXCJsaW5lXCIsIGlubmVyMlswXS5lbmQueCwgaW5uZXIyWzBdLmVuZC55XSk7XG4gICAgICBpbm5lcjJbMF0uY3VydmVUb1JldmVyc2VkKGJvcmRlckFyZ3MpO1xuICAgIH0gZWxzZSB7XG4gICAgICBib3JkZXJBcmdzLnB1c2goWyBcImxpbmVcIiwgYm9yZGVyRGF0YS5jMlswXSwgYm9yZGVyRGF0YS5jMlsxXV0pO1xuICAgICAgYm9yZGVyQXJncy5wdXNoKFsgXCJsaW5lXCIsIGJvcmRlckRhdGEuYzNbMF0sIGJvcmRlckRhdGEuYzNbMV1dKTtcbiAgICB9XG5cbiAgICBpZiAocmFkaXVzMVswXSA+IDAgfHwgcmFkaXVzMVsxXSA+IDApIHtcbiAgICAgIGJvcmRlckFyZ3MucHVzaChbXCJsaW5lXCIsIGlubmVyMVsxXS5lbmQueCwgaW5uZXIxWzFdLmVuZC55XSk7XG4gICAgICBpbm5lcjFbMV0uY3VydmVUb1JldmVyc2VkKGJvcmRlckFyZ3MpO1xuICAgIH0gZWxzZSB7XG4gICAgICBib3JkZXJBcmdzLnB1c2goWyBcImxpbmVcIiwgYm9yZGVyRGF0YS5jNFswXSwgYm9yZGVyRGF0YS5jNFsxXV0pO1xuICAgIH1cblxuICAgIHJldHVybiBib3JkZXJBcmdzO1xuICB9XG5cbiAgZnVuY3Rpb24gY2FsY3VsYXRlQ3VydmVQb2ludHMoYm91bmRzLCBib3JkZXJSYWRpdXMsIGJvcmRlcnMpIHtcblxuICAgIHZhciB4ID0gYm91bmRzLmxlZnQsXG4gICAgeSA9IGJvdW5kcy50b3AsXG4gICAgd2lkdGggPSBib3VuZHMud2lkdGgsXG4gICAgaGVpZ2h0ID0gYm91bmRzLmhlaWdodCxcblxuICAgIHRsaCA9IGJvcmRlclJhZGl1c1swXVswXSxcbiAgICB0bHYgPSBib3JkZXJSYWRpdXNbMF1bMV0sXG4gICAgdHJoID0gYm9yZGVyUmFkaXVzWzFdWzBdLFxuICAgIHRydiA9IGJvcmRlclJhZGl1c1sxXVsxXSxcbiAgICBicmggPSBib3JkZXJSYWRpdXNbMl1bMF0sXG4gICAgYnJ2ID0gYm9yZGVyUmFkaXVzWzJdWzFdLFxuICAgIGJsaCA9IGJvcmRlclJhZGl1c1szXVswXSxcbiAgICBibHYgPSBib3JkZXJSYWRpdXNbM11bMV0sXG5cbiAgICB0b3BXaWR0aCA9IHdpZHRoIC0gdHJoLFxuICAgIHJpZ2h0SGVpZ2h0ID0gaGVpZ2h0IC0gYnJ2LFxuICAgIGJvdHRvbVdpZHRoID0gd2lkdGggLSBicmgsXG4gICAgbGVmdEhlaWdodCA9IGhlaWdodCAtIGJsdjtcblxuICAgIHJldHVybiB7XG4gICAgICB0b3BMZWZ0T3V0ZXI6IGdldEN1cnZlUG9pbnRzKFxuICAgICAgICB4LFxuICAgICAgICB5LFxuICAgICAgICB0bGgsXG4gICAgICAgIHRsdlxuICAgICAgICApLnRvcExlZnQuc3ViZGl2aWRlKDAuNSksXG5cbiAgICAgIHRvcExlZnRJbm5lcjogZ2V0Q3VydmVQb2ludHMoXG4gICAgICAgIHggKyBib3JkZXJzWzNdLndpZHRoLFxuICAgICAgICB5ICsgYm9yZGVyc1swXS53aWR0aCxcbiAgICAgICAgTWF0aC5tYXgoMCwgdGxoIC0gYm9yZGVyc1szXS53aWR0aCksXG4gICAgICAgIE1hdGgubWF4KDAsIHRsdiAtIGJvcmRlcnNbMF0ud2lkdGgpXG4gICAgICAgICkudG9wTGVmdC5zdWJkaXZpZGUoMC41KSxcblxuICAgICAgdG9wUmlnaHRPdXRlcjogZ2V0Q3VydmVQb2ludHMoXG4gICAgICAgIHggKyB0b3BXaWR0aCxcbiAgICAgICAgeSxcbiAgICAgICAgdHJoLFxuICAgICAgICB0cnZcbiAgICAgICAgKS50b3BSaWdodC5zdWJkaXZpZGUoMC41KSxcblxuICAgICAgdG9wUmlnaHRJbm5lcjogZ2V0Q3VydmVQb2ludHMoXG4gICAgICAgIHggKyBNYXRoLm1pbih0b3BXaWR0aCwgd2lkdGggKyBib3JkZXJzWzNdLndpZHRoKSxcbiAgICAgICAgeSArIGJvcmRlcnNbMF0ud2lkdGgsXG4gICAgICAgICh0b3BXaWR0aCA+IHdpZHRoICsgYm9yZGVyc1szXS53aWR0aCkgPyAwIDp0cmggLSBib3JkZXJzWzNdLndpZHRoLFxuICAgICAgICB0cnYgLSBib3JkZXJzWzBdLndpZHRoXG4gICAgICAgICkudG9wUmlnaHQuc3ViZGl2aWRlKDAuNSksXG5cbiAgICAgIGJvdHRvbVJpZ2h0T3V0ZXI6IGdldEN1cnZlUG9pbnRzKFxuICAgICAgICB4ICsgYm90dG9tV2lkdGgsXG4gICAgICAgIHkgKyByaWdodEhlaWdodCxcbiAgICAgICAgYnJoLFxuICAgICAgICBicnZcbiAgICAgICAgKS5ib3R0b21SaWdodC5zdWJkaXZpZGUoMC41KSxcblxuICAgICAgYm90dG9tUmlnaHRJbm5lcjogZ2V0Q3VydmVQb2ludHMoXG4gICAgICAgIHggKyBNYXRoLm1pbihib3R0b21XaWR0aCwgd2lkdGggKyBib3JkZXJzWzNdLndpZHRoKSxcbiAgICAgICAgeSArIE1hdGgubWluKHJpZ2h0SGVpZ2h0LCBoZWlnaHQgKyBib3JkZXJzWzBdLndpZHRoKSxcbiAgICAgICAgTWF0aC5tYXgoMCwgYnJoIC0gYm9yZGVyc1sxXS53aWR0aCksXG4gICAgICAgIE1hdGgubWF4KDAsIGJydiAtIGJvcmRlcnNbMl0ud2lkdGgpXG4gICAgICAgICkuYm90dG9tUmlnaHQuc3ViZGl2aWRlKDAuNSksXG5cbiAgICAgIGJvdHRvbUxlZnRPdXRlcjogZ2V0Q3VydmVQb2ludHMoXG4gICAgICAgIHgsXG4gICAgICAgIHkgKyBsZWZ0SGVpZ2h0LFxuICAgICAgICBibGgsXG4gICAgICAgIGJsdlxuICAgICAgICApLmJvdHRvbUxlZnQuc3ViZGl2aWRlKDAuNSksXG5cbiAgICAgIGJvdHRvbUxlZnRJbm5lcjogZ2V0Q3VydmVQb2ludHMoXG4gICAgICAgIHggKyBib3JkZXJzWzNdLndpZHRoLFxuICAgICAgICB5ICsgbGVmdEhlaWdodCxcbiAgICAgICAgTWF0aC5tYXgoMCwgYmxoIC0gYm9yZGVyc1szXS53aWR0aCksXG4gICAgICAgIE1hdGgubWF4KDAsIGJsdiAtIGJvcmRlcnNbMl0ud2lkdGgpXG4gICAgICAgICkuYm90dG9tTGVmdC5zdWJkaXZpZGUoMC41KVxuICAgIH07XG4gIH1cblxuICBmdW5jdGlvbiBnZXRCb3JkZXJDbGlwKGVsZW1lbnQsIGJvcmRlclBvaW50cywgYm9yZGVycywgcmFkaXVzLCBib3VuZHMpIHtcbiAgICB2YXIgYmFja2dyb3VuZENsaXAgPSBnZXRDU1MoZWxlbWVudCwgJ2JhY2tncm91bmRDbGlwJyksXG4gICAgYm9yZGVyQXJncyA9IFtdO1xuXG4gICAgc3dpdGNoKGJhY2tncm91bmRDbGlwKSB7XG4gICAgICBjYXNlIFwiY29udGVudC1ib3hcIjpcbiAgICAgIGNhc2UgXCJwYWRkaW5nLWJveFwiOlxuICAgICAgICBwYXJzZUNvcm5lcihib3JkZXJBcmdzLCByYWRpdXNbMF0sIHJhZGl1c1sxXSwgYm9yZGVyUG9pbnRzLnRvcExlZnRJbm5lciwgYm9yZGVyUG9pbnRzLnRvcFJpZ2h0SW5uZXIsIGJvdW5kcy5sZWZ0ICsgYm9yZGVyc1szXS53aWR0aCwgYm91bmRzLnRvcCArIGJvcmRlcnNbMF0ud2lkdGgpO1xuICAgICAgICBwYXJzZUNvcm5lcihib3JkZXJBcmdzLCByYWRpdXNbMV0sIHJhZGl1c1syXSwgYm9yZGVyUG9pbnRzLnRvcFJpZ2h0SW5uZXIsIGJvcmRlclBvaW50cy5ib3R0b21SaWdodElubmVyLCBib3VuZHMubGVmdCArIGJvdW5kcy53aWR0aCAtIGJvcmRlcnNbMV0ud2lkdGgsIGJvdW5kcy50b3AgKyBib3JkZXJzWzBdLndpZHRoKTtcbiAgICAgICAgcGFyc2VDb3JuZXIoYm9yZGVyQXJncywgcmFkaXVzWzJdLCByYWRpdXNbM10sIGJvcmRlclBvaW50cy5ib3R0b21SaWdodElubmVyLCBib3JkZXJQb2ludHMuYm90dG9tTGVmdElubmVyLCBib3VuZHMubGVmdCArIGJvdW5kcy53aWR0aCAtIGJvcmRlcnNbMV0ud2lkdGgsIGJvdW5kcy50b3AgKyBib3VuZHMuaGVpZ2h0IC0gYm9yZGVyc1syXS53aWR0aCk7XG4gICAgICAgIHBhcnNlQ29ybmVyKGJvcmRlckFyZ3MsIHJhZGl1c1szXSwgcmFkaXVzWzBdLCBib3JkZXJQb2ludHMuYm90dG9tTGVmdElubmVyLCBib3JkZXJQb2ludHMudG9wTGVmdElubmVyLCBib3VuZHMubGVmdCArIGJvcmRlcnNbM10ud2lkdGgsIGJvdW5kcy50b3AgKyBib3VuZHMuaGVpZ2h0IC0gYm9yZGVyc1syXS53aWR0aCk7XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICBwYXJzZUNvcm5lcihib3JkZXJBcmdzLCByYWRpdXNbMF0sIHJhZGl1c1sxXSwgYm9yZGVyUG9pbnRzLnRvcExlZnRPdXRlciwgYm9yZGVyUG9pbnRzLnRvcFJpZ2h0T3V0ZXIsIGJvdW5kcy5sZWZ0LCBib3VuZHMudG9wKTtcbiAgICAgICAgcGFyc2VDb3JuZXIoYm9yZGVyQXJncywgcmFkaXVzWzFdLCByYWRpdXNbMl0sIGJvcmRlclBvaW50cy50b3BSaWdodE91dGVyLCBib3JkZXJQb2ludHMuYm90dG9tUmlnaHRPdXRlciwgYm91bmRzLmxlZnQgKyBib3VuZHMud2lkdGgsIGJvdW5kcy50b3ApO1xuICAgICAgICBwYXJzZUNvcm5lcihib3JkZXJBcmdzLCByYWRpdXNbMl0sIHJhZGl1c1szXSwgYm9yZGVyUG9pbnRzLmJvdHRvbVJpZ2h0T3V0ZXIsIGJvcmRlclBvaW50cy5ib3R0b21MZWZ0T3V0ZXIsIGJvdW5kcy5sZWZ0ICsgYm91bmRzLndpZHRoLCBib3VuZHMudG9wICsgYm91bmRzLmhlaWdodCk7XG4gICAgICAgIHBhcnNlQ29ybmVyKGJvcmRlckFyZ3MsIHJhZGl1c1szXSwgcmFkaXVzWzBdLCBib3JkZXJQb2ludHMuYm90dG9tTGVmdE91dGVyLCBib3JkZXJQb2ludHMudG9wTGVmdE91dGVyLCBib3VuZHMubGVmdCwgYm91bmRzLnRvcCArIGJvdW5kcy5oZWlnaHQpO1xuICAgICAgICBicmVhaztcbiAgICB9XG5cbiAgICByZXR1cm4gYm9yZGVyQXJncztcbiAgfVxuXG4gIGZ1bmN0aW9uIHBhcnNlQm9yZGVycyhlbGVtZW50LCBib3VuZHMsIGJvcmRlcnMpe1xuICAgIHZhciB4ID0gYm91bmRzLmxlZnQsXG4gICAgeSA9IGJvdW5kcy50b3AsXG4gICAgd2lkdGggPSBib3VuZHMud2lkdGgsXG4gICAgaGVpZ2h0ID0gYm91bmRzLmhlaWdodCxcbiAgICBib3JkZXJTaWRlLFxuICAgIGJ4LFxuICAgIGJ5LFxuICAgIGJ3LFxuICAgIGJoLFxuICAgIGJvcmRlckFyZ3MsXG4gICAgLy8gaHR0cDovL3d3dy53My5vcmcvVFIvY3NzMy1iYWNrZ3JvdW5kLyN0aGUtYm9yZGVyLXJhZGl1c1xuICAgIGJvcmRlclJhZGl1cyA9IGdldEJvcmRlclJhZGl1c0RhdGEoZWxlbWVudCksXG4gICAgYm9yZGVyUG9pbnRzID0gY2FsY3VsYXRlQ3VydmVQb2ludHMoYm91bmRzLCBib3JkZXJSYWRpdXMsIGJvcmRlcnMpLFxuICAgIGJvcmRlckRhdGEgPSB7XG4gICAgICBjbGlwOiBnZXRCb3JkZXJDbGlwKGVsZW1lbnQsIGJvcmRlclBvaW50cywgYm9yZGVycywgYm9yZGVyUmFkaXVzLCBib3VuZHMpLFxuICAgICAgYm9yZGVyczogW11cbiAgICB9O1xuXG4gICAgZm9yIChib3JkZXJTaWRlID0gMDsgYm9yZGVyU2lkZSA8IDQ7IGJvcmRlclNpZGUrKykge1xuXG4gICAgICBpZiAoYm9yZGVyc1tib3JkZXJTaWRlXS53aWR0aCA+IDApIHtcbiAgICAgICAgYnggPSB4O1xuICAgICAgICBieSA9IHk7XG4gICAgICAgIGJ3ID0gd2lkdGg7XG4gICAgICAgIGJoID0gaGVpZ2h0IC0gKGJvcmRlcnNbMl0ud2lkdGgpO1xuXG4gICAgICAgIHN3aXRjaChib3JkZXJTaWRlKSB7XG4gICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgLy8gdG9wIGJvcmRlclxuICAgICAgICAgICAgYmggPSBib3JkZXJzWzBdLndpZHRoO1xuXG4gICAgICAgICAgICBib3JkZXJBcmdzID0gZHJhd1NpZGUoe1xuICAgICAgICAgICAgICBjMTogW2J4LCBieV0sXG4gICAgICAgICAgICAgIGMyOiBbYnggKyBidywgYnldLFxuICAgICAgICAgICAgICBjMzogW2J4ICsgYncgLSBib3JkZXJzWzFdLndpZHRoLCBieSArIGJoXSxcbiAgICAgICAgICAgICAgYzQ6IFtieCArIGJvcmRlcnNbM10ud2lkdGgsIGJ5ICsgYmhdXG4gICAgICAgICAgICB9LCBib3JkZXJSYWRpdXNbMF0sIGJvcmRlclJhZGl1c1sxXSxcbiAgICAgICAgICAgIGJvcmRlclBvaW50cy50b3BMZWZ0T3V0ZXIsIGJvcmRlclBvaW50cy50b3BMZWZ0SW5uZXIsIGJvcmRlclBvaW50cy50b3BSaWdodE91dGVyLCBib3JkZXJQb2ludHMudG9wUmlnaHRJbm5lcik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICBjYXNlIDE6XG4gICAgICAgICAgICAvLyByaWdodCBib3JkZXJcbiAgICAgICAgICAgIGJ4ID0geCArIHdpZHRoIC0gKGJvcmRlcnNbMV0ud2lkdGgpO1xuICAgICAgICAgICAgYncgPSBib3JkZXJzWzFdLndpZHRoO1xuXG4gICAgICAgICAgICBib3JkZXJBcmdzID0gZHJhd1NpZGUoe1xuICAgICAgICAgICAgICBjMTogW2J4ICsgYncsIGJ5XSxcbiAgICAgICAgICAgICAgYzI6IFtieCArIGJ3LCBieSArIGJoICsgYm9yZGVyc1syXS53aWR0aF0sXG4gICAgICAgICAgICAgIGMzOiBbYngsIGJ5ICsgYmhdLFxuICAgICAgICAgICAgICBjNDogW2J4LCBieSArIGJvcmRlcnNbMF0ud2lkdGhdXG4gICAgICAgICAgICB9LCBib3JkZXJSYWRpdXNbMV0sIGJvcmRlclJhZGl1c1syXSxcbiAgICAgICAgICAgIGJvcmRlclBvaW50cy50b3BSaWdodE91dGVyLCBib3JkZXJQb2ludHMudG9wUmlnaHRJbm5lciwgYm9yZGVyUG9pbnRzLmJvdHRvbVJpZ2h0T3V0ZXIsIGJvcmRlclBvaW50cy5ib3R0b21SaWdodElubmVyKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgIC8vIGJvdHRvbSBib3JkZXJcbiAgICAgICAgICAgIGJ5ID0gKGJ5ICsgaGVpZ2h0KSAtIChib3JkZXJzWzJdLndpZHRoKTtcbiAgICAgICAgICAgIGJoID0gYm9yZGVyc1syXS53aWR0aDtcblxuICAgICAgICAgICAgYm9yZGVyQXJncyA9IGRyYXdTaWRlKHtcbiAgICAgICAgICAgICAgYzE6IFtieCArIGJ3LCBieSArIGJoXSxcbiAgICAgICAgICAgICAgYzI6IFtieCwgYnkgKyBiaF0sXG4gICAgICAgICAgICAgIGMzOiBbYnggKyBib3JkZXJzWzNdLndpZHRoLCBieV0sXG4gICAgICAgICAgICAgIGM0OiBbYnggKyBidyAtIGJvcmRlcnNbM10ud2lkdGgsIGJ5XVxuICAgICAgICAgICAgfSwgYm9yZGVyUmFkaXVzWzJdLCBib3JkZXJSYWRpdXNbM10sXG4gICAgICAgICAgICBib3JkZXJQb2ludHMuYm90dG9tUmlnaHRPdXRlciwgYm9yZGVyUG9pbnRzLmJvdHRvbVJpZ2h0SW5uZXIsIGJvcmRlclBvaW50cy5ib3R0b21MZWZ0T3V0ZXIsIGJvcmRlclBvaW50cy5ib3R0b21MZWZ0SW5uZXIpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSAzOlxuICAgICAgICAgICAgLy8gbGVmdCBib3JkZXJcbiAgICAgICAgICAgIGJ3ID0gYm9yZGVyc1szXS53aWR0aDtcblxuICAgICAgICAgICAgYm9yZGVyQXJncyA9IGRyYXdTaWRlKHtcbiAgICAgICAgICAgICAgYzE6IFtieCwgYnkgKyBiaCArIGJvcmRlcnNbMl0ud2lkdGhdLFxuICAgICAgICAgICAgICBjMjogW2J4LCBieV0sXG4gICAgICAgICAgICAgIGMzOiBbYnggKyBidywgYnkgKyBib3JkZXJzWzBdLndpZHRoXSxcbiAgICAgICAgICAgICAgYzQ6IFtieCArIGJ3LCBieSArIGJoXVxuICAgICAgICAgICAgfSwgYm9yZGVyUmFkaXVzWzNdLCBib3JkZXJSYWRpdXNbMF0sXG4gICAgICAgICAgICBib3JkZXJQb2ludHMuYm90dG9tTGVmdE91dGVyLCBib3JkZXJQb2ludHMuYm90dG9tTGVmdElubmVyLCBib3JkZXJQb2ludHMudG9wTGVmdE91dGVyLCBib3JkZXJQb2ludHMudG9wTGVmdElubmVyKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG5cbiAgICAgICAgYm9yZGVyRGF0YS5ib3JkZXJzLnB1c2goe1xuICAgICAgICAgIGFyZ3M6IGJvcmRlckFyZ3MsXG4gICAgICAgICAgY29sb3I6IGJvcmRlcnNbYm9yZGVyU2lkZV0uY29sb3JcbiAgICAgICAgfSk7XG5cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gYm9yZGVyRGF0YTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNyZWF0ZVNoYXBlKGN0eCwgYXJncykge1xuICAgIHZhciBzaGFwZSA9IGN0eC5kcmF3U2hhcGUoKTtcbiAgICBhcmdzLmZvckVhY2goZnVuY3Rpb24oYm9yZGVyLCBpbmRleCkge1xuICAgICAgc2hhcGVbKGluZGV4ID09PSAwKSA/IFwibW92ZVRvXCIgOiBib3JkZXJbMF0gKyBcIlRvXCIgXS5hcHBseShudWxsLCBib3JkZXIuc2xpY2UoMSkpO1xuICAgIH0pO1xuICAgIHJldHVybiBzaGFwZTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHJlbmRlckJvcmRlcnMoY3R4LCBib3JkZXJBcmdzLCBjb2xvcikge1xuICAgIGlmIChjb2xvciAhPT0gXCJ0cmFuc3BhcmVudFwiKSB7XG4gICAgICBjdHguc2V0VmFyaWFibGUoIFwiZmlsbFN0eWxlXCIsIGNvbG9yKTtcbiAgICAgIGNyZWF0ZVNoYXBlKGN0eCwgYm9yZGVyQXJncyk7XG4gICAgICBjdHguZmlsbCgpO1xuICAgICAgbnVtRHJhd3MrPTE7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gcmVuZGVyRm9ybVZhbHVlIChlbCwgYm91bmRzLCBzdGFjayl7XG5cbiAgICB2YXIgdmFsdWVXcmFwID0gZG9jLmNyZWF0ZUVsZW1lbnQoJ3ZhbHVld3JhcCcpLFxuICAgIGNzc1Byb3BlcnR5QXJyYXkgPSBbJ2xpbmVIZWlnaHQnLCd0ZXh0QWxpZ24nLCdmb250RmFtaWx5JywnY29sb3InLCdmb250U2l6ZScsJ3BhZGRpbmdMZWZ0JywncGFkZGluZ1RvcCcsJ3dpZHRoJywnaGVpZ2h0JywnYm9yZGVyJywnYm9yZGVyTGVmdFdpZHRoJywnYm9yZGVyVG9wV2lkdGgnXSxcbiAgICB0ZXh0VmFsdWUsXG4gICAgdGV4dE5vZGU7XG5cbiAgICBjc3NQcm9wZXJ0eUFycmF5LmZvckVhY2goZnVuY3Rpb24ocHJvcGVydHkpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHZhbHVlV3JhcC5zdHlsZVtwcm9wZXJ0eV0gPSBnZXRDU1MoZWwsIHByb3BlcnR5KTtcbiAgICAgIH0gY2F0Y2goZSkge1xuICAgICAgICAvLyBPbGRlciBJRSBoYXMgaXNzdWVzIHdpdGggXCJib3JkZXJcIlxuICAgICAgICBVdGlsLmxvZyhcImh0bWwyY2FudmFzOiBQYXJzZTogRXhjZXB0aW9uIGNhdWdodCBpbiByZW5kZXJGb3JtVmFsdWU6IFwiICsgZS5tZXNzYWdlKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHZhbHVlV3JhcC5zdHlsZS5ib3JkZXJDb2xvciA9IFwiYmxhY2tcIjtcbiAgICB2YWx1ZVdyYXAuc3R5bGUuYm9yZGVyU3R5bGUgPSBcInNvbGlkXCI7XG4gICAgdmFsdWVXcmFwLnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XG4gICAgdmFsdWVXcmFwLnN0eWxlLnBvc2l0aW9uID0gXCJhYnNvbHV0ZVwiO1xuXG4gICAgaWYgKC9eKHN1Ym1pdHxyZXNldHxidXR0b258dGV4dHxwYXNzd29yZCkkLy50ZXN0KGVsLnR5cGUpIHx8IGVsLm5vZGVOYW1lID09PSBcIlNFTEVDVFwiKXtcbiAgICAgIHZhbHVlV3JhcC5zdHlsZS5saW5lSGVpZ2h0ID0gZ2V0Q1NTKGVsLCBcImhlaWdodFwiKTtcbiAgICB9XG5cbiAgICB2YWx1ZVdyYXAuc3R5bGUudG9wID0gYm91bmRzLnRvcCArIFwicHhcIjtcbiAgICB2YWx1ZVdyYXAuc3R5bGUubGVmdCA9IGJvdW5kcy5sZWZ0ICsgXCJweFwiO1xuXG4gICAgdGV4dFZhbHVlID0gKGVsLm5vZGVOYW1lID09PSBcIlNFTEVDVFwiKSA/IChlbC5vcHRpb25zW2VsLnNlbGVjdGVkSW5kZXhdIHx8IDApLnRleHQgOiBlbC52YWx1ZTtcbiAgICBpZighdGV4dFZhbHVlKSB7XG4gICAgICB0ZXh0VmFsdWUgPSBlbC5wbGFjZWhvbGRlcjtcbiAgICB9XG5cbiAgICB0ZXh0Tm9kZSA9IGRvYy5jcmVhdGVUZXh0Tm9kZSh0ZXh0VmFsdWUpO1xuXG4gICAgdmFsdWVXcmFwLmFwcGVuZENoaWxkKHRleHROb2RlKTtcbiAgICBib2R5LmFwcGVuZENoaWxkKHZhbHVlV3JhcCk7XG5cbiAgICByZW5kZXJUZXh0KGVsLCB0ZXh0Tm9kZSwgc3RhY2spO1xuICAgIGJvZHkucmVtb3ZlQ2hpbGQodmFsdWVXcmFwKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGRyYXdJbWFnZSAoY3R4KSB7XG4gICAgY3R4LmRyYXdJbWFnZS5hcHBseShjdHgsIEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cywgMSkpO1xuICAgIG51bURyYXdzKz0xO1xuICB9XG5cbiAgZnVuY3Rpb24gZ2V0UHNldWRvRWxlbWVudChlbCwgd2hpY2gpIHtcbiAgICB2YXIgZWxTdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsLCB3aGljaCk7XG4gICAgdmFyIHBhcmVudFN0eWxlID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWwpO1xuICAgIC8vIElmIG5vIGNvbnRlbnQgYXR0cmlidXRlIGlzIHByZXNlbnQsIHRoZSBwc2V1ZG8gZWxlbWVudCBpcyBoaWRkZW4sXG4gICAgLy8gb3IgdGhlIHBhcmVudCBoYXMgYSBjb250ZW50IHByb3BlcnR5IGVxdWFsIHRvIHRoZSBjb250ZW50IG9uIHRoZSBwc2V1ZG8gZWxlbWVudCxcbiAgICAvLyBtb3ZlIGFsb25nLlxuICAgIGlmKCFlbFN0eWxlIHx8ICFlbFN0eWxlLmNvbnRlbnQgfHwgZWxTdHlsZS5jb250ZW50ID09PSBcIm5vbmVcIiB8fCBlbFN0eWxlLmNvbnRlbnQgPT09IFwiLW1vei1hbHQtY29udGVudFwiIHx8XG4gICAgICAgZWxTdHlsZS5kaXNwbGF5ID09PSBcIm5vbmVcIiB8fCBwYXJlbnRTdHlsZS5jb250ZW50ID09PSBlbFN0eWxlLmNvbnRlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIGNvbnRlbnQgPSBlbFN0eWxlLmNvbnRlbnQgKyAnJztcblxuICAgIC8vIFN0cmlwIGlubmVyIHF1b3Rlc1xuICAgIGlmKGNvbnRlbnRbMF0gPT09IFwiJ1wiIHx8IGNvbnRlbnRbMF0gPT09IFwiXFxcIlwiKSB7XG4gICAgICBjb250ZW50ID0gY29udGVudC5yZXBsYWNlKC8oXlsnXCJdKXwoWydcIl0kKS9nLCAnJyk7XG4gICAgfVxuXG4gICAgdmFyIGlzSW1hZ2UgPSBjb250ZW50LnN1YnN0ciggMCwgMyApID09PSAndXJsJyxcbiAgICBlbHBzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCggaXNJbWFnZSA/ICdpbWcnIDogJ3NwYW4nICk7XG5cbiAgICBlbHBzLmNsYXNzTmFtZSA9IHBzZXVkb0hpZGUgKyBcIi1lbGVtZW50IFwiO1xuXG4gICAgT2JqZWN0LmtleXMoZWxTdHlsZSkuZmlsdGVyKGluZGV4ZWRQcm9wZXJ0eSkuZm9yRWFjaChmdW5jdGlvbihwcm9wKSB7XG4gICAgICAvLyBQcmV2ZW50IGFzc2lnbmluZyBvZiByZWFkIG9ubHkgQ1NTIFJ1bGVzLCBleC4gbGVuZ3RoLCBwYXJlbnRSdWxlXG4gICAgICB0cnkge1xuICAgICAgICBlbHBzLnN0eWxlW3Byb3BdID0gZWxTdHlsZVtwcm9wXTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgVXRpbC5sb2coWydUcmllZCB0byBhc3NpZ24gcmVhZG9ubHkgcHJvcGVydHkgJywgcHJvcCwgJ0Vycm9yOicsIGVdKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGlmKGlzSW1hZ2UpIHtcbiAgICAgIGVscHMuc3JjID0gVXRpbC5wYXJzZUJhY2tncm91bmRJbWFnZShjb250ZW50KVswXS5hcmdzWzBdO1xuICAgIH0gZWxzZSB7XG4gICAgICBlbHBzLmlubmVySFRNTCA9IGNvbnRlbnQ7XG4gICAgfVxuICAgIHJldHVybiBlbHBzO1xuICB9XG5cbiAgZnVuY3Rpb24gaW5kZXhlZFByb3BlcnR5KHByb3BlcnR5KSB7XG4gICAgcmV0dXJuIChpc05hTih3aW5kb3cucGFyc2VJbnQocHJvcGVydHksIDEwKSkpO1xuICB9XG5cbiAgZnVuY3Rpb24gcmVuZGVyQmFja2dyb3VuZFJlcGVhdChjdHgsIGltYWdlLCBiYWNrZ3JvdW5kUG9zaXRpb24sIGJvdW5kcykge1xuICAgIHZhciBvZmZzZXRYID0gTWF0aC5yb3VuZChib3VuZHMubGVmdCArIGJhY2tncm91bmRQb3NpdGlvbi5sZWZ0KSxcbiAgICBvZmZzZXRZID0gTWF0aC5yb3VuZChib3VuZHMudG9wICsgYmFja2dyb3VuZFBvc2l0aW9uLnRvcCk7XG5cbiAgICBjdHguY3JlYXRlUGF0dGVybihpbWFnZSk7XG4gICAgY3R4LnRyYW5zbGF0ZShvZmZzZXRYLCBvZmZzZXRZKTtcbiAgICBjdHguZmlsbCgpO1xuICAgIGN0eC50cmFuc2xhdGUoLW9mZnNldFgsIC1vZmZzZXRZKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGJhY2tncm91bmRSZXBlYXRTaGFwZShjdHgsIGltYWdlLCBiYWNrZ3JvdW5kUG9zaXRpb24sIGJvdW5kcywgbGVmdCwgdG9wLCB3aWR0aCwgaGVpZ2h0KSB7XG4gICAgdmFyIGFyZ3MgPSBbXTtcbiAgICBhcmdzLnB1c2goW1wibGluZVwiLCBNYXRoLnJvdW5kKGxlZnQpLCBNYXRoLnJvdW5kKHRvcCldKTtcbiAgICBhcmdzLnB1c2goW1wibGluZVwiLCBNYXRoLnJvdW5kKGxlZnQgKyB3aWR0aCksIE1hdGgucm91bmQodG9wKV0pO1xuICAgIGFyZ3MucHVzaChbXCJsaW5lXCIsIE1hdGgucm91bmQobGVmdCArIHdpZHRoKSwgTWF0aC5yb3VuZChoZWlnaHQgKyB0b3ApXSk7XG4gICAgYXJncy5wdXNoKFtcImxpbmVcIiwgTWF0aC5yb3VuZChsZWZ0KSwgTWF0aC5yb3VuZChoZWlnaHQgKyB0b3ApXSk7XG4gICAgY3JlYXRlU2hhcGUoY3R4LCBhcmdzKTtcbiAgICBjdHguc2F2ZSgpO1xuICAgIGN0eC5jbGlwKCk7XG4gICAgcmVuZGVyQmFja2dyb3VuZFJlcGVhdChjdHgsIGltYWdlLCBiYWNrZ3JvdW5kUG9zaXRpb24sIGJvdW5kcyk7XG4gICAgY3R4LnJlc3RvcmUoKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHJlbmRlckJhY2tncm91bmRDb2xvcihjdHgsIGJhY2tncm91bmRCb3VuZHMsIGJnY29sb3IpIHtcbiAgICByZW5kZXJSZWN0KFxuICAgICAgY3R4LFxuICAgICAgYmFja2dyb3VuZEJvdW5kcy5sZWZ0LFxuICAgICAgYmFja2dyb3VuZEJvdW5kcy50b3AsXG4gICAgICBiYWNrZ3JvdW5kQm91bmRzLndpZHRoLFxuICAgICAgYmFja2dyb3VuZEJvdW5kcy5oZWlnaHQsXG4gICAgICBiZ2NvbG9yXG4gICAgICApO1xuICB9XG5cbiAgZnVuY3Rpb24gcmVuZGVyQmFja2dyb3VuZFJlcGVhdGluZyhlbCwgYm91bmRzLCBjdHgsIGltYWdlLCBpbWFnZUluZGV4KSB7XG4gICAgdmFyIGJhY2tncm91bmRTaXplID0gVXRpbC5CYWNrZ3JvdW5kU2l6ZShlbCwgYm91bmRzLCBpbWFnZSwgaW1hZ2VJbmRleCksXG4gICAgYmFja2dyb3VuZFBvc2l0aW9uID0gVXRpbC5CYWNrZ3JvdW5kUG9zaXRpb24oZWwsIGJvdW5kcywgaW1hZ2UsIGltYWdlSW5kZXgsIGJhY2tncm91bmRTaXplKSxcbiAgICBiYWNrZ3JvdW5kUmVwZWF0ID0gVXRpbC5CYWNrZ3JvdW5kUmVwZWF0KGVsLCBpbWFnZUluZGV4KTtcblxuICAgIGltYWdlID0gcmVzaXplSW1hZ2UoaW1hZ2UsIGJhY2tncm91bmRTaXplKTtcblxuICAgIHN3aXRjaCAoYmFja2dyb3VuZFJlcGVhdCkge1xuICAgICAgY2FzZSBcInJlcGVhdC14XCI6XG4gICAgICBjYXNlIFwicmVwZWF0IG5vLXJlcGVhdFwiOlxuICAgICAgICBiYWNrZ3JvdW5kUmVwZWF0U2hhcGUoY3R4LCBpbWFnZSwgYmFja2dyb3VuZFBvc2l0aW9uLCBib3VuZHMsXG4gICAgICAgICAgYm91bmRzLmxlZnQsIGJvdW5kcy50b3AgKyBiYWNrZ3JvdW5kUG9zaXRpb24udG9wLCA5OTk5OSwgaW1hZ2UuaGVpZ2h0KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwicmVwZWF0LXlcIjpcbiAgICAgIGNhc2UgXCJuby1yZXBlYXQgcmVwZWF0XCI6XG4gICAgICAgIGJhY2tncm91bmRSZXBlYXRTaGFwZShjdHgsIGltYWdlLCBiYWNrZ3JvdW5kUG9zaXRpb24sIGJvdW5kcyxcbiAgICAgICAgICBib3VuZHMubGVmdCArIGJhY2tncm91bmRQb3NpdGlvbi5sZWZ0LCBib3VuZHMudG9wLCBpbWFnZS53aWR0aCwgOTk5OTkpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJuby1yZXBlYXRcIjpcbiAgICAgICAgYmFja2dyb3VuZFJlcGVhdFNoYXBlKGN0eCwgaW1hZ2UsIGJhY2tncm91bmRQb3NpdGlvbiwgYm91bmRzLFxuICAgICAgICAgIGJvdW5kcy5sZWZ0ICsgYmFja2dyb3VuZFBvc2l0aW9uLmxlZnQsIGJvdW5kcy50b3AgKyBiYWNrZ3JvdW5kUG9zaXRpb24udG9wLCBpbWFnZS53aWR0aCwgaW1hZ2UuaGVpZ2h0KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZW5kZXJCYWNrZ3JvdW5kUmVwZWF0KGN0eCwgaW1hZ2UsIGJhY2tncm91bmRQb3NpdGlvbiwge1xuICAgICAgICAgIHRvcDogYm91bmRzLnRvcCxcbiAgICAgICAgICBsZWZ0OiBib3VuZHMubGVmdCxcbiAgICAgICAgICB3aWR0aDogaW1hZ2Uud2lkdGgsXG4gICAgICAgICAgaGVpZ2h0OiBpbWFnZS5oZWlnaHRcbiAgICAgICAgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHJlbmRlckJhY2tncm91bmRJbWFnZShlbGVtZW50LCBib3VuZHMsIGN0eCkge1xuICAgIHZhciBiYWNrZ3JvdW5kSW1hZ2UgPSBnZXRDU1MoZWxlbWVudCwgXCJiYWNrZ3JvdW5kSW1hZ2VcIiksXG4gICAgYmFja2dyb3VuZEltYWdlcyA9IFV0aWwucGFyc2VCYWNrZ3JvdW5kSW1hZ2UoYmFja2dyb3VuZEltYWdlKSxcbiAgICBpbWFnZSxcbiAgICBpbWFnZUluZGV4ID0gYmFja2dyb3VuZEltYWdlcy5sZW5ndGg7XG5cbiAgICB3aGlsZShpbWFnZUluZGV4LS0pIHtcbiAgICAgIGJhY2tncm91bmRJbWFnZSA9IGJhY2tncm91bmRJbWFnZXNbaW1hZ2VJbmRleF07XG5cbiAgICAgIGlmICghYmFja2dyb3VuZEltYWdlLmFyZ3MgfHwgYmFja2dyb3VuZEltYWdlLmFyZ3MubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICB2YXIga2V5ID0gYmFja2dyb3VuZEltYWdlLm1ldGhvZCA9PT0gJ3VybCcgP1xuICAgICAgYmFja2dyb3VuZEltYWdlLmFyZ3NbMF0gOlxuICAgICAgYmFja2dyb3VuZEltYWdlLnZhbHVlO1xuXG4gICAgICBpbWFnZSA9IGxvYWRJbWFnZShrZXkpO1xuXG4gICAgICAvLyBUT0RPIGFkZCBzdXBwb3J0IGZvciBiYWNrZ3JvdW5kLW9yaWdpblxuICAgICAgaWYgKGltYWdlKSB7XG4gICAgICAgIHJlbmRlckJhY2tncm91bmRSZXBlYXRpbmcoZWxlbWVudCwgYm91bmRzLCBjdHgsIGltYWdlLCBpbWFnZUluZGV4KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIFV0aWwubG9nKFwiaHRtbDJjYW52YXM6IEVycm9yIGxvYWRpbmcgYmFja2dyb3VuZDpcIiwgYmFja2dyb3VuZEltYWdlKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiByZXNpemVJbWFnZShpbWFnZSwgYm91bmRzKSB7XG4gICAgaWYoaW1hZ2Uud2lkdGggPT09IGJvdW5kcy53aWR0aCAmJiBpbWFnZS5oZWlnaHQgPT09IGJvdW5kcy5oZWlnaHQpIHtcbiAgICAgIHJldHVybiBpbWFnZTtcbiAgICB9XG5cbiAgICB2YXIgY3R4LCBjYW52YXMgPSBkb2MuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgY2FudmFzLndpZHRoID0gYm91bmRzLndpZHRoO1xuICAgIGNhbnZhcy5oZWlnaHQgPSBib3VuZHMuaGVpZ2h0O1xuICAgIGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XG4gICAgZHJhd0ltYWdlKGN0eCwgaW1hZ2UsIDAsIDAsIGltYWdlLndpZHRoLCBpbWFnZS5oZWlnaHQsIDAsIDAsIGJvdW5kcy53aWR0aCwgYm91bmRzLmhlaWdodCApO1xuICAgIHJldHVybiBjYW52YXM7XG4gIH1cblxuICBmdW5jdGlvbiBzZXRPcGFjaXR5KGN0eCwgZWxlbWVudCwgcGFyZW50U3RhY2spIHtcbiAgICByZXR1cm4gY3R4LnNldFZhcmlhYmxlKFwiZ2xvYmFsQWxwaGFcIiwgZ2V0Q1NTKGVsZW1lbnQsIFwib3BhY2l0eVwiKSAqICgocGFyZW50U3RhY2spID8gcGFyZW50U3RhY2sub3BhY2l0eSA6IDEpKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHJlbW92ZVB4KHN0cikge1xuICAgIHJldHVybiBzdHIucmVwbGFjZShcInB4XCIsIFwiXCIpO1xuICB9XG5cbiAgZnVuY3Rpb24gZ2V0VHJhbnNmb3JtKGVsZW1lbnQsIHBhcmVudFN0YWNrKSB7XG4gICAgdmFyIHRyYW5zZm9ybVJlZ0V4cCA9IC8obWF0cml4KVxcKCguKylcXCkvO1xuICAgIHZhciB0cmFuc2Zvcm0gPSBnZXRDU1MoZWxlbWVudCwgXCJ0cmFuc2Zvcm1cIikgfHwgZ2V0Q1NTKGVsZW1lbnQsIFwiLXdlYmtpdC10cmFuc2Zvcm1cIikgfHwgZ2V0Q1NTKGVsZW1lbnQsIFwiLW1vei10cmFuc2Zvcm1cIikgfHwgZ2V0Q1NTKGVsZW1lbnQsIFwiLW1zLXRyYW5zZm9ybVwiKSB8fCBnZXRDU1MoZWxlbWVudCwgXCItby10cmFuc2Zvcm1cIik7XG4gICAgdmFyIHRyYW5zZm9ybU9yaWdpbiA9IGdldENTUyhlbGVtZW50LCBcInRyYW5zZm9ybS1vcmlnaW5cIikgfHwgZ2V0Q1NTKGVsZW1lbnQsIFwiLXdlYmtpdC10cmFuc2Zvcm0tb3JpZ2luXCIpIHx8IGdldENTUyhlbGVtZW50LCBcIi1tb3otdHJhbnNmb3JtLW9yaWdpblwiKSB8fCBnZXRDU1MoZWxlbWVudCwgXCItbXMtdHJhbnNmb3JtLW9yaWdpblwiKSB8fCBnZXRDU1MoZWxlbWVudCwgXCItby10cmFuc2Zvcm0tb3JpZ2luXCIpIHx8IFwiMHB4IDBweFwiO1xuXG4gICAgdHJhbnNmb3JtT3JpZ2luID0gdHJhbnNmb3JtT3JpZ2luLnNwbGl0KFwiIFwiKS5tYXAocmVtb3ZlUHgpLm1hcChVdGlsLmFzRmxvYXQpO1xuXG4gICAgdmFyIG1hdHJpeDtcbiAgICBpZiAodHJhbnNmb3JtICYmIHRyYW5zZm9ybSAhPT0gXCJub25lXCIpIHtcbiAgICAgIHZhciBtYXRjaCA9IHRyYW5zZm9ybS5tYXRjaCh0cmFuc2Zvcm1SZWdFeHApO1xuICAgICAgaWYgKG1hdGNoKSB7XG4gICAgICAgIHN3aXRjaChtYXRjaFsxXSkge1xuICAgICAgICAgIGNhc2UgXCJtYXRyaXhcIjpcbiAgICAgICAgICAgIG1hdHJpeCA9IG1hdGNoWzJdLnNwbGl0KFwiLFwiKS5tYXAoVXRpbC50cmltVGV4dCkubWFwKFV0aWwuYXNGbG9hdCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBvcmlnaW46IHRyYW5zZm9ybU9yaWdpbixcbiAgICAgIG1hdHJpeDogbWF0cml4XG4gICAgfTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNyZWF0ZVN0YWNrKGVsZW1lbnQsIHBhcmVudFN0YWNrLCBib3VuZHMsIHRyYW5zZm9ybSkge1xuICAgIHZhciBjdHggPSBoMmNSZW5kZXJDb250ZXh0KCghcGFyZW50U3RhY2spID8gZG9jdW1lbnRXaWR0aCgpIDogYm91bmRzLndpZHRoICwgKCFwYXJlbnRTdGFjaykgPyBkb2N1bWVudEhlaWdodCgpIDogYm91bmRzLmhlaWdodCksXG4gICAgc3RhY2sgPSB7XG4gICAgICBjdHg6IGN0eCxcbiAgICAgIG9wYWNpdHk6IHNldE9wYWNpdHkoY3R4LCBlbGVtZW50LCBwYXJlbnRTdGFjayksXG4gICAgICBjc3NQb3NpdGlvbjogZ2V0Q1NTKGVsZW1lbnQsIFwicG9zaXRpb25cIiksXG4gICAgICBib3JkZXJzOiBnZXRCb3JkZXJEYXRhKGVsZW1lbnQpLFxuICAgICAgdHJhbnNmb3JtOiB0cmFuc2Zvcm0sXG4gICAgICBjbGlwOiAocGFyZW50U3RhY2sgJiYgcGFyZW50U3RhY2suY2xpcCkgPyBVdGlsLkV4dGVuZCgge30sIHBhcmVudFN0YWNrLmNsaXAgKSA6IG51bGxcbiAgICB9O1xuXG4gICAgc2V0WihlbGVtZW50LCBzdGFjaywgcGFyZW50U3RhY2spO1xuXG4gICAgLy8gVE9ETyBjb3JyZWN0IG92ZXJmbG93IGZvciBhYnNvbHV0ZSBjb250ZW50IHJlc2lkaW5nIHVuZGVyIGEgc3RhdGljIHBvc2l0aW9uXG4gICAgaWYgKG9wdGlvbnMudXNlT3ZlcmZsb3cgPT09IHRydWUgJiYgLyhoaWRkZW58c2Nyb2xsfGF1dG8pLy50ZXN0KGdldENTUyhlbGVtZW50LCBcIm92ZXJmbG93XCIpKSA9PT0gdHJ1ZSAmJiAvKEJPRFkpL2kudGVzdChlbGVtZW50Lm5vZGVOYW1lKSA9PT0gZmFsc2Upe1xuICAgICAgc3RhY2suY2xpcCA9IChzdGFjay5jbGlwKSA/IGNsaXBCb3VuZHMoc3RhY2suY2xpcCwgYm91bmRzKSA6IGJvdW5kcztcbiAgICB9XG5cbiAgICByZXR1cm4gc3RhY2s7XG4gIH1cblxuICBmdW5jdGlvbiBnZXRCYWNrZ3JvdW5kQm91bmRzKGJvcmRlcnMsIGJvdW5kcywgY2xpcCkge1xuICAgIHZhciBiYWNrZ3JvdW5kQm91bmRzID0ge1xuICAgICAgbGVmdDogYm91bmRzLmxlZnQgKyBib3JkZXJzWzNdLndpZHRoLFxuICAgICAgdG9wOiBib3VuZHMudG9wICsgYm9yZGVyc1swXS53aWR0aCxcbiAgICAgIHdpZHRoOiBib3VuZHMud2lkdGggLSAoYm9yZGVyc1sxXS53aWR0aCArIGJvcmRlcnNbM10ud2lkdGgpLFxuICAgICAgaGVpZ2h0OiBib3VuZHMuaGVpZ2h0IC0gKGJvcmRlcnNbMF0ud2lkdGggKyBib3JkZXJzWzJdLndpZHRoKVxuICAgIH07XG5cbiAgICBpZiAoY2xpcCkge1xuICAgICAgYmFja2dyb3VuZEJvdW5kcyA9IGNsaXBCb3VuZHMoYmFja2dyb3VuZEJvdW5kcywgY2xpcCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGJhY2tncm91bmRCb3VuZHM7XG4gIH1cblxuICBmdW5jdGlvbiBnZXRCb3VuZHMoZWxlbWVudCwgdHJhbnNmb3JtKSB7XG4gICAgdmFyIGJvdW5kcyA9ICh0cmFuc2Zvcm0ubWF0cml4KSA/IFV0aWwuT2Zmc2V0Qm91bmRzKGVsZW1lbnQpIDogVXRpbC5Cb3VuZHMoZWxlbWVudCk7XG4gICAgdHJhbnNmb3JtLm9yaWdpblswXSArPSBib3VuZHMubGVmdDtcbiAgICB0cmFuc2Zvcm0ub3JpZ2luWzFdICs9IGJvdW5kcy50b3A7XG4gICAgcmV0dXJuIGJvdW5kcztcbiAgfVxuXG4gIGZ1bmN0aW9uIHJlbmRlckVsZW1lbnQoZWxlbWVudCwgcGFyZW50U3RhY2ssIGlnbm9yZUJhY2tncm91bmQpIHtcbiAgICB2YXIgdHJhbnNmb3JtID0gZ2V0VHJhbnNmb3JtKGVsZW1lbnQsIHBhcmVudFN0YWNrKSxcbiAgICBib3VuZHMgPSBnZXRCb3VuZHMoZWxlbWVudCwgdHJhbnNmb3JtKSxcbiAgICBpbWFnZSxcbiAgICBzdGFjayA9IGNyZWF0ZVN0YWNrKGVsZW1lbnQsIHBhcmVudFN0YWNrLCBib3VuZHMsIHRyYW5zZm9ybSksXG4gICAgYm9yZGVycyA9IHN0YWNrLmJvcmRlcnMsXG4gICAgY3R4ID0gc3RhY2suY3R4LFxuICAgIGJhY2tncm91bmRCb3VuZHMgPSBnZXRCYWNrZ3JvdW5kQm91bmRzKGJvcmRlcnMsIGJvdW5kcywgc3RhY2suY2xpcCksXG4gICAgYm9yZGVyRGF0YSA9IHBhcnNlQm9yZGVycyhlbGVtZW50LCBib3VuZHMsIGJvcmRlcnMpLFxuICAgIGJhY2tncm91bmRDb2xvciA9IChpZ25vcmVFbGVtZW50c1JlZ0V4cC50ZXN0KGVsZW1lbnQubm9kZU5hbWUpKSA/IFwiI2VmZWZlZlwiIDogZ2V0Q1NTKGVsZW1lbnQsIFwiYmFja2dyb3VuZENvbG9yXCIpO1xuXG5cbiAgICBjcmVhdGVTaGFwZShjdHgsIGJvcmRlckRhdGEuY2xpcCk7XG5cbiAgICBjdHguc2F2ZSgpO1xuICAgIGN0eC5jbGlwKCk7XG5cbiAgICBpZiAoYmFja2dyb3VuZEJvdW5kcy5oZWlnaHQgPiAwICYmIGJhY2tncm91bmRCb3VuZHMud2lkdGggPiAwICYmICFpZ25vcmVCYWNrZ3JvdW5kKSB7XG4gICAgICByZW5kZXJCYWNrZ3JvdW5kQ29sb3IoY3R4LCBib3VuZHMsIGJhY2tncm91bmRDb2xvcik7XG4gICAgICByZW5kZXJCYWNrZ3JvdW5kSW1hZ2UoZWxlbWVudCwgYmFja2dyb3VuZEJvdW5kcywgY3R4KTtcbiAgICB9IGVsc2UgaWYgKGlnbm9yZUJhY2tncm91bmQpIHtcbiAgICAgIHN0YWNrLmJhY2tncm91bmRDb2xvciA9ICBiYWNrZ3JvdW5kQ29sb3I7XG4gICAgfVxuXG4gICAgY3R4LnJlc3RvcmUoKTtcblxuICAgIGJvcmRlckRhdGEuYm9yZGVycy5mb3JFYWNoKGZ1bmN0aW9uKGJvcmRlcikge1xuICAgICAgcmVuZGVyQm9yZGVycyhjdHgsIGJvcmRlci5hcmdzLCBib3JkZXIuY29sb3IpO1xuICAgIH0pO1xuXG4gICAgc3dpdGNoKGVsZW1lbnQubm9kZU5hbWUpe1xuICAgICAgY2FzZSBcIklNR1wiOlxuICAgICAgICBpZiAoKGltYWdlID0gbG9hZEltYWdlKGVsZW1lbnQuZ2V0QXR0cmlidXRlKCdzcmMnKSkpKSB7XG4gICAgICAgICAgcmVuZGVySW1hZ2UoY3R4LCBlbGVtZW50LCBpbWFnZSwgYm91bmRzLCBib3JkZXJzKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBVdGlsLmxvZyhcImh0bWwyY2FudmFzOiBFcnJvciBsb2FkaW5nIDxpbWc+OlwiICsgZWxlbWVudC5nZXRBdHRyaWJ1dGUoJ3NyYycpKTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJJTlBVVFwiOlxuICAgICAgICAvLyBUT0RPIGFkZCBhbGwgcmVsZXZhbnQgdHlwZSdzLCBpLmUuIEhUTUw1IG5ldyBzdHVmZlxuICAgICAgICAvLyB0b2RvIGFkZCBzdXBwb3J0IGZvciBwbGFjZWhvbGRlciBhdHRyaWJ1dGUgZm9yIGJyb3dzZXJzIHdoaWNoIHN1cHBvcnQgaXRcbiAgICAgICAgaWYgKC9eKHRleHR8dXJsfGVtYWlsfHN1Ym1pdHxidXR0b258cmVzZXQpJC8udGVzdChlbGVtZW50LnR5cGUpICYmIChlbGVtZW50LnZhbHVlIHx8IGVsZW1lbnQucGxhY2Vob2xkZXIgfHwgXCJcIikubGVuZ3RoID4gMCl7XG4gICAgICAgICAgcmVuZGVyRm9ybVZhbHVlKGVsZW1lbnQsIGJvdW5kcywgc3RhY2spO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcIlRFWFRBUkVBXCI6XG4gICAgICAgIGlmICgoZWxlbWVudC52YWx1ZSB8fCBlbGVtZW50LnBsYWNlaG9sZGVyIHx8IFwiXCIpLmxlbmd0aCA+IDApe1xuICAgICAgICAgIHJlbmRlckZvcm1WYWx1ZShlbGVtZW50LCBib3VuZHMsIHN0YWNrKTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJTRUxFQ1RcIjpcbiAgICAgICAgaWYgKChlbGVtZW50Lm9wdGlvbnN8fGVsZW1lbnQucGxhY2Vob2xkZXIgfHwgXCJcIikubGVuZ3RoID4gMCl7XG4gICAgICAgICAgcmVuZGVyRm9ybVZhbHVlKGVsZW1lbnQsIGJvdW5kcywgc3RhY2spO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcIkxJXCI6XG4gICAgICAgIHJlbmRlckxpc3RJdGVtKGVsZW1lbnQsIHN0YWNrLCBiYWNrZ3JvdW5kQm91bmRzKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiQ0FOVkFTXCI6XG4gICAgICAgIHJlbmRlckltYWdlKGN0eCwgZWxlbWVudCwgZWxlbWVudCwgYm91bmRzLCBib3JkZXJzKTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgcmV0dXJuIHN0YWNrO1xuICB9XG5cbiAgZnVuY3Rpb24gaXNFbGVtZW50VmlzaWJsZShlbGVtZW50KSB7XG4gICAgcmV0dXJuIChnZXRDU1MoZWxlbWVudCwgJ2Rpc3BsYXknKSAhPT0gXCJub25lXCIgJiYgZ2V0Q1NTKGVsZW1lbnQsICd2aXNpYmlsaXR5JykgIT09IFwiaGlkZGVuXCIgJiYgIWVsZW1lbnQuaGFzQXR0cmlidXRlKFwiZGF0YS1odG1sMmNhbnZhcy1pZ25vcmVcIikpO1xuICB9XG5cbiAgZnVuY3Rpb24gcGFyc2VFbGVtZW50IChlbGVtZW50LCBzdGFjaywgY2IpIHtcbiAgICBpZiAoIWNiKSB7XG4gICAgICBjYiA9IGZ1bmN0aW9uKCl7fTtcbiAgICB9XG4gICAgaWYgKGlzRWxlbWVudFZpc2libGUoZWxlbWVudCkpIHtcbiAgICAgIHN0YWNrID0gcmVuZGVyRWxlbWVudChlbGVtZW50LCBzdGFjaywgZmFsc2UpIHx8IHN0YWNrO1xuICAgICAgaWYgKCFpZ25vcmVFbGVtZW50c1JlZ0V4cC50ZXN0KGVsZW1lbnQubm9kZU5hbWUpKSB7XG4gICAgICAgIHJldHVybiBwYXJzZUNoaWxkcmVuKGVsZW1lbnQsIHN0YWNrLCBjYik7XG4gICAgICB9XG4gICAgfVxuICAgIGNiKCk7XG4gIH1cblxuICBmdW5jdGlvbiBwYXJzZUNoaWxkcmVuKGVsZW1lbnQsIHN0YWNrLCBjYikge1xuICAgIHZhciBjaGlsZHJlbiA9IFV0aWwuQ2hpbGRyZW4oZWxlbWVudCk7XG4gICAgLy8gQWZ0ZXIgYWxsIG5vZGVzIGhhdmUgcHJvY2Vzc2VkLCBmaW5pc2hlZCgpIHdpbGwgY2FsbCB0aGUgY2IuXG4gICAgLy8gV2UgYWRkIG9uZSBhbmQga2ljayBpdCBvZmYgc28gdGhpcyB3aWxsIHN0aWxsIHdvcmsgd2hlbiBjaGlsZHJlbi5sZW5ndGggPT09IDAuXG4gICAgLy8gTm90ZSB0aGF0IHVubGVzcyBhc3luYyBpcyB0cnVlLCB0aGlzIHdpbGwgaGFwcGVuIHN5bmNocm9ub3VzbHksIGp1c3Qgd2lsbCBjYWxsYmFja3MuXG4gICAgdmFyIGpvYnMgPSBjaGlsZHJlbi5sZW5ndGggKyAxO1xuICAgIGZpbmlzaGVkKCk7XG5cbiAgICBpZiAob3B0aW9ucy5hc3luYykge1xuICAgICAgY2hpbGRyZW4uZm9yRWFjaChmdW5jdGlvbihub2RlKSB7XG4gICAgICAgIC8vIERvbid0IGJsb2NrIHRoZSBwYWdlIGZyb20gcmVuZGVyaW5nXG4gICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKXsgcGFyc2VOb2RlKG5vZGUpOyB9LCAwKTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBjaGlsZHJlbi5mb3JFYWNoKHBhcnNlTm9kZSk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gcGFyc2VOb2RlKG5vZGUpIHtcbiAgICAgIGlmIChub2RlLm5vZGVUeXBlID09PSBub2RlLkVMRU1FTlRfTk9ERSkge1xuICAgICAgICBwYXJzZUVsZW1lbnQobm9kZSwgc3RhY2ssIGZpbmlzaGVkKTtcbiAgICAgIH0gZWxzZSBpZiAobm9kZS5ub2RlVHlwZSA9PT0gbm9kZS5URVhUX05PREUpIHtcbiAgICAgICAgcmVuZGVyVGV4dChlbGVtZW50LCBub2RlLCBzdGFjayk7XG4gICAgICAgIGZpbmlzaGVkKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBmaW5pc2hlZCgpO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBmaW5pc2hlZChlbCkge1xuICAgICAgaWYgKC0tam9icyA8PSAwKXtcbiAgICAgICAgVXRpbC5sb2coXCJmaW5pc2hlZCByZW5kZXJpbmcgXCIgKyBjaGlsZHJlbi5sZW5ndGggKyBcIiBjaGlsZHJlbi5cIik7XG4gICAgICAgIGNiKCk7XG4gICAgICB9XG4gICAgfVxuICB9XG59O1xuX2h0bWwyY2FudmFzLlByZWxvYWQgPSBmdW5jdGlvbiggb3B0aW9ucyApIHtcblxuICB2YXIgaW1hZ2VzID0ge1xuICAgIG51bUxvYWRlZDogMCwgICAvLyBhbHNvIGZhaWxlZCBhcmUgY291bnRlZCBoZXJlXG4gICAgbnVtRmFpbGVkOiAwLFxuICAgIG51bVRvdGFsOiAwLFxuICAgIGNsZWFudXBEb25lOiBmYWxzZVxuICB9LFxuICBwYWdlT3JpZ2luLFxuICBVdGlsID0gX2h0bWwyY2FudmFzLlV0aWwsXG4gIG1ldGhvZHMsXG4gIGksXG4gIGNvdW50ID0gMCxcbiAgZWxlbWVudCA9IG9wdGlvbnMuZWxlbWVudHNbMF0gfHwgZG9jdW1lbnQuYm9keSxcbiAgZG9jID0gZWxlbWVudC5vd25lckRvY3VtZW50LFxuICBkb21JbWFnZXMgPSBlbGVtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdpbWcnKSwgLy8gRmV0Y2ggaW1hZ2VzIG9mIHRoZSBwcmVzZW50IGVsZW1lbnQgb25seVxuICBpbWdMZW4gPSBkb21JbWFnZXMubGVuZ3RoLFxuICBsaW5rID0gZG9jLmNyZWF0ZUVsZW1lbnQoXCJhXCIpLFxuICBzdXBwb3J0Q09SUyA9IChmdW5jdGlvbiggaW1nICl7XG4gICAgcmV0dXJuIChpbWcuY3Jvc3NPcmlnaW4gIT09IHVuZGVmaW5lZCk7XG4gIH0pKG5ldyBJbWFnZSgpKSxcbiAgdGltZW91dFRpbWVyO1xuXG4gIGxpbmsuaHJlZiA9IHdpbmRvdy5sb2NhdGlvbi5ocmVmO1xuICBwYWdlT3JpZ2luICA9IGxpbmsucHJvdG9jb2wgKyBsaW5rLmhvc3Q7XG5cbiAgZnVuY3Rpb24gaXNTYW1lT3JpZ2luKHVybCl7XG4gICAgbGluay5ocmVmID0gdXJsO1xuICAgIGxpbmsuaHJlZiA9IGxpbmsuaHJlZjsgLy8gWUVTLCBCRUxJRVZFIElUIE9SIE5PVCwgdGhhdCBpcyByZXF1aXJlZCBmb3IgSUU5IC0gaHR0cDovL2pzZmlkZGxlLm5ldC9uaWtsYXN2aC8yZTQ4Yi9cbiAgICB2YXIgb3JpZ2luID0gbGluay5wcm90b2NvbCArIGxpbmsuaG9zdDtcbiAgICByZXR1cm4gKG9yaWdpbiA9PT0gcGFnZU9yaWdpbik7XG4gIH1cblxuICBmdW5jdGlvbiBzdGFydCgpe1xuICAgIFV0aWwubG9nKFwiaHRtbDJjYW52YXM6IHN0YXJ0OiBpbWFnZXM6IFwiICsgaW1hZ2VzLm51bUxvYWRlZCArIFwiIC8gXCIgKyBpbWFnZXMubnVtVG90YWwgKyBcIiAoZmFpbGVkOiBcIiArIGltYWdlcy5udW1GYWlsZWQgKyBcIilcIik7XG4gICAgaWYgKCFpbWFnZXMuZmlyc3RSdW4gJiYgaW1hZ2VzLm51bUxvYWRlZCA+PSBpbWFnZXMubnVtVG90YWwpe1xuICAgICAgVXRpbC5sb2coXCJGaW5pc2hlZCBsb2FkaW5nIGltYWdlczogIyBcIiArIGltYWdlcy5udW1Ub3RhbCArIFwiIChmYWlsZWQ6IFwiICsgaW1hZ2VzLm51bUZhaWxlZCArIFwiKVwiKTtcblxuICAgICAgaWYgKHR5cGVvZiBvcHRpb25zLmNvbXBsZXRlID09PSBcImZ1bmN0aW9uXCIpe1xuICAgICAgICBvcHRpb25zLmNvbXBsZXRlKGltYWdlcyk7XG4gICAgICB9XG5cbiAgICB9XG4gIH1cblxuICAvLyBUT0RPIG1vZGlmeSBwcm94eSB0byBzZXJ2ZSBpbWFnZXMgd2l0aCBDT1JTIGVuYWJsZWQsIHdoZXJlIGF2YWlsYWJsZVxuICBmdW5jdGlvbiBwcm94eUdldEltYWdlKHVybCwgaW1nLCBpbWFnZU9iail7XG4gICAgdmFyIGNhbGxiYWNrX25hbWUsXG4gICAgc2NyaXB0VXJsID0gb3B0aW9ucy5wcm94eSxcbiAgICBzY3JpcHQ7XG5cbiAgICBsaW5rLmhyZWYgPSB1cmw7XG4gICAgdXJsID0gbGluay5ocmVmOyAvLyB3b3JrIGFyb3VuZCBmb3IgcGFnZXMgd2l0aCBiYXNlIGhyZWY9XCJcIiBzZXQgLSBXQVJOSU5HOiB0aGlzIG1heSBjaGFuZ2UgdGhlIHVybFxuXG4gICAgY2FsbGJhY2tfbmFtZSA9ICdodG1sMmNhbnZhc18nICsgKGNvdW50KyspO1xuICAgIGltYWdlT2JqLmNhbGxiYWNrbmFtZSA9IGNhbGxiYWNrX25hbWU7XG5cbiAgICBpZiAoc2NyaXB0VXJsLmluZGV4T2YoXCI/XCIpID4gLTEpIHtcbiAgICAgIHNjcmlwdFVybCArPSBcIiZcIjtcbiAgICB9IGVsc2Uge1xuICAgICAgc2NyaXB0VXJsICs9IFwiP1wiO1xuICAgIH1cbiAgICBzY3JpcHRVcmwgKz0gJ3VybD0nICsgZW5jb2RlVVJJQ29tcG9uZW50KHVybCkgKyAnJmNhbGxiYWNrPScgKyBjYWxsYmFja19uYW1lO1xuICAgIHNjcmlwdCA9IGRvYy5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO1xuXG4gICAgd2luZG93W2NhbGxiYWNrX25hbWVdID0gZnVuY3Rpb24oYSl7XG4gICAgICBpZiAoYS5zdWJzdHJpbmcoMCw2KSA9PT0gXCJlcnJvcjpcIil7XG4gICAgICAgIGltYWdlT2JqLnN1Y2NlZWRlZCA9IGZhbHNlO1xuICAgICAgICBpbWFnZXMubnVtTG9hZGVkKys7XG4gICAgICAgIGltYWdlcy5udW1GYWlsZWQrKztcbiAgICAgICAgc3RhcnQoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldEltYWdlTG9hZEhhbmRsZXJzKGltZywgaW1hZ2VPYmopO1xuICAgICAgICBpbWcuc3JjID0gYTtcbiAgICAgIH1cbiAgICAgIHdpbmRvd1tjYWxsYmFja19uYW1lXSA9IHVuZGVmaW5lZDsgLy8gdG8gd29yayB3aXRoIElFPDkgIC8vIE5PVEU6IHRoYXQgdGhlIHVuZGVmaW5lZCBjYWxsYmFjayBwcm9wZXJ0eS1uYW1lIHN0aWxsIGV4aXN0cyBvbiB0aGUgd2luZG93IG9iamVjdCAoZm9yIElFPDkpXG4gICAgICB0cnkge1xuICAgICAgICBkZWxldGUgd2luZG93W2NhbGxiYWNrX25hbWVdOyAgLy8gZm9yIGFsbCBicm93c2VyIHRoYXQgc3VwcG9ydCB0aGlzXG4gICAgICB9IGNhdGNoKGV4KSB7fVxuICAgICAgc2NyaXB0LnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoc2NyaXB0KTtcbiAgICAgIHNjcmlwdCA9IG51bGw7XG4gICAgICBkZWxldGUgaW1hZ2VPYmouc2NyaXB0O1xuICAgICAgZGVsZXRlIGltYWdlT2JqLmNhbGxiYWNrbmFtZTtcbiAgICB9O1xuXG4gICAgc2NyaXB0LnNldEF0dHJpYnV0ZShcInR5cGVcIiwgXCJ0ZXh0L2phdmFzY3JpcHRcIik7XG4gICAgc2NyaXB0LnNldEF0dHJpYnV0ZShcInNyY1wiLCBzY3JpcHRVcmwpO1xuICAgIGltYWdlT2JqLnNjcmlwdCA9IHNjcmlwdDtcbiAgICB3aW5kb3cuZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzY3JpcHQpO1xuXG4gIH1cblxuICBmdW5jdGlvbiBsb2FkUHNldWRvRWxlbWVudChlbGVtZW50LCB0eXBlKSB7XG4gICAgdmFyIHN0eWxlID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxlbWVudCwgdHlwZSksXG4gICAgY29udGVudCA9IHN0eWxlLmNvbnRlbnQ7XG4gICAgaWYgKGNvbnRlbnQuc3Vic3RyKDAsIDMpID09PSAndXJsJykge1xuICAgICAgbWV0aG9kcy5sb2FkSW1hZ2UoX2h0bWwyY2FudmFzLlV0aWwucGFyc2VCYWNrZ3JvdW5kSW1hZ2UoY29udGVudClbMF0uYXJnc1swXSk7XG4gICAgfVxuICAgIGxvYWRCYWNrZ3JvdW5kSW1hZ2VzKHN0eWxlLmJhY2tncm91bmRJbWFnZSwgZWxlbWVudCk7XG4gIH1cblxuICBmdW5jdGlvbiBsb2FkUHNldWRvRWxlbWVudEltYWdlcyhlbGVtZW50KSB7XG4gICAgbG9hZFBzZXVkb0VsZW1lbnQoZWxlbWVudCwgXCI6YmVmb3JlXCIpO1xuICAgIGxvYWRQc2V1ZG9FbGVtZW50KGVsZW1lbnQsIFwiOmFmdGVyXCIpO1xuICB9XG5cbiAgZnVuY3Rpb24gbG9hZEdyYWRpZW50SW1hZ2UoYmFja2dyb3VuZEltYWdlLCBib3VuZHMpIHtcbiAgICB2YXIgaW1nID0gX2h0bWwyY2FudmFzLkdlbmVyYXRlLkdyYWRpZW50KGJhY2tncm91bmRJbWFnZSwgYm91bmRzKTtcblxuICAgIGlmIChpbWcgIT09IHVuZGVmaW5lZCl7XG4gICAgICBpbWFnZXNbYmFja2dyb3VuZEltYWdlXSA9IHtcbiAgICAgICAgaW1nOiBpbWcsXG4gICAgICAgIHN1Y2NlZWRlZDogdHJ1ZVxuICAgICAgfTtcbiAgICAgIGltYWdlcy5udW1Ub3RhbCsrO1xuICAgICAgaW1hZ2VzLm51bUxvYWRlZCsrO1xuICAgICAgc3RhcnQoKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBpbnZhbGlkQmFja2dyb3VuZHMoYmFja2dyb3VuZF9pbWFnZSkge1xuICAgIHJldHVybiAoYmFja2dyb3VuZF9pbWFnZSAmJiBiYWNrZ3JvdW5kX2ltYWdlLm1ldGhvZCAmJiBiYWNrZ3JvdW5kX2ltYWdlLmFyZ3MgJiYgYmFja2dyb3VuZF9pbWFnZS5hcmdzLmxlbmd0aCA+IDAgKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGxvYWRCYWNrZ3JvdW5kSW1hZ2VzKGJhY2tncm91bmRfaW1hZ2UsIGVsKSB7XG4gICAgdmFyIGJvdW5kcztcblxuICAgIF9odG1sMmNhbnZhcy5VdGlsLnBhcnNlQmFja2dyb3VuZEltYWdlKGJhY2tncm91bmRfaW1hZ2UpLmZpbHRlcihpbnZhbGlkQmFja2dyb3VuZHMpLmZvckVhY2goZnVuY3Rpb24oYmFja2dyb3VuZF9pbWFnZSkge1xuICAgICAgaWYgKGJhY2tncm91bmRfaW1hZ2UubWV0aG9kID09PSAndXJsJykge1xuICAgICAgICBtZXRob2RzLmxvYWRJbWFnZShiYWNrZ3JvdW5kX2ltYWdlLmFyZ3NbMF0pO1xuICAgICAgfSBlbHNlIGlmKGJhY2tncm91bmRfaW1hZ2UubWV0aG9kLm1hdGNoKC9cXC0/Z3JhZGllbnQkLykpIHtcbiAgICAgICAgaWYoYm91bmRzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBib3VuZHMgPSBfaHRtbDJjYW52YXMuVXRpbC5Cb3VuZHMoZWwpO1xuICAgICAgICB9XG4gICAgICAgIGxvYWRHcmFkaWVudEltYWdlKGJhY2tncm91bmRfaW1hZ2UudmFsdWUsIGJvdW5kcyk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBnZXRJbWFnZXMgKGVsKSB7XG4gICAgdmFyIGVsTm9kZVR5cGUgPSBmYWxzZTtcblxuICAgIC8vIEZpcmVmb3ggZmFpbHMgd2l0aCBwZXJtaXNzaW9uIGRlbmllZCBvbiBwYWdlcyB3aXRoIGlmcmFtZXNcbiAgICB0cnkge1xuICAgICAgVXRpbC5DaGlsZHJlbihlbCkuZm9yRWFjaChnZXRJbWFnZXMpO1xuICAgIH1cbiAgICBjYXRjaCggZSApIHt9XG5cbiAgICB0cnkge1xuICAgICAgZWxOb2RlVHlwZSA9IGVsLm5vZGVUeXBlO1xuICAgIH0gY2F0Y2ggKGV4KSB7XG4gICAgICBlbE5vZGVUeXBlID0gZmFsc2U7XG4gICAgICBVdGlsLmxvZyhcImh0bWwyY2FudmFzOiBmYWlsZWQgdG8gYWNjZXNzIHNvbWUgZWxlbWVudCdzIG5vZGVUeXBlIC0gRXhjZXB0aW9uOiBcIiArIGV4Lm1lc3NhZ2UpO1xuICAgIH1cblxuICAgIGlmIChlbE5vZGVUeXBlID09PSAxIHx8IGVsTm9kZVR5cGUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgbG9hZFBzZXVkb0VsZW1lbnRJbWFnZXMoZWwpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgbG9hZEJhY2tncm91bmRJbWFnZXMoVXRpbC5nZXRDU1MoZWwsICdiYWNrZ3JvdW5kSW1hZ2UnKSwgZWwpO1xuICAgICAgfSBjYXRjaChlKSB7XG4gICAgICAgIFV0aWwubG9nKFwiaHRtbDJjYW52YXM6IGZhaWxlZCB0byBnZXQgYmFja2dyb3VuZC1pbWFnZSAtIEV4Y2VwdGlvbjogXCIgKyBlLm1lc3NhZ2UpO1xuICAgICAgfVxuICAgICAgbG9hZEJhY2tncm91bmRJbWFnZXMoZWwpO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHNldEltYWdlTG9hZEhhbmRsZXJzKGltZywgaW1hZ2VPYmopIHtcbiAgICBpbWcub25sb2FkID0gZnVuY3Rpb24oKSB7XG4gICAgICBpZiAoIGltYWdlT2JqLnRpbWVyICE9PSB1bmRlZmluZWQgKSB7XG4gICAgICAgIC8vIENPUlMgc3VjY2VlZGVkXG4gICAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQoIGltYWdlT2JqLnRpbWVyICk7XG4gICAgICB9XG5cbiAgICAgIGltYWdlcy5udW1Mb2FkZWQrKztcbiAgICAgIGltYWdlT2JqLnN1Y2NlZWRlZCA9IHRydWU7XG4gICAgICBpbWcub25lcnJvciA9IGltZy5vbmxvYWQgPSBudWxsO1xuICAgICAgc3RhcnQoKTtcbiAgICB9O1xuICAgIGltZy5vbmVycm9yID0gZnVuY3Rpb24oKSB7XG4gICAgICBpZiAoaW1nLmNyb3NzT3JpZ2luID09PSBcImFub255bW91c1wiKSB7XG4gICAgICAgIC8vIENPUlMgZmFpbGVkXG4gICAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQoIGltYWdlT2JqLnRpbWVyICk7XG5cbiAgICAgICAgLy8gbGV0J3MgdHJ5IHdpdGggcHJveHkgaW5zdGVhZFxuICAgICAgICBpZiAoIG9wdGlvbnMucHJveHkgKSB7XG4gICAgICAgICAgdmFyIHNyYyA9IGltZy5zcmM7XG4gICAgICAgICAgaW1nID0gbmV3IEltYWdlKCk7XG4gICAgICAgICAgaW1hZ2VPYmouaW1nID0gaW1nO1xuICAgICAgICAgIGltZy5zcmMgPSBzcmM7XG5cbiAgICAgICAgICBwcm94eUdldEltYWdlKCBpbWcuc3JjLCBpbWcsIGltYWdlT2JqICk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGltYWdlcy5udW1Mb2FkZWQrKztcbiAgICAgIGltYWdlcy5udW1GYWlsZWQrKztcbiAgICAgIGltYWdlT2JqLnN1Y2NlZWRlZCA9IGZhbHNlO1xuICAgICAgaW1nLm9uZXJyb3IgPSBpbWcub25sb2FkID0gbnVsbDtcbiAgICAgIHN0YXJ0KCk7XG4gICAgfTtcbiAgfVxuXG4gIG1ldGhvZHMgPSB7XG4gICAgbG9hZEltYWdlOiBmdW5jdGlvbiggc3JjICkge1xuICAgICAgdmFyIGltZywgaW1hZ2VPYmo7XG4gICAgICBpZiAoIHNyYyAmJiBpbWFnZXNbc3JjXSA9PT0gdW5kZWZpbmVkICkge1xuICAgICAgICBpbWcgPSBuZXcgSW1hZ2UoKTtcbiAgICAgICAgaWYgKCBzcmMubWF0Y2goL2RhdGE6aW1hZ2VcXC8uKjtiYXNlNjQsL2kpICkge1xuICAgICAgICAgIGltZy5zcmMgPSBzcmMucmVwbGFjZSgvdXJsXFwoWydcIl17MCx9fFsnXCJdezAsfVxcKSQvaWcsICcnKTtcbiAgICAgICAgICBpbWFnZU9iaiA9IGltYWdlc1tzcmNdID0ge1xuICAgICAgICAgICAgaW1nOiBpbWdcbiAgICAgICAgICB9O1xuICAgICAgICAgIGltYWdlcy5udW1Ub3RhbCsrO1xuICAgICAgICAgIHNldEltYWdlTG9hZEhhbmRsZXJzKGltZywgaW1hZ2VPYmopO1xuICAgICAgICB9IGVsc2UgaWYgKCBpc1NhbWVPcmlnaW4oIHNyYyApIHx8IG9wdGlvbnMuYWxsb3dUYWludCA9PT0gIHRydWUgKSB7XG4gICAgICAgICAgaW1hZ2VPYmogPSBpbWFnZXNbc3JjXSA9IHtcbiAgICAgICAgICAgIGltZzogaW1nXG4gICAgICAgICAgfTtcbiAgICAgICAgICBpbWFnZXMubnVtVG90YWwrKztcbiAgICAgICAgICBzZXRJbWFnZUxvYWRIYW5kbGVycyhpbWcsIGltYWdlT2JqKTtcbiAgICAgICAgICBpbWcuc3JjID0gc3JjO1xuICAgICAgICB9IGVsc2UgaWYgKCBzdXBwb3J0Q09SUyAmJiAhb3B0aW9ucy5hbGxvd1RhaW50ICYmIG9wdGlvbnMudXNlQ09SUyApIHtcbiAgICAgICAgICAvLyBhdHRlbXB0IHRvIGxvYWQgd2l0aCBDT1JTXG5cbiAgICAgICAgICBpbWcuY3Jvc3NPcmlnaW4gPSBcImFub255bW91c1wiO1xuICAgICAgICAgIGltYWdlT2JqID0gaW1hZ2VzW3NyY10gPSB7XG4gICAgICAgICAgICBpbWc6IGltZ1xuICAgICAgICAgIH07XG4gICAgICAgICAgaW1hZ2VzLm51bVRvdGFsKys7XG4gICAgICAgICAgc2V0SW1hZ2VMb2FkSGFuZGxlcnMoaW1nLCBpbWFnZU9iaik7XG4gICAgICAgICAgaW1nLnNyYyA9IHNyYztcbiAgICAgICAgfSBlbHNlIGlmICggb3B0aW9ucy5wcm94eSApIHtcbiAgICAgICAgICBpbWFnZU9iaiA9IGltYWdlc1tzcmNdID0ge1xuICAgICAgICAgICAgaW1nOiBpbWdcbiAgICAgICAgICB9O1xuICAgICAgICAgIGltYWdlcy5udW1Ub3RhbCsrO1xuICAgICAgICAgIHByb3h5R2V0SW1hZ2UoIHNyYywgaW1nLCBpbWFnZU9iaiApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICB9LFxuICAgIGNsZWFudXBET006IGZ1bmN0aW9uKGNhdXNlKSB7XG4gICAgICB2YXIgaW1nLCBzcmM7XG4gICAgICBpZiAoIWltYWdlcy5jbGVhbnVwRG9uZSkge1xuICAgICAgICBpZiAoY2F1c2UgJiYgdHlwZW9mIGNhdXNlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgVXRpbC5sb2coXCJodG1sMmNhbnZhczogQ2xlYW51cCBiZWNhdXNlOiBcIiArIGNhdXNlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBVdGlsLmxvZyhcImh0bWwyY2FudmFzOiBDbGVhbnVwIGFmdGVyIHRpbWVvdXQ6IFwiICsgb3B0aW9ucy50aW1lb3V0ICsgXCIgbXMuXCIpO1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yIChzcmMgaW4gaW1hZ2VzKSB7XG4gICAgICAgICAgaWYgKGltYWdlcy5oYXNPd25Qcm9wZXJ0eShzcmMpKSB7XG4gICAgICAgICAgICBpbWcgPSBpbWFnZXNbc3JjXTtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaW1nID09PSBcIm9iamVjdFwiICYmIGltZy5jYWxsYmFja25hbWUgJiYgaW1nLnN1Y2NlZWRlZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgIC8vIGNhbmNlbCBwcm94eSBpbWFnZSByZXF1ZXN0XG4gICAgICAgICAgICAgIHdpbmRvd1tpbWcuY2FsbGJhY2tuYW1lXSA9IHVuZGVmaW5lZDsgLy8gdG8gd29yayB3aXRoIElFPDkgIC8vIE5PVEU6IHRoYXQgdGhlIHVuZGVmaW5lZCBjYWxsYmFjayBwcm9wZXJ0eS1uYW1lIHN0aWxsIGV4aXN0cyBvbiB0aGUgd2luZG93IG9iamVjdCAoZm9yIElFPDkpXG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgZGVsZXRlIHdpbmRvd1tpbWcuY2FsbGJhY2tuYW1lXTsgIC8vIGZvciBhbGwgYnJvd3NlciB0aGF0IHN1cHBvcnQgdGhpc1xuICAgICAgICAgICAgICB9IGNhdGNoKGV4KSB7fVxuICAgICAgICAgICAgICBpZiAoaW1nLnNjcmlwdCAmJiBpbWcuc2NyaXB0LnBhcmVudE5vZGUpIHtcbiAgICAgICAgICAgICAgICBpbWcuc2NyaXB0LnNldEF0dHJpYnV0ZShcInNyY1wiLCBcImFib3V0OmJsYW5rXCIpOyAgLy8gdHJ5IHRvIGNhbmNlbCBydW5uaW5nIHJlcXVlc3RcbiAgICAgICAgICAgICAgICBpbWcuc2NyaXB0LnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoaW1nLnNjcmlwdCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaW1hZ2VzLm51bUxvYWRlZCsrO1xuICAgICAgICAgICAgICBpbWFnZXMubnVtRmFpbGVkKys7XG4gICAgICAgICAgICAgIFV0aWwubG9nKFwiaHRtbDJjYW52YXM6IENsZWFuZWQgdXAgZmFpbGVkIGltZzogJ1wiICsgc3JjICsgXCInIFN0ZXBzOiBcIiArIGltYWdlcy5udW1Mb2FkZWQgKyBcIiAvIFwiICsgaW1hZ2VzLm51bVRvdGFsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBjYW5jZWwgYW55IHBlbmRpbmcgcmVxdWVzdHNcbiAgICAgICAgaWYod2luZG93LnN0b3AgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIHdpbmRvdy5zdG9wKCk7XG4gICAgICAgIH0gZWxzZSBpZihkb2N1bWVudC5leGVjQ29tbWFuZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJTdG9wXCIsIGZhbHNlKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZG9jdW1lbnQuY2xvc2UgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIGRvY3VtZW50LmNsb3NlKCk7XG4gICAgICAgIH1cbiAgICAgICAgaW1hZ2VzLmNsZWFudXBEb25lID0gdHJ1ZTtcbiAgICAgICAgaWYgKCEoY2F1c2UgJiYgdHlwZW9mIGNhdXNlID09PSBcInN0cmluZ1wiKSkge1xuICAgICAgICAgIHN0YXJ0KCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuXG4gICAgcmVuZGVyaW5nRG9uZTogZnVuY3Rpb24oKSB7XG4gICAgICBpZiAodGltZW91dFRpbWVyKSB7XG4gICAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQodGltZW91dFRpbWVyKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgaWYgKG9wdGlvbnMudGltZW91dCA+IDApIHtcbiAgICB0aW1lb3V0VGltZXIgPSB3aW5kb3cuc2V0VGltZW91dChtZXRob2RzLmNsZWFudXBET00sIG9wdGlvbnMudGltZW91dCk7XG4gIH1cblxuICBVdGlsLmxvZygnaHRtbDJjYW52YXM6IFByZWxvYWQgc3RhcnRzOiBmaW5kaW5nIGJhY2tncm91bmQtaW1hZ2VzJyk7XG4gIGltYWdlcy5maXJzdFJ1biA9IHRydWU7XG5cbiAgZ2V0SW1hZ2VzKGVsZW1lbnQpO1xuXG4gIFV0aWwubG9nKCdodG1sMmNhbnZhczogUHJlbG9hZDogRmluZGluZyBpbWFnZXMnKTtcbiAgLy8gbG9hZCA8aW1nPiBpbWFnZXNcbiAgZm9yIChpID0gMDsgaSA8IGltZ0xlbjsgaSs9MSl7XG4gICAgbWV0aG9kcy5sb2FkSW1hZ2UoIGRvbUltYWdlc1tpXS5nZXRBdHRyaWJ1dGUoIFwic3JjXCIgKSApO1xuICB9XG5cbiAgaW1hZ2VzLmZpcnN0UnVuID0gZmFsc2U7XG4gIFV0aWwubG9nKCdodG1sMmNhbnZhczogUHJlbG9hZDogRG9uZS4nKTtcbiAgaWYgKGltYWdlcy5udW1Ub3RhbCA9PT0gaW1hZ2VzLm51bUxvYWRlZCkge1xuICAgIHN0YXJ0KCk7XG4gIH1cblxuICByZXR1cm4gbWV0aG9kcztcbn07XG5cbl9odG1sMmNhbnZhcy5SZW5kZXJlciA9IGZ1bmN0aW9uKHBhcnNlUXVldWUsIG9wdGlvbnMpe1xuICBmdW5jdGlvbiBzb3J0WmluZGV4KGEsIGIpIHtcbiAgICBpZiAoYSA9PT0gJ2NoaWxkcmVuJykge1xuICAgICAgcmV0dXJuIC0xO1xuICAgIH0gZWxzZSBpZiAoYiA9PT0gJ2NoaWxkcmVuJykge1xuICAgICAgcmV0dXJuIDE7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBhIC0gYjtcbiAgICB9XG4gIH1cblxuICAvLyBodHRwOi8vd3d3LnczLm9yZy9UUi9DU1MyMS96aW5kZXguaHRtbFxuICBmdW5jdGlvbiBjcmVhdGVSZW5kZXJRdWV1ZShwYXJzZVF1ZXVlKSB7XG4gICAgdmFyIHF1ZXVlID0gW10sXG4gICAgcm9vdENvbnRleHQ7XG5cbiAgICByb290Q29udGV4dCA9IChmdW5jdGlvbiBidWlsZFN0YWNraW5nQ29udGV4dChyb290Tm9kZSkge1xuICAgICAgdmFyIHJvb3RDb250ZXh0ID0ge307XG4gICAgICBmdW5jdGlvbiBpbnNlcnQoY29udGV4dCwgbm9kZSwgc3BlY2lhbFBhcmVudCkge1xuICAgICAgICB2YXIgemkgPSAobm9kZS56SW5kZXguemluZGV4ID09PSAnYXV0bycpID8gMCA6IE51bWJlcihub2RlLnpJbmRleC56aW5kZXgpLFxuICAgICAgICBjb250ZXh0Rm9yQ2hpbGRyZW4gPSBjb250ZXh0LCAvLyB0aGUgc3RhY2tpbmcgY29udGV4dCBmb3IgY2hpbGRyZW5cbiAgICAgICAgaXNQb3NpdGlvbmVkID0gbm9kZS56SW5kZXguaXNQb3NpdGlvbmVkLFxuICAgICAgICBpc0Zsb2F0ZWQgPSBub2RlLnpJbmRleC5pc0Zsb2F0ZWQsXG4gICAgICAgIHN0dWIgPSB7bm9kZTogbm9kZX0sXG4gICAgICAgIGNoaWxkcmVuRGVzdCA9IHNwZWNpYWxQYXJlbnQ7IC8vIHdoZXJlIGNoaWxkcmVuIHdpdGhvdXQgei1pbmRleCBzaG91bGQgYmUgcHVzaGVkIGludG9cblxuICAgICAgICBpZiAobm9kZS56SW5kZXgub3duU3RhY2tpbmcpIHtcbiAgICAgICAgICBjb250ZXh0Rm9yQ2hpbGRyZW4gPSBzdHViLmNvbnRleHQgPSB7XG4gICAgICAgICAgICAgIGNoaWxkcmVuOiBbe25vZGU6bm9kZSwgY2hpbGRyZW46IFtdfV1cbiAgICAgICAgICB9O1xuICAgICAgICAgIGNoaWxkcmVuRGVzdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgfSBlbHNlIGlmIChpc1Bvc2l0aW9uZWQgfHwgaXNGbG9hdGVkKSB7XG4gICAgICAgICAgY2hpbGRyZW5EZXN0ID0gc3R1Yi5jaGlsZHJlbiA9IFtdO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHppID09PSAwICYmIHNwZWNpYWxQYXJlbnQpIHtcbiAgICAgICAgICBzcGVjaWFsUGFyZW50LnB1c2goc3R1Yik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKCFjb250ZXh0W3ppXSkgeyBjb250ZXh0W3ppXSA9IFtdOyB9XG4gICAgICAgICAgY29udGV4dFt6aV0ucHVzaChzdHViKTtcbiAgICAgICAgfVxuXG4gICAgICAgIG5vZGUuekluZGV4LmNoaWxkcmVuLmZvckVhY2goZnVuY3Rpb24oY2hpbGROb2RlKSB7XG4gICAgICAgICAgaW5zZXJ0KGNvbnRleHRGb3JDaGlsZHJlbiwgY2hpbGROb2RlLCBjaGlsZHJlbkRlc3QpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGluc2VydChyb290Q29udGV4dCwgcm9vdE5vZGUpO1xuICAgICAgcmV0dXJuIHJvb3RDb250ZXh0O1xuICAgIH0pKHBhcnNlUXVldWUpO1xuXG4gICAgZnVuY3Rpb24gc29ydFooY29udGV4dCkge1xuICAgICAgT2JqZWN0LmtleXMoY29udGV4dCkuc29ydChzb3J0WmluZGV4KS5mb3JFYWNoKGZ1bmN0aW9uKHppKSB7XG4gICAgICAgIHZhciBub25Qb3NpdGlvbmVkID0gW10sXG4gICAgICAgIGZsb2F0ZWQgPSBbXSxcbiAgICAgICAgcG9zaXRpb25lZCA9IFtdLFxuICAgICAgICBsaXN0ID0gW107XG5cbiAgICAgICAgLy8gcG9zaXRpb25lZCBhZnRlciBzdGF0aWNcbiAgICAgICAgY29udGV4dFt6aV0uZm9yRWFjaChmdW5jdGlvbih2KSB7XG4gICAgICAgICAgaWYgKHYubm9kZS56SW5kZXguaXNQb3NpdGlvbmVkIHx8IHYubm9kZS56SW5kZXgub3BhY2l0eSA8IDEpIHtcbiAgICAgICAgICAgIC8vIGh0dHA6Ly93d3cudzMub3JnL1RSL2NzczMtY29sb3IvI3RyYW5zcGFyZW5jeVxuICAgICAgICAgICAgLy8gbm9uLXBvc2l0aW9uZWQgZWxlbWVudCB3aXRoIG9wYWN0aXkgPCAxIHNob3VsZCBiZSBzdGFja2VkIGFzIGlmIGl0IHdlcmUgYSBwb3NpdGlvbmVkIGVsZW1lbnQgd2l0aCDigJh6LWluZGV4OiAw4oCZIGFuZCDigJhvcGFjaXR5OiAx4oCZLlxuICAgICAgICAgICAgcG9zaXRpb25lZC5wdXNoKHYpO1xuICAgICAgICAgIH0gZWxzZSBpZiAodi5ub2RlLnpJbmRleC5pc0Zsb2F0ZWQpIHtcbiAgICAgICAgICAgIGZsb2F0ZWQucHVzaCh2KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbm9uUG9zaXRpb25lZC5wdXNoKHYpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgKGZ1bmN0aW9uIHdhbGsoYXJyKSB7XG4gICAgICAgICAgYXJyLmZvckVhY2goZnVuY3Rpb24odikge1xuICAgICAgICAgICAgbGlzdC5wdXNoKHYpO1xuICAgICAgICAgICAgaWYgKHYuY2hpbGRyZW4pIHsgd2Fsayh2LmNoaWxkcmVuKTsgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9KShub25Qb3NpdGlvbmVkLmNvbmNhdChmbG9hdGVkLCBwb3NpdGlvbmVkKSk7XG5cbiAgICAgICAgbGlzdC5mb3JFYWNoKGZ1bmN0aW9uKHYpIHtcbiAgICAgICAgICBpZiAodi5jb250ZXh0KSB7XG4gICAgICAgICAgICBzb3J0Wih2LmNvbnRleHQpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBxdWV1ZS5wdXNoKHYubm9kZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHNvcnRaKHJvb3RDb250ZXh0KTtcblxuICAgIHJldHVybiBxdWV1ZTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGdldFJlbmRlcmVyKHJlbmRlcmVyTmFtZSkge1xuICAgIHZhciByZW5kZXJlcjtcblxuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5yZW5kZXJlciA9PT0gXCJzdHJpbmdcIiAmJiBfaHRtbDJjYW52YXMuUmVuZGVyZXJbcmVuZGVyZXJOYW1lXSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICByZW5kZXJlciA9IF9odG1sMmNhbnZhcy5SZW5kZXJlcltyZW5kZXJlck5hbWVdKG9wdGlvbnMpO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHJlbmRlcmVyTmFtZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICByZW5kZXJlciA9IHJlbmRlcmVyTmFtZShvcHRpb25zKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5rbm93biByZW5kZXJlclwiKTtcbiAgICB9XG5cbiAgICBpZiAoIHR5cGVvZiByZW5kZXJlciAhPT0gXCJmdW5jdGlvblwiICkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCByZW5kZXJlciBkZWZpbmVkXCIpO1xuICAgIH1cbiAgICByZXR1cm4gcmVuZGVyZXI7XG4gIH1cblxuICByZXR1cm4gZ2V0UmVuZGVyZXIob3B0aW9ucy5yZW5kZXJlcikocGFyc2VRdWV1ZSwgb3B0aW9ucywgZG9jdW1lbnQsIGNyZWF0ZVJlbmRlclF1ZXVlKHBhcnNlUXVldWUuc3RhY2spLCBfaHRtbDJjYW52YXMpO1xufTtcblxuX2h0bWwyY2FudmFzLlV0aWwuU3VwcG9ydCA9IGZ1bmN0aW9uIChvcHRpb25zLCBkb2MpIHtcblxuICBmdW5jdGlvbiBzdXBwb3J0U1ZHUmVuZGVyaW5nKCkge1xuICAgIHZhciBpbWcgPSBuZXcgSW1hZ2UoKSxcbiAgICBjYW52YXMgPSBkb2MuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKSxcbiAgICBjdHggPSAoY2FudmFzLmdldENvbnRleHQgPT09IHVuZGVmaW5lZCkgPyBmYWxzZSA6IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XG4gICAgaWYgKGN0eCA9PT0gZmFsc2UpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgY2FudmFzLndpZHRoID0gY2FudmFzLmhlaWdodCA9IDEwO1xuICAgIGltZy5zcmMgPSBbXG4gICAgXCJkYXRhOmltYWdlL3N2Zyt4bWwsXCIsXG4gICAgXCI8c3ZnIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Zycgd2lkdGg9JzEwJyBoZWlnaHQ9JzEwJz5cIixcbiAgICBcIjxmb3JlaWduT2JqZWN0IHdpZHRoPScxMCcgaGVpZ2h0PScxMCc+XCIsXG4gICAgXCI8ZGl2IHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hodG1sJyBzdHlsZT0nd2lkdGg6MTA7aGVpZ2h0OjEwOyc+XCIsXG4gICAgXCJzdXBcIixcbiAgICBcIjwvZGl2PlwiLFxuICAgIFwiPC9mb3JlaWduT2JqZWN0PlwiLFxuICAgIFwiPC9zdmc+XCJcbiAgICBdLmpvaW4oXCJcIik7XG4gICAgdHJ5IHtcbiAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwKTtcbiAgICAgIGNhbnZhcy50b0RhdGFVUkwoKTtcbiAgICB9IGNhdGNoKGUpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgX2h0bWwyY2FudmFzLlV0aWwubG9nKCdodG1sMmNhbnZhczogUGFyc2U6IFNWRyBwb3dlcmVkIHJlbmRlcmluZyBhdmFpbGFibGUnKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIC8vIFRlc3Qgd2hldGhlciB3ZSBjYW4gdXNlIHJhbmdlcyB0byBtZWFzdXJlIGJvdW5kaW5nIGJveGVzXG4gIC8vIE9wZXJhIGRvZXNuJ3QgcHJvdmlkZSB2YWxpZCBib3VuZHMuaGVpZ2h0L2JvdHRvbSBldmVuIHRob3VnaCBpdCBzdXBwb3J0cyB0aGUgbWV0aG9kLlxuXG4gIGZ1bmN0aW9uIHN1cHBvcnRSYW5nZUJvdW5kcygpIHtcbiAgICB2YXIgciwgdGVzdEVsZW1lbnQsIHJhbmdlQm91bmRzLCByYW5nZUhlaWdodCwgc3VwcG9ydCA9IGZhbHNlO1xuXG4gICAgaWYgKGRvYy5jcmVhdGVSYW5nZSkge1xuICAgICAgciA9IGRvYy5jcmVhdGVSYW5nZSgpO1xuICAgICAgaWYgKHIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KSB7XG4gICAgICAgIHRlc3RFbGVtZW50ID0gZG9jLmNyZWF0ZUVsZW1lbnQoJ2JvdW5kdGVzdCcpO1xuICAgICAgICB0ZXN0RWxlbWVudC5zdHlsZS5oZWlnaHQgPSBcIjEyM3B4XCI7XG4gICAgICAgIHRlc3RFbGVtZW50LnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XG4gICAgICAgIGRvYy5ib2R5LmFwcGVuZENoaWxkKHRlc3RFbGVtZW50KTtcblxuICAgICAgICByLnNlbGVjdE5vZGUodGVzdEVsZW1lbnQpO1xuICAgICAgICByYW5nZUJvdW5kcyA9IHIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIHJhbmdlSGVpZ2h0ID0gcmFuZ2VCb3VuZHMuaGVpZ2h0O1xuXG4gICAgICAgIGlmIChyYW5nZUhlaWdodCA9PT0gMTIzKSB7XG4gICAgICAgICAgc3VwcG9ydCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZG9jLmJvZHkucmVtb3ZlQ2hpbGQodGVzdEVsZW1lbnQpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBzdXBwb3J0O1xuICB9XG5cbiAgcmV0dXJuIHtcbiAgICByYW5nZUJvdW5kczogc3VwcG9ydFJhbmdlQm91bmRzKCksXG4gICAgc3ZnUmVuZGVyaW5nOiBvcHRpb25zLnN2Z1JlbmRlcmluZyAmJiBzdXBwb3J0U1ZHUmVuZGVyaW5nKClcbiAgfTtcbn07XG53aW5kb3cuaHRtbDJjYW52YXMgPSBmdW5jdGlvbihlbGVtZW50cywgb3B0cykge1xuICBlbGVtZW50cyA9IChlbGVtZW50cy5sZW5ndGgpID8gZWxlbWVudHMgOiBbZWxlbWVudHNdO1xuICB2YXIgcXVldWUsXG4gIGNhbnZhcyxcbiAgb3B0aW9ucyA9IHtcbiAgICAvLyBnZW5lcmFsXG4gICAgbG9nZ2luZzogZmFsc2UsXG4gICAgZWxlbWVudHM6IGVsZW1lbnRzLFxuICAgIGJhY2tncm91bmQ6IFwiI2ZmZlwiLFxuXG4gICAgLy8gcHJlbG9hZCBvcHRpb25zXG4gICAgcHJveHk6IG51bGwsXG4gICAgdGltZW91dDogMCwgICAgLy8gbm8gdGltZW91dFxuICAgIHVzZUNPUlM6IGZhbHNlLCAvLyB0cnkgdG8gbG9hZCBpbWFnZXMgYXMgQ09SUyAod2hlcmUgYXZhaWxhYmxlKSwgYmVmb3JlIGZhbGxpbmcgYmFjayB0byBwcm94eVxuICAgIGFsbG93VGFpbnQ6IGZhbHNlLCAvLyB3aGV0aGVyIHRvIGFsbG93IGltYWdlcyB0byB0YWludCB0aGUgY2FudmFzLCB3b24ndCBuZWVkIHByb3h5IGlmIHNldCB0byB0cnVlXG5cbiAgICAvLyBwYXJzZSBvcHRpb25zXG4gICAgc3ZnUmVuZGVyaW5nOiBmYWxzZSwgLy8gdXNlIHN2ZyBwb3dlcmVkIHJlbmRlcmluZyB3aGVyZSBhdmFpbGFibGUgKEZGMTErKVxuICAgIGlnbm9yZUVsZW1lbnRzOiBcIklGUkFNRXxPQkpFQ1R8UEFSQU1cIixcbiAgICB1c2VPdmVyZmxvdzogdHJ1ZSxcbiAgICBsZXR0ZXJSZW5kZXJpbmc6IGZhbHNlLFxuICAgIGNoaW5lc2U6IGZhbHNlLFxuICAgIGFzeW5jOiBmYWxzZSwgLy8gSWYgdHJ1ZSwgcGFyc2luZyB3aWxsIG5vdCBibG9jaywgYnV0IGlmIHRoZSB1c2VyIHNjcm9sbHMgZHVyaW5nIHBhcnNlIHRoZSBpbWFnZSBjYW4gZ2V0IHdlaXJkXG5cbiAgICAvLyByZW5kZXIgb3B0aW9uc1xuICAgIHdpZHRoOiBudWxsLFxuICAgIGhlaWdodDogbnVsbCxcbiAgICB0YWludFRlc3Q6IHRydWUsIC8vIGRvIGEgdGFpbnQgdGVzdCB3aXRoIGFsbCBpbWFnZXMgYmVmb3JlIGFwcGx5aW5nIHRvIGNhbnZhc1xuICAgIHJlbmRlcmVyOiBcIkNhbnZhc1wiXG4gIH07XG5cbiAgb3B0aW9ucyA9IF9odG1sMmNhbnZhcy5VdGlsLkV4dGVuZChvcHRzLCBvcHRpb25zKTtcblxuICBfaHRtbDJjYW52YXMubG9nZ2luZyA9IG9wdGlvbnMubG9nZ2luZztcbiAgb3B0aW9ucy5jb21wbGV0ZSA9IGZ1bmN0aW9uKCBpbWFnZXMgKSB7XG5cbiAgICBpZiAodHlwZW9mIG9wdGlvbnMub25wcmVsb2FkZWQgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgaWYgKCBvcHRpb25zLm9ucHJlbG9hZGVkKCBpbWFnZXMgKSA9PT0gZmFsc2UgKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG4gICAgX2h0bWwyY2FudmFzLlBhcnNlKCBpbWFnZXMsIG9wdGlvbnMsIGZ1bmN0aW9uKHF1ZXVlKSB7XG4gICAgICBpZiAodHlwZW9mIG9wdGlvbnMub25wYXJzZWQgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICBpZiAoIG9wdGlvbnMub25wYXJzZWQoIHF1ZXVlICkgPT09IGZhbHNlICkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjYW52YXMgPSBfaHRtbDJjYW52YXMuUmVuZGVyZXIoIHF1ZXVlLCBvcHRpb25zICk7XG5cbiAgICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5vbnJlbmRlcmVkID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgb3B0aW9ucy5vbnJlbmRlcmVkKCBjYW52YXMgKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcblxuICAvLyBmb3IgcGFnZXMgd2l0aG91dCBpbWFnZXMsIHdlIHN0aWxsIHdhbnQgdGhpcyB0byBiZSBhc3luYywgaS5lLiByZXR1cm4gbWV0aG9kcyBiZWZvcmUgZXhlY3V0aW5nXG4gIHdpbmRvdy5zZXRUaW1lb3V0KCBmdW5jdGlvbigpe1xuICAgIF9odG1sMmNhbnZhcy5QcmVsb2FkKCBvcHRpb25zICk7XG4gIH0sIDAgKTtcblxuICByZXR1cm4ge1xuICAgIHJlbmRlcjogZnVuY3Rpb24oIHF1ZXVlLCBvcHRzICkge1xuICAgICAgcmV0dXJuIF9odG1sMmNhbnZhcy5SZW5kZXJlciggcXVldWUsIF9odG1sMmNhbnZhcy5VdGlsLkV4dGVuZChvcHRzLCBvcHRpb25zKSApO1xuICAgIH0sXG4gICAgcGFyc2U6IGZ1bmN0aW9uKCBpbWFnZXMsIG9wdHMgKSB7XG4gICAgICByZXR1cm4gX2h0bWwyY2FudmFzLlBhcnNlKCBpbWFnZXMsIF9odG1sMmNhbnZhcy5VdGlsLkV4dGVuZChvcHRzLCBvcHRpb25zKSApO1xuICAgIH0sXG4gICAgcHJlbG9hZDogZnVuY3Rpb24oIG9wdHMgKSB7XG4gICAgICByZXR1cm4gX2h0bWwyY2FudmFzLlByZWxvYWQoIF9odG1sMmNhbnZhcy5VdGlsLkV4dGVuZChvcHRzLCBvcHRpb25zKSApO1xuICAgIH0sXG4gICAgbG9nOiBfaHRtbDJjYW52YXMuVXRpbC5sb2dcbiAgfTtcbn07XG5cbndpbmRvdy5odG1sMmNhbnZhcy5sb2cgPSBfaHRtbDJjYW52YXMuVXRpbC5sb2c7IC8vIGZvciByZW5kZXJlcnNcbndpbmRvdy5odG1sMmNhbnZhcy5SZW5kZXJlciA9IHtcbiAgQ2FudmFzOiB1bmRlZmluZWQgLy8gV2UgYXJlIGFzc3VtaW5nIHRoaXMgd2lsbCBiZSB1c2VkXG59O1xuX2h0bWwyY2FudmFzLlJlbmRlcmVyLkNhbnZhcyA9IGZ1bmN0aW9uKG9wdGlvbnMpIHtcbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG5cbiAgdmFyIGRvYyA9IGRvY3VtZW50LFxuICBzYWZlSW1hZ2VzID0gW10sXG4gIHRlc3RDYW52YXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiY2FudmFzXCIpLFxuICB0ZXN0Y3R4ID0gdGVzdENhbnZhcy5nZXRDb250ZXh0KFwiMmRcIiksXG4gIFV0aWwgPSBfaHRtbDJjYW52YXMuVXRpbCxcbiAgY2FudmFzID0gb3B0aW9ucy5jYW52YXMgfHwgZG9jLmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuXG4gIGZ1bmN0aW9uIGNyZWF0ZVNoYXBlKGN0eCwgYXJncykge1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBhcmdzLmZvckVhY2goZnVuY3Rpb24oYXJnKSB7XG4gICAgICBjdHhbYXJnLm5hbWVdLmFwcGx5KGN0eCwgYXJnWydhcmd1bWVudHMnXSk7XG4gICAgfSk7XG4gICAgY3R4LmNsb3NlUGF0aCgpO1xuICB9XG5cbiAgZnVuY3Rpb24gc2FmZUltYWdlKGl0ZW0pIHtcbiAgICBpZiAoc2FmZUltYWdlcy5pbmRleE9mKGl0ZW1bJ2FyZ3VtZW50cyddWzBdLnNyYykgPT09IC0xKSB7XG4gICAgICB0ZXN0Y3R4LmRyYXdJbWFnZShpdGVtWydhcmd1bWVudHMnXVswXSwgMCwgMCk7XG4gICAgICB0cnkge1xuICAgICAgICB0ZXN0Y3R4LmdldEltYWdlRGF0YSgwLCAwLCAxLCAxKTtcbiAgICAgIH0gY2F0Y2goZSkge1xuICAgICAgICB0ZXN0Q2FudmFzID0gZG9jLmNyZWF0ZUVsZW1lbnQoXCJjYW52YXNcIik7XG4gICAgICAgIHRlc3RjdHggPSB0ZXN0Q2FudmFzLmdldENvbnRleHQoXCIyZFwiKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgc2FmZUltYWdlcy5wdXNoKGl0ZW1bJ2FyZ3VtZW50cyddWzBdLnNyYyk7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgZnVuY3Rpb24gcmVuZGVySXRlbShjdHgsIGl0ZW0pIHtcbiAgICBzd2l0Y2goaXRlbS50eXBlKXtcbiAgICAgIGNhc2UgXCJ2YXJpYWJsZVwiOlxuICAgICAgICBjdHhbaXRlbS5uYW1lXSA9IGl0ZW1bJ2FyZ3VtZW50cyddO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJmdW5jdGlvblwiOlxuICAgICAgICBzd2l0Y2goaXRlbS5uYW1lKSB7XG4gICAgICAgICAgY2FzZSBcImNyZWF0ZVBhdHRlcm5cIjpcbiAgICAgICAgICAgIGlmIChpdGVtWydhcmd1bWVudHMnXVswXS53aWR0aCA+IDAgJiYgaXRlbVsnYXJndW1lbnRzJ11bMF0uaGVpZ2h0ID4gMCkge1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGN0eC5maWxsU3R5bGUgPSBjdHguY3JlYXRlUGF0dGVybihpdGVtWydhcmd1bWVudHMnXVswXSwgXCJyZXBlYXRcIik7XG4gICAgICAgICAgICAgIH0gY2F0Y2goZSkge1xuICAgICAgICAgICAgICAgIFV0aWwubG9nKFwiaHRtbDJjYW52YXM6IFJlbmRlcmVyOiBFcnJvciBjcmVhdGluZyBwYXR0ZXJuXCIsIGUubWVzc2FnZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgXCJkcmF3U2hhcGVcIjpcbiAgICAgICAgICAgIGNyZWF0ZVNoYXBlKGN0eCwgaXRlbVsnYXJndW1lbnRzJ10pO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSBcImRyYXdJbWFnZVwiOlxuICAgICAgICAgICAgaWYgKGl0ZW1bJ2FyZ3VtZW50cyddWzhdID4gMCAmJiBpdGVtWydhcmd1bWVudHMnXVs3XSA+IDApIHtcbiAgICAgICAgICAgICAgaWYgKCFvcHRpb25zLnRhaW50VGVzdCB8fCAob3B0aW9ucy50YWludFRlc3QgJiYgc2FmZUltYWdlKGl0ZW0pKSkge1xuICAgICAgICAgICAgICAgIGN0eC5kcmF3SW1hZ2UuYXBwbHkoIGN0eCwgaXRlbVsnYXJndW1lbnRzJ10gKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIGN0eFtpdGVtLm5hbWVdLmFwcGx5KGN0eCwgaXRlbVsnYXJndW1lbnRzJ10pO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBmdW5jdGlvbihwYXJzZWREYXRhLCBvcHRpb25zLCBkb2N1bWVudCwgcXVldWUsIF9odG1sMmNhbnZhcykge1xuICAgIHZhciBjdHggPSBjYW52YXMuZ2V0Q29udGV4dChcIjJkXCIpLFxuICAgIG5ld0NhbnZhcyxcbiAgICBib3VuZHMsXG4gICAgZnN0eWxlLFxuICAgIHpTdGFjayA9IHBhcnNlZERhdGEuc3RhY2s7XG5cbiAgICBjYW52YXMud2lkdGggPSBjYW52YXMuc3R5bGUud2lkdGggPSAgb3B0aW9ucy53aWR0aCB8fCB6U3RhY2suY3R4LndpZHRoO1xuICAgIGNhbnZhcy5oZWlnaHQgPSBjYW52YXMuc3R5bGUuaGVpZ2h0ID0gb3B0aW9ucy5oZWlnaHQgfHwgelN0YWNrLmN0eC5oZWlnaHQ7XG5cbiAgICBmc3R5bGUgPSBjdHguZmlsbFN0eWxlO1xuICAgIGN0eC5maWxsU3R5bGUgPSAoVXRpbC5pc1RyYW5zcGFyZW50KHBhcnNlZERhdGEuYmFja2dyb3VuZENvbG9yKSAmJiBvcHRpb25zLmJhY2tncm91bmQgIT09IHVuZGVmaW5lZCkgPyBvcHRpb25zLmJhY2tncm91bmQgOiBwYXJzZWREYXRhLmJhY2tncm91bmRDb2xvcjtcbiAgICBjdHguZmlsbFJlY3QoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcbiAgICBjdHguZmlsbFN0eWxlID0gZnN0eWxlO1xuICAgIHF1ZXVlLmZvckVhY2goZnVuY3Rpb24oc3RvcmFnZUNvbnRleHQpIHtcbiAgICAgIC8vIHNldCBjb21tb24gc2V0dGluZ3MgZm9yIGNhbnZhc1xuICAgICAgY3R4LnRleHRCYXNlbGluZSA9IFwiYm90dG9tXCI7XG4gICAgICBjdHguc2F2ZSgpO1xuXG4gICAgICBpZiAoc3RvcmFnZUNvbnRleHQudHJhbnNmb3JtLm1hdHJpeCkge1xuICAgICAgICBjdHgudHJhbnNsYXRlKHN0b3JhZ2VDb250ZXh0LnRyYW5zZm9ybS5vcmlnaW5bMF0sIHN0b3JhZ2VDb250ZXh0LnRyYW5zZm9ybS5vcmlnaW5bMV0pO1xuICAgICAgICBjdHgudHJhbnNmb3JtLmFwcGx5KGN0eCwgc3RvcmFnZUNvbnRleHQudHJhbnNmb3JtLm1hdHJpeCk7XG4gICAgICAgIGN0eC50cmFuc2xhdGUoLXN0b3JhZ2VDb250ZXh0LnRyYW5zZm9ybS5vcmlnaW5bMF0sIC1zdG9yYWdlQ29udGV4dC50cmFuc2Zvcm0ub3JpZ2luWzFdKTtcbiAgICAgIH1cblxuICAgICAgaWYgKHN0b3JhZ2VDb250ZXh0LmNsaXApe1xuICAgICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICAgIGN0eC5yZWN0KHN0b3JhZ2VDb250ZXh0LmNsaXAubGVmdCwgc3RvcmFnZUNvbnRleHQuY2xpcC50b3AsIHN0b3JhZ2VDb250ZXh0LmNsaXAud2lkdGgsIHN0b3JhZ2VDb250ZXh0LmNsaXAuaGVpZ2h0KTtcbiAgICAgICAgY3R4LmNsaXAoKTtcbiAgICAgIH1cblxuICAgICAgaWYgKHN0b3JhZ2VDb250ZXh0LmN0eC5zdG9yYWdlKSB7XG4gICAgICAgIHN0b3JhZ2VDb250ZXh0LmN0eC5zdG9yYWdlLmZvckVhY2goZnVuY3Rpb24oaXRlbSkge1xuICAgICAgICAgIHJlbmRlckl0ZW0oY3R4LCBpdGVtKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgfSk7XG5cbiAgICBVdGlsLmxvZyhcImh0bWwyY2FudmFzOiBSZW5kZXJlcjogQ2FudmFzIHJlbmRlcmVyIGRvbmUgLSByZXR1cm5pbmcgY2FudmFzIG9ialwiKTtcblxuICAgIGlmIChvcHRpb25zLmVsZW1lbnRzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgaWYgKHR5cGVvZiBvcHRpb25zLmVsZW1lbnRzWzBdID09PSBcIm9iamVjdFwiICYmIG9wdGlvbnMuZWxlbWVudHNbMF0ubm9kZU5hbWUgIT09IFwiQk9EWVwiKSB7XG4gICAgICAgIC8vIGNyb3AgaW1hZ2UgdG8gdGhlIGJvdW5kcyBvZiBzZWxlY3RlZCAoc2luZ2xlKSBlbGVtZW50XG4gICAgICAgIGJvdW5kcyA9IF9odG1sMmNhbnZhcy5VdGlsLkJvdW5kcyhvcHRpb25zLmVsZW1lbnRzWzBdKTtcbiAgICAgICAgbmV3Q2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICAgIFxuXG5cdCAgICBuZXdDYW52YXMud2lkdGggPSBNYXRoLmNlaWwoYm91bmRzLndpZHRoKTtcbiAgICAgICAgbmV3Q2FudmFzLmhlaWdodCA9IE1hdGguY2VpbChib3VuZHMuaGVpZ2h0KTtcbiAgIFxuXHQgIGN0eCA9IG5ld0NhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XG4gICAgICBjdHguZHJhd0ltYWdlKGNhbnZhcywgYm91bmRzLmxlZnQsIGJvdW5kcy50b3AsIGJvdW5kcy53aWR0aCwgYm91bmRzLmhlaWdodCwgMCwgMCwgYm91bmRzLndpZHRoLCBib3VuZHMuaGVpZ2h0KTtcblxuXHRcdFxuXHRcdFxuXHRcdGNhbnZhcyA9IG51bGw7XG4gICAgICAgIHJldHVybiBuZXdDYW52YXM7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGNhbnZhcztcbiAgfTtcbn07XG59KSh3aW5kb3csZG9jdW1lbnQpO1xuIiwiLypqc2xpbnQgYWRzYWZlOiBmYWxzZSwgYml0d2lzZTogdHJ1ZSwgYnJvd3NlcjogdHJ1ZSwgY2FwOiBmYWxzZSwgY3NzOiBmYWxzZSxcbiAgZGVidWc6IGZhbHNlLCBkZXZlbDogdHJ1ZSwgZXFlcWVxOiB0cnVlLCBlczU6IGZhbHNlLCBldmlsOiBmYWxzZSxcbiAgZm9yaW46IGZhbHNlLCBmcmFnbWVudDogZmFsc2UsIGltbWVkOiB0cnVlLCBsYXhicmVhazogZmFsc2UsIG5ld2NhcDogdHJ1ZSxcbiAgbm9tZW46IGZhbHNlLCBvbjogZmFsc2UsIG9uZXZhcjogdHJ1ZSwgcGFzc2ZhaWw6IGZhbHNlLCBwbHVzcGx1czogdHJ1ZSxcbiAgcmVnZXhwOiBmYWxzZSwgcmhpbm86IHRydWUsIHNhZmU6IGZhbHNlLCBzdHJpY3Q6IGZhbHNlLCBzdWI6IGZhbHNlLFxuICB1bmRlZjogdHJ1ZSwgd2hpdGU6IGZhbHNlLCB3aWRnZXQ6IGZhbHNlLCB3aW5kb3dzOiBmYWxzZSAqL1xuLypnbG9iYWwgalF1ZXJ5OiBmYWxzZSwgd2luZG93OiBmYWxzZSAqL1xuLy9cInVzZSBzdHJpY3RcIjtcblxuLypcbiAqIE9yaWdpbmFsIGNvZGUgKGMpIDIwMTAgTmljayBHYWxicmVhdGhcbiAqIGh0dHA6Ly9jb2RlLmdvb2dsZS5jb20vcC9zdHJpbmdlbmNvZGVycy9zb3VyY2UvYnJvd3NlLyNzdm4vdHJ1bmsvamF2YXNjcmlwdFxuICpcbiAqIGpRdWVyeSBwb3J0IChjKSAyMDEwIENhcmxvIFpvdHRtYW5uXG4gKiBodHRwOi8vZ2l0aHViLmNvbS9jYXJsby9qcXVlcnktYmFzZTY0XG4gKlxuICogUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb25cbiAqIG9idGFpbmluZyBhIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uXG4gKiBmaWxlcyAodGhlIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXRcbiAqIHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLFxuICogY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCwgZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGxcbiAqIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZVxuICogU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZSBmb2xsb3dpbmdcbiAqIGNvbmRpdGlvbnM6XG4gKlxuICogVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmVcbiAqIGluY2x1ZGVkIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuICpcbiAqIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsXG4gKiBFWFBSRVNTIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVNcbiAqIE9GIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EXG4gKiBOT05JTkZSSU5HRU1FTlQuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVFxuICogSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksXG4gKiBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUiBPVEhFUldJU0UsIEFSSVNJTkdcbiAqIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRSBVU0UgT1JcbiAqIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbiovXG5cbi8qIGJhc2U2NCBlbmNvZGUvZGVjb2RlIGNvbXBhdGlibGUgd2l0aCB3aW5kb3cuYnRvYS9hdG9iXG4gKlxuICogd2luZG93LmF0b2IvYnRvYSBpcyBhIEZpcmVmb3ggZXh0ZW5zaW9uIHRvIGNvbnZlcnQgYmluYXJ5IGRhdGEgKHRoZSBcImJcIilcbiAqIHRvIGJhc2U2NCAoYXNjaWksIHRoZSBcImFcIikuXG4gKlxuICogSXQgaXMgYWxzbyBmb3VuZCBpbiBTYWZhcmkgYW5kIENocm9tZS4gIEl0IGlzIG5vdCBhdmFpbGFibGUgaW4gSUUuXG4gKlxuICogaWYgKCF3aW5kb3cuYnRvYSkgd2luZG93LmJ0b2EgPSAkLmJhc2U2NC5lbmNvZGVcbiAqIGlmICghd2luZG93LmF0b2IpIHdpbmRvdy5hdG9iID0gJC5iYXNlNjQuZGVjb2RlXG4gKlxuICogVGhlIG9yaWdpbmFsIHNwZWMncyBmb3IgYXRvYi9idG9hIGFyZSBhIGJpdCBsYWNraW5nXG4gKiBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi9ET00vd2luZG93LmF0b2JcbiAqIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuL0RPTS93aW5kb3cuYnRvYVxuICpcbiAqIHdpbmRvdy5idG9hIGFuZCAkLmJhc2U2NC5lbmNvZGUgdGFrZXMgYSBzdHJpbmcgd2hlcmUgY2hhckNvZGVBdCBpcyBbMCwyNTVdXG4gKiBJZiBhbnkgY2hhcmFjdGVyIGlzIG5vdCBbMCwyNTVdLCB0aGVuIGFuIGV4Y2VwdGlvbiBpcyB0aHJvd24uXG4gKlxuICogd2luZG93LmF0b2IgYW5kICQuYmFzZTY0LmRlY29kZSB0YWtlIGEgYmFzZTY0LWVuY29kZWQgc3RyaW5nXG4gKiBJZiB0aGUgaW5wdXQgbGVuZ3RoIGlzIG5vdCBhIG11bHRpcGxlIG9mIDQsIG9yIGNvbnRhaW5zIGludmFsaWQgY2hhcmFjdGVyc1xuICogICB0aGVuIGFuIGV4Y2VwdGlvbiBpcyB0aHJvd24uXG4gKi9cbiBcbmpRdWVyeS5iYXNlNjQgPSAoIGZ1bmN0aW9uKCAkICkge1xuICBcbiAgdmFyIF9QQURDSEFSID0gXCI9XCIsXG4gICAgX0FMUEhBID0gXCJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvXCIsXG4gICAgX1ZFUlNJT04gPSBcIjEuMFwiO1xuXG5cbiAgZnVuY3Rpb24gX2dldGJ5dGU2NCggcywgaSApIHtcbiAgICAvLyBUaGlzIGlzIG9kZGx5IGZhc3QsIGV4Y2VwdCBvbiBDaHJvbWUvVjguXG4gICAgLy8gTWluaW1hbCBvciBubyBpbXByb3ZlbWVudCBpbiBwZXJmb3JtYW5jZSBieSB1c2luZyBhXG4gICAgLy8gb2JqZWN0IHdpdGggcHJvcGVydGllcyBtYXBwaW5nIGNoYXJzIHRvIHZhbHVlIChlZy4gJ0EnOiAwKVxuXG4gICAgdmFyIGlkeCA9IF9BTFBIQS5pbmRleE9mKCBzLmNoYXJBdCggaSApICk7XG5cbiAgICBpZiAoIGlkeCA9PT0gLTEgKSB7XG4gICAgICB0aHJvdyBcIkNhbm5vdCBkZWNvZGUgYmFzZTY0XCI7XG4gICAgfVxuXG4gICAgcmV0dXJuIGlkeDtcbiAgfVxuICBcbiAgXG4gIGZ1bmN0aW9uIF9kZWNvZGUoIHMgKSB7XG4gICAgdmFyIHBhZHMgPSAwLFxuICAgICAgaSxcbiAgICAgIGIxMCxcbiAgICAgIGltYXggPSBzLmxlbmd0aCxcbiAgICAgIHggPSBbXTtcblxuICAgIHMgPSBTdHJpbmcoIHMgKTtcbiAgICBcbiAgICBpZiAoIGltYXggPT09IDAgKSB7XG4gICAgICByZXR1cm4gcztcbiAgICB9XG5cbiAgICBpZiAoIGltYXggJSA0ICE9PSAwICkge1xuICAgICAgdGhyb3cgXCJDYW5ub3QgZGVjb2RlIGJhc2U2NFwiO1xuICAgIH1cblxuICAgIGlmICggcy5jaGFyQXQoIGltYXggLSAxICkgPT09IF9QQURDSEFSICkge1xuICAgICAgcGFkcyA9IDE7XG5cbiAgICAgIGlmICggcy5jaGFyQXQoIGltYXggLSAyICkgPT09IF9QQURDSEFSICkge1xuICAgICAgICBwYWRzID0gMjtcbiAgICAgIH1cblxuICAgICAgLy8gZWl0aGVyIHdheSwgd2Ugd2FudCB0byBpZ25vcmUgdGhpcyBsYXN0IGJsb2NrXG4gICAgICBpbWF4IC09IDQ7XG4gICAgfVxuXG4gICAgZm9yICggaSA9IDA7IGkgPCBpbWF4OyBpICs9IDQgKSB7XG4gICAgICBiMTAgPSAoIF9nZXRieXRlNjQoIHMsIGkgKSA8PCAxOCApIHwgKCBfZ2V0Ynl0ZTY0KCBzLCBpICsgMSApIDw8IDEyICkgfCAoIF9nZXRieXRlNjQoIHMsIGkgKyAyICkgPDwgNiApIHwgX2dldGJ5dGU2NCggcywgaSArIDMgKTtcbiAgICAgIHgucHVzaCggU3RyaW5nLmZyb21DaGFyQ29kZSggYjEwID4+IDE2LCAoIGIxMCA+PiA4ICkgJiAweGZmLCBiMTAgJiAweGZmICkgKTtcbiAgICB9XG5cbiAgICBzd2l0Y2ggKCBwYWRzICkge1xuICAgICAgY2FzZSAxOlxuICAgICAgICBiMTAgPSAoIF9nZXRieXRlNjQoIHMsIGkgKSA8PCAxOCApIHwgKCBfZ2V0Ynl0ZTY0KCBzLCBpICsgMSApIDw8IDEyICkgfCAoIF9nZXRieXRlNjQoIHMsIGkgKyAyICkgPDwgNiApO1xuICAgICAgICB4LnB1c2goIFN0cmluZy5mcm9tQ2hhckNvZGUoIGIxMCA+PiAxNiwgKCBiMTAgPj4gOCApICYgMHhmZiApICk7XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlIDI6XG4gICAgICAgIGIxMCA9ICggX2dldGJ5dGU2NCggcywgaSApIDw8IDE4KSB8ICggX2dldGJ5dGU2NCggcywgaSArIDEgKSA8PCAxMiApO1xuICAgICAgICB4LnB1c2goIFN0cmluZy5mcm9tQ2hhckNvZGUoIGIxMCA+PiAxNiApICk7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIHJldHVybiB4LmpvaW4oIFwiXCIgKTtcbiAgfVxuICBcbiAgXG4gIGZ1bmN0aW9uIF9nZXRieXRlKCBzLCBpICkge1xuICAgIHZhciB4ID0gcy5jaGFyQ29kZUF0KCBpICk7XG5cbiAgICBpZiAoIHggPiAyNTUgKSB7XG4gICAgICB0aHJvdyBcIklOVkFMSURfQ0hBUkFDVEVSX0VSUjogRE9NIEV4Y2VwdGlvbiA1XCI7XG4gICAgfVxuICAgIFxuICAgIHJldHVybiB4O1xuICB9XG5cblxuICBmdW5jdGlvbiBfZW5jb2RlKCBzICkge1xuICAgIGlmICggYXJndW1lbnRzLmxlbmd0aCAhPT0gMSApIHtcbiAgICAgIHRocm93IFwiU3ludGF4RXJyb3I6IGV4YWN0bHkgb25lIGFyZ3VtZW50IHJlcXVpcmVkXCI7XG4gICAgfVxuXG4gICAgcyA9IFN0cmluZyggcyApO1xuXG4gICAgdmFyIGksXG4gICAgICBiMTAsXG4gICAgICB4ID0gW10sXG4gICAgICBpbWF4ID0gcy5sZW5ndGggLSBzLmxlbmd0aCAlIDM7XG5cbiAgICBpZiAoIHMubGVuZ3RoID09PSAwICkge1xuICAgICAgcmV0dXJuIHM7XG4gICAgfVxuXG4gICAgZm9yICggaSA9IDA7IGkgPCBpbWF4OyBpICs9IDMgKSB7XG4gICAgICBiMTAgPSAoIF9nZXRieXRlKCBzLCBpICkgPDwgMTYgKSB8ICggX2dldGJ5dGUoIHMsIGkgKyAxICkgPDwgOCApIHwgX2dldGJ5dGUoIHMsIGkgKyAyICk7XG4gICAgICB4LnB1c2goIF9BTFBIQS5jaGFyQXQoIGIxMCA+PiAxOCApICk7XG4gICAgICB4LnB1c2goIF9BTFBIQS5jaGFyQXQoICggYjEwID4+IDEyICkgJiAweDNGICkgKTtcbiAgICAgIHgucHVzaCggX0FMUEhBLmNoYXJBdCggKCBiMTAgPj4gNiApICYgMHgzZiApICk7XG4gICAgICB4LnB1c2goIF9BTFBIQS5jaGFyQXQoIGIxMCAmIDB4M2YgKSApO1xuICAgIH1cblxuICAgIHN3aXRjaCAoIHMubGVuZ3RoIC0gaW1heCApIHtcbiAgICAgIGNhc2UgMTpcbiAgICAgICAgYjEwID0gX2dldGJ5dGUoIHMsIGkgKSA8PCAxNjtcbiAgICAgICAgeC5wdXNoKCBfQUxQSEEuY2hhckF0KCBiMTAgPj4gMTggKSArIF9BTFBIQS5jaGFyQXQoICggYjEwID4+IDEyICkgJiAweDNGICkgKyBfUEFEQ0hBUiArIF9QQURDSEFSICk7XG4gICAgICAgIGJyZWFrO1xuXG4gICAgICBjYXNlIDI6XG4gICAgICAgIGIxMCA9ICggX2dldGJ5dGUoIHMsIGkgKSA8PCAxNiApIHwgKCBfZ2V0Ynl0ZSggcywgaSArIDEgKSA8PCA4ICk7XG4gICAgICAgIHgucHVzaCggX0FMUEhBLmNoYXJBdCggYjEwID4+IDE4ICkgKyBfQUxQSEEuY2hhckF0KCAoIGIxMCA+PiAxMiApICYgMHgzRiApICsgX0FMUEhBLmNoYXJBdCggKCBiMTAgPj4gNiApICYgMHgzZiApICsgX1BBRENIQVIgKTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgcmV0dXJuIHguam9pbiggXCJcIiApO1xuICB9XG5cblxuICByZXR1cm4ge1xuICAgIGRlY29kZTogX2RlY29kZSxcbiAgICBlbmNvZGU6IF9lbmNvZGUsXG4gICAgVkVSU0lPTjogX1ZFUlNJT05cbiAgfTtcbiAgICAgIFxufSggalF1ZXJ5ICkgKTtcblxuIiwiLyoqXG4gKiBqc1BERlxuICogKGMpIDIwMDkgSmFtZXMgSGFsbFxuICogXG4gKiBTb21lIHBhcnRzIGJhc2VkIG9uIEZQREYuXG4gKi9cblxudmFyIGpzUERGID0gZnVuY3Rpb24oKXtcblx0XG5cdC8vIFByaXZhdGUgcHJvcGVydGllc1xuXHR2YXIgdmVyc2lvbiA9ICcyMDA5MDUwNCc7XG5cdHZhciBidWZmZXIgPSAnJztcblx0XG5cdHZhciBwZGZWZXJzaW9uID0gJzEuMyc7IC8vIFBERiBWZXJzaW9uXG5cdHZhciBkZWZhdWx0UGFnZUZvcm1hdCA9ICdhNCc7XG5cdHZhciBwYWdlRm9ybWF0cyA9IHsgLy8gU2l6ZSBpbiBtbSBvZiB2YXJpb3VzIHBhcGVyIGZvcm1hdHNcblx0XHQnYTMnOiBbODQxLjg5LCAxMTkwLjU1XSxcblx0XHQnYTQnOiBbNTk1LjI4LCA4NDEuODldLFxuXHRcdCdhNSc6IFs0MjAuOTQsIDU5NS4yOF0sXG5cdFx0J2xldHRlcic6IFs2MTIsIDc5Ml0sXG5cdFx0J2xlZ2FsJzogWzYxMiwgMTAwOF1cblx0fTtcblx0dmFyIHRleHRDb2xvciA9ICcwIGcnO1xuXHR2YXIgcGFnZSA9IDA7XG5cdHZhciBvYmplY3ROdW1iZXIgPSAyOyAvLyAnbicgQ3VycmVudCBvYmplY3QgbnVtYmVyXG5cdHZhciBzdGF0ZSA9IDA7IC8vIEN1cnJlbnQgZG9jdW1lbnQgc3RhdGVcblx0dmFyIHBhZ2VzID0gbmV3IEFycmF5KCk7XG5cdHZhciBvZmZzZXRzID0gbmV3IEFycmF5KCk7IC8vIExpc3Qgb2Ygb2Zmc2V0c1xuXHR2YXIgbGluZVdpZHRoID0gMC4yMDAwMjU7IC8vIDJtbVxuXHR2YXIgcGFnZUhlaWdodDtcblx0dmFyIGs7IC8vIFNjYWxlIGZhY3RvclxuXHR2YXIgdW5pdCA9ICdtbSc7IC8vIERlZmF1bHQgdG8gbW0gZm9yIHVuaXRzXG5cdHZhciBmb250TnVtYmVyOyAvLyBUT0RPOiBUaGlzIGlzIHRlbXAsIHJlcGxhY2Ugd2l0aCByZWFsIGZvbnQgaGFuZGxpbmdcblx0dmFyIGRvY3VtZW50UHJvcGVydGllcyA9IHt9O1xuXHR2YXIgZm9udFNpemUgPSAxNjsgLy8gRGVmYXVsdCBmb250IHNpemVcblx0dmFyIHBhZ2VGb250U2l6ZSA9IDE2O1xuXG5cdC8vIEluaXRpbGlzYXRpb24gXG5cdGlmICh1bml0ID09ICdwdCcpIHtcblx0XHRrID0gMTtcblx0fSBlbHNlIGlmKHVuaXQgPT0gJ21tJykge1xuXHRcdGsgPSA3Mi8yNS40O1xuXHR9IGVsc2UgaWYodW5pdCA9PSAnY20nKSB7XG5cdFx0ayA9IDcyLzIuNTQ7XG5cdH0gZWxzZSBpZih1bml0ID09ICdpbicpIHtcblx0XHRrID0gNzI7XG5cdH1cblx0XG5cdC8vIFByaXZhdGUgZnVuY3Rpb25zXG5cdHZhciBuZXdPYmplY3QgPSBmdW5jdGlvbigpIHtcblx0XHQvL0JlZ2luIGEgbmV3IG9iamVjdFxuXHRcdG9iamVjdE51bWJlciArKztcblx0XHRvZmZzZXRzW29iamVjdE51bWJlcl0gPSBidWZmZXIubGVuZ3RoO1xuXHRcdG91dChvYmplY3ROdW1iZXIgKyAnIDAgb2JqJyk7XHRcdFxuXHR9XG5cdFxuXHRcblx0dmFyIHB1dEhlYWRlciA9IGZ1bmN0aW9uKCkge1xuXHRcdG91dCgnJVBERi0nICsgcGRmVmVyc2lvbik7XG5cdH1cblx0XG5cdHZhciBwdXRQYWdlcyA9IGZ1bmN0aW9uKCkge1xuXHRcdFxuXHRcdC8vIFRPRE86IEZpeCwgaGFyZGNvZGVkIHRvIGE0IHBvcnRyYWl0XG5cdFx0dmFyIHdQdCA9IHBhZ2VXaWR0aCAqIGs7XG5cdFx0dmFyIGhQdCA9IHBhZ2VIZWlnaHQgKiBrO1xuXG5cdFx0Zm9yKG49MTsgbiA8PSBwYWdlOyBuKyspIHtcblx0XHRcdG5ld09iamVjdCgpO1xuXHRcdFx0b3V0KCc8PC9UeXBlIC9QYWdlJyk7XG5cdFx0XHRvdXQoJy9QYXJlbnQgMSAwIFInKTtcdFxuXHRcdFx0b3V0KCcvUmVzb3VyY2VzIDIgMCBSJyk7XG5cdFx0XHRvdXQoJy9Db250ZW50cyAnICsgKG9iamVjdE51bWJlciArIDEpICsgJyAwIFI+PicpO1xuXHRcdFx0b3V0KCdlbmRvYmonKTtcblx0XHRcdFxuXHRcdFx0Ly9QYWdlIGNvbnRlbnRcblx0XHRcdHAgPSBwYWdlc1tuXTtcblx0XHRcdG5ld09iamVjdCgpO1xuXHRcdFx0b3V0KCc8PC9MZW5ndGggJyArIHAubGVuZ3RoICArICc+PicpO1xuXHRcdFx0cHV0U3RyZWFtKHApO1xuXHRcdFx0b3V0KCdlbmRvYmonKTtcdFx0XHRcdFx0XG5cdFx0fVxuXHRcdG9mZnNldHNbMV0gPSBidWZmZXIubGVuZ3RoO1xuXHRcdG91dCgnMSAwIG9iaicpO1xuXHRcdG91dCgnPDwvVHlwZSAvUGFnZXMnKTtcblx0XHR2YXIga2lkcz0nL0tpZHMgWyc7XG5cdFx0Zm9yIChpID0gMDsgaSA8IHBhZ2U7IGkrKykge1xuXHRcdFx0a2lkcyArPSAoMyArIDIgKiBpKSArICcgMCBSICc7XG5cdFx0fVxuXHRcdG91dChraWRzICsgJ10nKTtcblx0XHRvdXQoJy9Db3VudCAnICsgcGFnZSk7XG5cdFx0b3V0KHNwcmludGYoJy9NZWRpYUJveCBbMCAwICUuMmYgJS4yZl0nLCB3UHQsIGhQdCkpO1xuXHRcdG91dCgnPj4nKTtcblx0XHRvdXQoJ2VuZG9iaicpO1x0XHRcblx0fVxuXHRcblx0dmFyIHB1dFN0cmVhbSA9IGZ1bmN0aW9uKHN0cikge1xuXHRcdG91dCgnc3RyZWFtJyk7XG5cdFx0b3V0KHN0cik7XG5cdFx0b3V0KCdlbmRzdHJlYW0nKTtcblx0fVxuXHRcblx0dmFyIHB1dFJlc291cmNlcyA9IGZ1bmN0aW9uKCkge1xuXHRcdHB1dEZvbnRzKCk7XG5cdFx0cHV0SW1hZ2VzKCk7XG5cdFx0XG5cdFx0Ly9SZXNvdXJjZSBkaWN0aW9uYXJ5XG5cdFx0b2Zmc2V0c1syXSA9IGJ1ZmZlci5sZW5ndGg7XG5cdFx0b3V0KCcyIDAgb2JqJyk7XG5cdFx0b3V0KCc8PCcpO1xuXHRcdHB1dFJlc291cmNlRGljdGlvbmFyeSgpO1xuXHRcdG91dCgnPj4nKTtcblx0XHRvdXQoJ2VuZG9iaicpO1xuXHR9XHRcblx0XG5cdHZhciBwdXRGb250cyA9IGZ1bmN0aW9uKCkge1xuXHRcdC8vIFRPRE86IE9ubHkgc3VwcG9ydHMgY29yZSBmb250IGhhcmRjb2RlZCB0byBIZWx2ZXRpY2Fcblx0XHRuZXdPYmplY3QoKTtcblx0XHRmb250TnVtYmVyID0gb2JqZWN0TnVtYmVyO1xuXHRcdG5hbWUgPSAnSGVsdmV0aWNhJztcblx0XHRvdXQoJzw8L1R5cGUgL0ZvbnQnKTtcblx0XHRvdXQoJy9CYXNlRm9udCAvJyArIG5hbWUpO1xuXHRcdG91dCgnL1N1YnR5cGUgL1R5cGUxJyk7XG5cdFx0b3V0KCcvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZycpO1xuXHRcdG91dCgnPj4nKTtcblx0XHRvdXQoJ2VuZG9iaicpO1xuXHR9XG5cdFxuXHR2YXIgcHV0SW1hZ2VzID0gZnVuY3Rpb24oKSB7XG5cdFx0Ly8gVE9ET1xuXHR9XG5cdFxuXHR2YXIgcHV0UmVzb3VyY2VEaWN0aW9uYXJ5ID0gZnVuY3Rpb24oKSB7XG5cdFx0b3V0KCcvUHJvY1NldCBbL1BERiAvVGV4dCAvSW1hZ2VCIC9JbWFnZUMgL0ltYWdlSV0nKTtcblx0XHRvdXQoJy9Gb250IDw8Jyk7XG5cdFx0Ly8gRG8gdGhpcyBmb3IgZWFjaCBmb250LCB0aGUgJzEnIGJpdCBpcyB0aGUgaW5kZXggb2YgdGhlIGZvbnRcbiAgICAgICAgLy8gZm9udE51bWJlciBpcyBjdXJyZW50bHkgdGhlIG9iamVjdCBudW1iZXIgcmVsYXRlZCB0byAncHV0Rm9udHMnXG5cdFx0b3V0KCcvRjEgJyArIGZvbnROdW1iZXIgKyAnIDAgUicpO1xuXHRcdG91dCgnPj4nKTtcblx0XHRvdXQoJy9YT2JqZWN0IDw8Jyk7XG5cdFx0cHV0WG9iamVjdERpY3QoKTtcblx0XHRvdXQoJz4+Jyk7XG5cdH1cblx0XG5cdHZhciBwdXRYb2JqZWN0RGljdCA9IGZ1bmN0aW9uKCkge1xuXHRcdC8vIFRPRE9cblx0XHQvLyBMb29wIHRocm91Z2ggaW1hZ2VzXG5cdH1cblx0XG5cdFxuXHR2YXIgcHV0SW5mbyA9IGZ1bmN0aW9uKCkge1xuXHRcdG91dCgnL1Byb2R1Y2VyIChqc1BERiAnICsgdmVyc2lvbiArICcpJyk7XG5cdFx0aWYoZG9jdW1lbnRQcm9wZXJ0aWVzLnRpdGxlICE9IHVuZGVmaW5lZCkge1xuXHRcdFx0b3V0KCcvVGl0bGUgKCcgKyBwZGZFc2NhcGUoZG9jdW1lbnRQcm9wZXJ0aWVzLnRpdGxlKSArICcpJyk7XG5cdFx0fVxuXHRcdGlmKGRvY3VtZW50UHJvcGVydGllcy5zdWJqZWN0ICE9IHVuZGVmaW5lZCkge1xuXHRcdFx0b3V0KCcvU3ViamVjdCAoJyArIHBkZkVzY2FwZShkb2N1bWVudFByb3BlcnRpZXMuc3ViamVjdCkgKyAnKScpO1xuXHRcdH1cblx0XHRpZihkb2N1bWVudFByb3BlcnRpZXMuYXV0aG9yICE9IHVuZGVmaW5lZCkge1xuXHRcdFx0b3V0KCcvQXV0aG9yICgnICsgcGRmRXNjYXBlKGRvY3VtZW50UHJvcGVydGllcy5hdXRob3IpICsgJyknKTtcblx0XHR9XG5cdFx0aWYoZG9jdW1lbnRQcm9wZXJ0aWVzLmtleXdvcmRzICE9IHVuZGVmaW5lZCkge1xuXHRcdFx0b3V0KCcvS2V5d29yZHMgKCcgKyBwZGZFc2NhcGUoZG9jdW1lbnRQcm9wZXJ0aWVzLmtleXdvcmRzKSArICcpJyk7XG5cdFx0fVxuXHRcdGlmKGRvY3VtZW50UHJvcGVydGllcy5jcmVhdG9yICE9IHVuZGVmaW5lZCkge1xuXHRcdFx0b3V0KCcvQ3JlYXRvciAoJyArIHBkZkVzY2FwZShkb2N1bWVudFByb3BlcnRpZXMuY3JlYXRvcikgKyAnKScpO1xuXHRcdH1cdFx0XG5cdFx0dmFyIGNyZWF0ZWQgPSBuZXcgRGF0ZSgpO1xuXHRcdHZhciB5ZWFyID0gY3JlYXRlZC5nZXRGdWxsWWVhcigpO1xuXHRcdHZhciBtb250aCA9IChjcmVhdGVkLmdldE1vbnRoKCkgKyAxKTtcblx0XHR2YXIgZGF5ID0gY3JlYXRlZC5nZXREYXRlKCk7XG5cdFx0dmFyIGhvdXIgPSBjcmVhdGVkLmdldEhvdXJzKCk7XG5cdFx0dmFyIG1pbnV0ZSA9IGNyZWF0ZWQuZ2V0TWludXRlcygpO1xuXHRcdHZhciBzZWNvbmQgPSBjcmVhdGVkLmdldFNlY29uZHMoKTtcblx0XHRvdXQoJy9DcmVhdGlvbkRhdGUgKEQ6JyArIHNwcmludGYoJyUwMmQlMDJkJTAyZCUwMmQlMDJkJTAyZCcsIHllYXIsIG1vbnRoLCBkYXksIGhvdXIsIG1pbnV0ZSwgc2Vjb25kKSArICcpJyk7XG5cdH1cblx0XG5cdHZhciBwdXRDYXRhbG9nID0gZnVuY3Rpb24gKCkge1xuXHRcdG91dCgnL1R5cGUgL0NhdGFsb2cnKTtcblx0XHRvdXQoJy9QYWdlcyAxIDAgUicpO1xuXHRcdC8vIFRPRE86IEFkZCB6b29tIGFuZCBsYXlvdXQgbW9kZXNcblx0XHRvdXQoJy9PcGVuQWN0aW9uIFszIDAgUiAvRml0SCBudWxsXScpO1xuXHRcdG91dCgnL1BhZ2VMYXlvdXQgL09uZUNvbHVtbicpO1xuXHR9XHRcblx0XG5cdGZ1bmN0aW9uIHB1dFRyYWlsZXIoKSB7XG5cdFx0b3V0KCcvU2l6ZSAnICsgKG9iamVjdE51bWJlciArIDEpKTtcblx0XHRvdXQoJy9Sb290ICcgKyBvYmplY3ROdW1iZXIgKyAnIDAgUicpO1xuXHRcdG91dCgnL0luZm8gJyArIChvYmplY3ROdW1iZXIgLSAxKSArICcgMCBSJyk7XG5cdH1cdFxuXG5cdHZhciBlbmREb2N1bWVudCA9IGZ1bmN0aW9uKCkge1xuXHRcdHN0YXRlID0gMTtcblx0XHRwdXRIZWFkZXIoKTtcblx0XHRwdXRQYWdlcygpO1xuXHRcdFxuXHRcdHB1dFJlc291cmNlcygpO1xuXHRcdC8vSW5mb1xuXHRcdG5ld09iamVjdCgpO1xuXHRcdG91dCgnPDwnKTtcblx0XHRwdXRJbmZvKCk7XG5cdFx0b3V0KCc+PicpO1xuXHRcdG91dCgnZW5kb2JqJyk7XG5cdFx0XG5cdFx0Ly9DYXRhbG9nXG5cdFx0bmV3T2JqZWN0KCk7XG5cdFx0b3V0KCc8PCcpO1xuXHRcdHB1dENhdGFsb2coKTtcblx0XHRvdXQoJz4+Jyk7XG5cdFx0b3V0KCdlbmRvYmonKTtcblx0XHRcblx0XHQvL0Nyb3NzLXJlZlxuXHRcdHZhciBvID0gYnVmZmVyLmxlbmd0aDtcblx0XHRvdXQoJ3hyZWYnKTtcblx0XHRvdXQoJzAgJyArIChvYmplY3ROdW1iZXIgKyAxKSk7XG5cdFx0b3V0KCcwMDAwMDAwMDAwIDY1NTM1IGYgJyk7XG5cdFx0Zm9yICh2YXIgaT0xOyBpIDw9IG9iamVjdE51bWJlcjsgaSsrKSB7XG5cdFx0XHRvdXQoc3ByaW50ZignJTAxMGQgMDAwMDAgbiAnLCBvZmZzZXRzW2ldKSk7XG5cdFx0fVxuXHRcdC8vVHJhaWxlclxuXHRcdG91dCgndHJhaWxlcicpO1xuXHRcdG91dCgnPDwnKTtcblx0XHRwdXRUcmFpbGVyKCk7XG5cdFx0b3V0KCc+PicpO1xuXHRcdG91dCgnc3RhcnR4cmVmJyk7XG5cdFx0b3V0KG8pO1xuXHRcdG91dCgnJSVFT0YnKTtcblx0XHRzdGF0ZSA9IDM7XHRcdFxuXHR9XG5cdFxuXHR2YXIgYmVnaW5QYWdlID0gZnVuY3Rpb24oKSB7XG5cdFx0cGFnZSArKztcblx0XHQvLyBEbyBkaW1lbnNpb24gc3R1ZmZcblx0XHRzdGF0ZSA9IDI7XG5cdFx0cGFnZXNbcGFnZV0gPSAnJztcblx0XHRcblx0XHQvLyBUT0RPOiBIYXJkY29kZWQgYXQgQTQgYW5kIHBvcnRyYWl0XG5cdFx0cGFnZUhlaWdodCA9IHBhZ2VGb3JtYXRzWydhNCddWzFdIC8gaztcblx0XHRwYWdlV2lkdGggPSBwYWdlRm9ybWF0c1snYTQnXVswXSAvIGs7XG5cdH1cblx0XG5cdHZhciBvdXQgPSBmdW5jdGlvbihzdHJpbmcpIHtcblx0XHRpZihzdGF0ZSA9PSAyKSB7XG5cdFx0XHRwYWdlc1twYWdlXSArPSBzdHJpbmcgKyAnXFxuJztcblx0XHR9IGVsc2Uge1xuXHRcdFx0YnVmZmVyICs9IHN0cmluZyArICdcXG4nO1xuXHRcdH1cblx0fVxuXHRcblx0dmFyIF9hZGRQYWdlID0gZnVuY3Rpb24oKSB7XG5cdFx0YmVnaW5QYWdlKCk7XG5cdFx0Ly8gU2V0IGxpbmUgd2lkdGhcblx0XHRvdXQoc3ByaW50ZignJS4yZiB3JywgKGxpbmVXaWR0aCAqIGspKSk7XG5cdFx0XG5cdFx0Ly8gU2V0IGZvbnQgLSBUT0RPXG5cdFx0Ly8gMTYgaXMgdGhlIGZvbnQgc2l6ZVxuXHRcdHBhZ2VGb250U2l6ZSA9IGZvbnRTaXplO1xuXHRcdG91dCgnQlQgL0YxICcgKyBwYXJzZUludChmb250U2l6ZSkgKyAnLjAwIFRmIEVUJyk7IFx0XHRcblx0fVxuXHRcblx0Ly8gQWRkIHRoZSBmaXJzdCBwYWdlIGF1dG9tYXRpY2FsbHlcblx0X2FkZFBhZ2UoKTtcdFxuXG5cdC8vIEVzY2FwZSB0ZXh0XG5cdHZhciBwZGZFc2NhcGUgPSBmdW5jdGlvbih0ZXh0KSB7XG5cdFx0cmV0dXJuIHRleHQucmVwbGFjZSgvXFxcXC9nLCAnXFxcXFxcXFwnKS5yZXBsYWNlKC9cXCgvZywgJ1xcXFwoJykucmVwbGFjZSgvXFwpL2csICdcXFxcKScpO1xuXHR9XG5cdFxuXHRyZXR1cm4ge1xuXHRcdGFkZFBhZ2U6IGZ1bmN0aW9uKCkge1xuXHRcdFx0X2FkZFBhZ2UoKTtcblx0XHR9LFxuXHRcdHRleHQ6IGZ1bmN0aW9uKHgsIHksIHRleHQpIHtcblx0XHRcdC8vIG5lZWQgcGFnZSBoZWlnaHRcblx0XHRcdGlmKHBhZ2VGb250U2l6ZSAhPSBmb250U2l6ZSkge1xuXHRcdFx0XHRvdXQoJ0JUIC9GMSAnICsgcGFyc2VJbnQoZm9udFNpemUpICsgJy4wMCBUZiBFVCcpO1xuXHRcdFx0XHRwYWdlRm9udFNpemUgPSBmb250U2l6ZTtcblx0XHRcdH1cblx0XHRcdHZhciBzdHIgPSBzcHJpbnRmKCdCVCAlLjJmICUuMmYgVGQgKCVzKSBUaiBFVCcsIHggKiBrLCAocGFnZUhlaWdodCAtIHkpICogaywgcGRmRXNjYXBlKHRleHQpKTtcblx0XHRcdG91dChzdHIpO1xuXHRcdH0sXG5cdFx0c2V0UHJvcGVydGllczogZnVuY3Rpb24ocHJvcGVydGllcykge1xuXHRcdFx0ZG9jdW1lbnRQcm9wZXJ0aWVzID0gcHJvcGVydGllcztcblx0XHR9LFxuXHRcdGFkZEltYWdlOiBmdW5jdGlvbihpbWFnZURhdGEsIGZvcm1hdCwgeCwgeSwgdywgaCkge1xuXHRcdFxuXHRcdH0sXG5cdFx0b3V0cHV0OiBmdW5jdGlvbih0eXBlLCBvcHRpb25zKSB7XG5cdFx0XHRlbmREb2N1bWVudCgpO1xuXHRcdFx0aWYodHlwZSA9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0cmV0dXJuIGJ1ZmZlcjtcblx0XHRcdH1cblx0XHRcdGlmKHR5cGUgPT0gJ2RhdGF1cmknKSB7XG5cdFx0XHRcdGRvY3VtZW50LmxvY2F0aW9uLmhyZWYgPSAnZGF0YTphcHBsaWNhdGlvbi9wZGY7YmFzZTY0LCcgKyBCYXNlNjQuZW5jb2RlKGJ1ZmZlcik7XG5cdFx0XHR9XG5cdFx0XHRpZih0eXBlID09ICdkYXRhdXJpc3RyaW5nJykge1xuXG5cblx0XHRcdFx0cmV0dXJuICdkYXRhOmFwcGxpY2F0aW9uL3BkZjtiYXNlNjQsJyArIEJhc2U2NC5lbmNvZGUoYnVmZmVyKTtcblx0XHRcdH1cblx0XHRcdC8vIEBUT0RPOiBBZGQgZGlmZmVyZW50IG91dHB1dCBvcHRpb25zXG5cdFx0fSxcblx0XHRzZXRGb250U2l6ZTogZnVuY3Rpb24oc2l6ZSkge1xuXHRcdFx0Zm9udFNpemUgPSBzaXplO1xuXHRcdH1cblx0fVxuXG59O1xuIiwiJChkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oKXtcblxuICAgICQoXCIuZW1iZWQtaW1hZ2VcIikuY2xpY2soZnVuY3Rpb24oZSl7IFxuXG4gICAgICAgIHZhciBpZnJhbWUgPSAkKHRoaXMpLnBhcmVudCgpLmZpbmQoJ2lmcmFtZScpO1xuICAgICAgICB2YXIgdmlkZW9PYmplY3QgPSAkKHRoaXMpLnBhcmVudCgpLmZpbmQoJy5lbWJlZC12aWRlbycpO1xuICAgICAgICB2YXIgdGV4dGNvbnRlbnQgPSAkKHRoaXMpLnBhcmVudCgpLnByZXYoKTsgICAgICAgXG4gICAgICAgIFxuICAgICAgICBcbiAgICAgICAgdmFyIHBsYXllcnMgID0gd2luZG93LnBsYXllcnNhZW07ICAgXG4gICAgICAgIFxuICAgICAgICBpZihpZnJhbWUubGVuZ3RoPj0xKXtcblxuXG4gICAgICAgICQoXCIubHBfX211bHRpbWVkaWFfY2FyZCAubHBfX2NhcmRfaW1nID4gLmVtYmVkLXZpZGVvXCIpLmZpbmQoXCJpZnJhbWVcIikucmVtb3ZlQXR0cihcInN0eWxlXCIpLmNzcyh7XG4gICAgICAgICAgICAnaGVpZ2h0JzogJChcIi5scF9fbXVsdGltZWRpYV9jYXJkIC5scF9fY2FyZF9pbWcgPiBpbWdcIikuaGVpZ2h0KCksXG4gICAgICAgICAgICAnd2lkdGgnOiAkKFwiLmxwX19tdWx0aW1lZGlhX2NhcmQgLmxwX19jYXJkX2ltZyA+IGltZ1wiKS53aWR0aCgpXG4gICAgICAgIH0pO1xuXG5cblxuICAgICAgICAgICAgaWYodHlwZW9mIHRleHRjb250ZW50IT1cInVuZGVmaW5lZFwiICYmIHR5cGVvZiAodGV4dGNvbnRlbnQuYXR0cignY2xhc3MnKSkgIT0gJ3VuZGVmaW5lZCcgJiYgdGV4dGNvbnRlbnQuYXR0cignY2xhc3MnKS5pbmRleE9mKCdmZWF0dXJlZGNhcmQnKT4tMSl7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgdGV4dGNvbnRlbnQuaGlkZSgpO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgICAgICB2YXIgc3JjVmFsID0gaWZyYW1lWzBdLnNyYztcbiAgICAgICAgICAgIHZhciBpbWFnZU9iamVjdCA9ICQodGhpcykucGFyZW50KCkuY2hpbGRyZW4oJzpmaXJzdC1jaGlsZCcpO1xuICAgICAgICAgICAgdmFyIHBsYXlJY29uID0gJCh0aGlzKS5wYXJlbnQoKS5maW5kKCcubHBfX3BsYXlfaWNvbicpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBpZihpbWFnZU9iamVjdC5sZW5ndGg+PTEpe1xuICAgICAgICAgICAgICAgIGltYWdlT2JqZWN0LmNzcyhcInZpc2liaWxpdHlcIiwgXCJoaWRkZW5cIik7XG4gICAgICAgICAgICAgICAgaW1hZ2VPYmplY3QuY3NzKFwiaGVpZ2h0XCIsIFwiMFwiKTtcbiAgICAgICAgICAgICAgICAvL2ltYWdlT2JqZWN0LmhpZGUoKTtcbiAgICAgICAgICAgICAgICBpZihwbGF5SWNvbi5sZW5ndGg+PTEpe1xuICAgICAgICAgICAgICAgIHBsYXlJY29uLmNzcyhcInZpc2liaWxpdHlcIiwgXCJoaWRkZW5cIik7XG4gICAgICAgICAgICAgICAgcGxheUljb24uY3NzKFwiaGVpZ2h0XCIsIFwiMFwiKTtcbiAgICAgICAgICAgICAgICAgICAvLyBwbGF5SWNvbi5oaWRlKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHZpZGVvT2JqZWN0LmNzcyhcInZpc2liaWxpdHlcIiwgXCJ2aXNpYmxlXCIpO1xuICAgICAgICAgICAgICAgIHZpZGVvT2JqZWN0LmNzcyhcImhlaWdodFwiLCBcImF1dG9cIik7XG4gICAgICAgICAgICAgICAgdmlkZW9PYmplY3Quc2hvdygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgXG4gICAgICAgICAgICBpZiAoc3JjVmFsLmluZGV4T2YoXCJ5b3V0dWJlXCIpID49IDAgKXtcblxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHZhciBpZnJhbWVpZCA9IGlmcmFtZVswXS5pZDtcbiAgICAgICAgICAgICAgICB2YXIgcGxheWVyID0gbnVsbDtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBpZih0eXBlb2YgcGxheWVycyAhPSd1bmRlZmluZWQnKXtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIGZvciAoeCA9IDA7IHggPCBwbGF5ZXJzLmxlbmd0aDsgeCsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmKGlmcmFtZWlkPT1wbGF5ZXJzW3hdLmEuaWQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYXllciA9IHBsYXllcnNbeF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIGlmKG51bGwhPSBwbGF5ZXIpe1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgcGxheWVyLnBsYXlWaWRlbygpO1xuICAgICAgICAgICAgICAgIH1lbHNle1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIGlmIChzcmNWYWwuaW5kZXhPZihcIj9cIikgPj0gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZnJhbWVbMF0uc3JjID1pZnJhbWVbMF0uc3JjICsnJmF1dG9wbGF5PTEnO1xuICAgICAgICAgICAgICAgICAgICB9ZWxzZSBpZiAoc3JjVmFsLmluZGV4T2YoXCI/XCIpID09IC0xKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmcmFtZVswXS5zcmMgPWlmcmFtZVswXS5zcmMgKyc/YXV0b3BsYXk9MSc7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZXF1YWxIZWlnaHQoJChcIi5scF9faW5kZXB0aF9jYXJkX3dyYXBwZXJcIikpO1xuICAgIH0pO1xuICAgIFxufSk7IiwiLy8gLS0tLS0tLS0tLS1CZWdpbiBOYXZpZ2F0aW9uIEpTIC0tLS0tLS0tLS0tLS0gLy9cbnZhciBzZWxlY3QgPSByZXF1aXJlKCcuLi91dGlscy9zZWxlY3QnKTtcbnZhciBkaXNwYXRjaCA9IHJlcXVpcmUoJy4uL3V0aWxzL2Rpc3BhdGNoJyk7XG5cbnZhciBjbGlja0V2ZW50ID0gKCdvbnRvdWNoc3RhcnQnIGluIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCA/ICd0b3VjaHN0YXJ0JyA6ICdjbGljaycpO1xudmFyIGRpc3BhdGNoZXJzID0gW107XG5cbmZ1bmN0aW9uIGhhbmRsZU5hdkVsZW1lbnRzIChlKSB7XG5cbiAgdmFyIHRvZ2dsZUVsZW1lbnRzID0gc2VsZWN0KCcubG9vcC1vdmVybGF5LCAubG9vcC1uYXYnKTtcbiAgdmFyIG5hdkNsb3NlRWxlbWVudCA9IHNlbGVjdCgnLmxvb3AtbmF2LWNsb3NlJylbIDAgXTtcblxuICB0b2dnbGVFbGVtZW50cy5mb3JFYWNoKGZ1bmN0aW9uIChlbGVtZW50KSB7XG4gICAgZWxlbWVudC5jbGFzc0xpc3QudG9nZ2xlKCdpcy12aXNpYmxlJyk7XG4gIH0pO1xuXG4gIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnRvZ2dsZSgndXNhLW1vYmlsZV9uYXYtYWN0aXZlJyk7XG4gIG5hdkNsb3NlRWxlbWVudC5mb2N1cygpO1xuXG4gIHJldHVybiBmYWxzZTtcbn1cblxuZnVuY3Rpb24gbmF2SW5pdCAoKSB7XG4gIHZhciBuYXZFbGVtZW50cyA9IHNlbGVjdCgnLmxvb3AtbWVudS1idG4sIC5sb29wLW92ZXJsYXksIC5sb29wLW5hdi1jbG9zZScpO1xuXG4gIGRpc3BhdGNoZXJzID0gbmF2RWxlbWVudHMubWFwKGZ1bmN0aW9uIChlbGVtZW50KSB7XG4gICAgcmV0dXJuIGRpc3BhdGNoKGVsZW1lbnQsIGNsaWNrRXZlbnQsIGhhbmRsZU5hdkVsZW1lbnRzKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIG5hdk9mZiAoKSB7XG4gIHdoaWxlIChkaXNwYXRjaGVycy5sZW5ndGgpIHtcbiAgICBkaXNwYXRjaGVycy5wb3AoKS5vZmYoKTtcbiAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IG5hdkluaXQ7XG5tb2R1bGUuZXhwb3J0cy5vZmYgPSBuYXZPZmY7XG4vLyAtLS0tLS0tLS0tLUVuZCBOYXZpZ2F0aW9uIEpTIC0tLS0tLS0tLS0tLS0gLy8iLCJcblxuZnVuY3Rpb24gc3ByaW50ZiggKSB7XG4gICAgLy8gUmV0dXJuIGEgZm9ybWF0dGVkIHN0cmluZyAgXG4gICAgLy8gXG4gICAgLy8gdmVyc2lvbjogOTAzLjMwMTZcbiAgICAvLyBkaXNjdXNzIGF0OiBodHRwOi8vcGhwanMub3JnL2Z1bmN0aW9ucy9zcHJpbnRmXG4gICAgLy8gKyAgIG9yaWdpbmFsIGJ5OiBBc2ggU2VhcmxlIChodHRwOi8vaGV4bWVuLmNvbS9ibG9nLylcbiAgICAvLyArIG5hbWVzcGFjZWQgYnk6IE1pY2hhZWwgV2hpdGUgKGh0dHA6Ly9nZXRzcHJpbmsuY29tKVxuICAgIC8vICsgICAgdHdlYWtlZCBieTogSmFja1xuICAgIC8vICsgICBpbXByb3ZlZCBieTogS2V2aW4gdmFuIFpvbm5ldmVsZCAoaHR0cDovL2tldmluLnZhbnpvbm5ldmVsZC5uZXQpXG4gICAgLy8gKyAgICAgIGlucHV0IGJ5OiBQYXVsbyBSaWNhcmRvIEYuIFNhbnRvc1xuICAgIC8vICsgICBpbXByb3ZlZCBieTogS2V2aW4gdmFuIFpvbm5ldmVsZCAoaHR0cDovL2tldmluLnZhbnpvbm5ldmVsZC5uZXQpXG4gICAgLy8gKyAgICAgIGlucHV0IGJ5OiBCcmV0dCBaYW1pciAoaHR0cDovL2JyZXR0ejkuYmxvZ3Nwb3QuY29tKVxuICAgIC8vICsgICBpbXByb3ZlZCBieTogS2V2aW4gdmFuIFpvbm5ldmVsZCAoaHR0cDovL2tldmluLnZhbnpvbm5ldmVsZC5uZXQpXG4gICAgLy8gKiAgICAgZXhhbXBsZSAxOiBzcHJpbnRmKFwiJTAxLjJmXCIsIDEyMy4xKTtcbiAgICAvLyAqICAgICByZXR1cm5zIDE6IDEyMy4xMFxuICAgIC8vICogICAgIGV4YW1wbGUgMjogc3ByaW50ZihcIlslMTBzXVwiLCAnbW9ua2V5Jyk7XG4gICAgLy8gKiAgICAgcmV0dXJucyAyOiAnWyAgICBtb25rZXldJ1xuICAgIC8vICogICAgIGV4YW1wbGUgMzogc3ByaW50ZihcIlslJyMxMHNdXCIsICdtb25rZXknKTtcbiAgICAvLyAqICAgICByZXR1cm5zIDM6ICdbIyMjI21vbmtleV0nXG4gICAgdmFyIHJlZ2V4ID0gLyUlfCUoXFxkK1xcJCk/KFstK1xcJyMwIF0qKShcXCpcXGQrXFwkfFxcKnxcXGQrKT8oXFwuKFxcKlxcZCtcXCR8XFwqfFxcZCspKT8oW3NjYm94WHVpZGZlZ0VHXSkvZztcbiAgICB2YXIgYSA9IGFyZ3VtZW50cywgaSA9IDAsIGZvcm1hdCA9IGFbaSsrXTtcblxuICAgIC8vIHBhZCgpXG4gICAgdmFyIHBhZCA9IGZ1bmN0aW9uKHN0ciwgbGVuLCBjaHIsIGxlZnRKdXN0aWZ5KSB7XG4gICAgICAgIGlmICghY2hyKSBjaHIgPSAnICc7XG4gICAgICAgIHZhciBwYWRkaW5nID0gKHN0ci5sZW5ndGggPj0gbGVuKSA/ICcnIDogQXJyYXkoMSArIGxlbiAtIHN0ci5sZW5ndGggPj4+IDApLmpvaW4oY2hyKTtcbiAgICAgICAgcmV0dXJuIGxlZnRKdXN0aWZ5ID8gc3RyICsgcGFkZGluZyA6IHBhZGRpbmcgKyBzdHI7XG4gICAgfTtcblxuICAgIC8vIGp1c3RpZnkoKVxuICAgIHZhciBqdXN0aWZ5ID0gZnVuY3Rpb24odmFsdWUsIHByZWZpeCwgbGVmdEp1c3RpZnksIG1pbldpZHRoLCB6ZXJvUGFkLCBjdXN0b21QYWRDaGFyKSB7XG4gICAgICAgIHZhciBkaWZmID0gbWluV2lkdGggLSB2YWx1ZS5sZW5ndGg7XG4gICAgICAgIGlmIChkaWZmID4gMCkge1xuICAgICAgICAgICAgaWYgKGxlZnRKdXN0aWZ5IHx8ICF6ZXJvUGFkKSB7XG4gICAgICAgICAgICAgICAgdmFsdWUgPSBwYWQodmFsdWUsIG1pbldpZHRoLCBjdXN0b21QYWRDaGFyLCBsZWZ0SnVzdGlmeSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHZhbHVlID0gdmFsdWUuc2xpY2UoMCwgcHJlZml4Lmxlbmd0aCkgKyBwYWQoJycsIGRpZmYsICcwJywgdHJ1ZSkgKyB2YWx1ZS5zbGljZShwcmVmaXgubGVuZ3RoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgfTtcblxuICAgIC8vIGZvcm1hdEJhc2VYKClcbiAgICB2YXIgZm9ybWF0QmFzZVggPSBmdW5jdGlvbih2YWx1ZSwgYmFzZSwgcHJlZml4LCBsZWZ0SnVzdGlmeSwgbWluV2lkdGgsIHByZWNpc2lvbiwgemVyb1BhZCkge1xuICAgICAgICAvLyBOb3RlOiBjYXN0cyBuZWdhdGl2ZSBudW1iZXJzIHRvIHBvc2l0aXZlIG9uZXNcbiAgICAgICAgdmFyIG51bWJlciA9IHZhbHVlID4+PiAwO1xuICAgICAgICBwcmVmaXggPSBwcmVmaXggJiYgbnVtYmVyICYmIHsnMic6ICcwYicsICc4JzogJzAnLCAnMTYnOiAnMHgnfVtiYXNlXSB8fCAnJztcbiAgICAgICAgdmFsdWUgPSBwcmVmaXggKyBwYWQobnVtYmVyLnRvU3RyaW5nKGJhc2UpLCBwcmVjaXNpb24gfHwgMCwgJzAnLCBmYWxzZSk7XG4gICAgICAgIHJldHVybiBqdXN0aWZ5KHZhbHVlLCBwcmVmaXgsIGxlZnRKdXN0aWZ5LCBtaW5XaWR0aCwgemVyb1BhZCk7XG4gICAgfTtcblxuICAgIC8vIGZvcm1hdFN0cmluZygpXG4gICAgdmFyIGZvcm1hdFN0cmluZyA9IGZ1bmN0aW9uKHZhbHVlLCBsZWZ0SnVzdGlmeSwgbWluV2lkdGgsIHByZWNpc2lvbiwgemVyb1BhZCwgY3VzdG9tUGFkQ2hhcikge1xuICAgICAgICBpZiAocHJlY2lzaW9uICE9IG51bGwpIHtcbiAgICAgICAgICAgIHZhbHVlID0gdmFsdWUuc2xpY2UoMCwgcHJlY2lzaW9uKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ganVzdGlmeSh2YWx1ZSwgJycsIGxlZnRKdXN0aWZ5LCBtaW5XaWR0aCwgemVyb1BhZCwgY3VzdG9tUGFkQ2hhcik7XG4gICAgfTtcblxuICAgIC8vIGRvRm9ybWF0KClcbiAgICB2YXIgZG9Gb3JtYXQgPSBmdW5jdGlvbihzdWJzdHJpbmcsIHZhbHVlSW5kZXgsIGZsYWdzLCBtaW5XaWR0aCwgXywgcHJlY2lzaW9uLCB0eXBlKSB7XG4gICAgICAgIHZhciBudW1iZXI7XG4gICAgICAgIHZhciBwcmVmaXg7XG4gICAgICAgIHZhciBtZXRob2Q7XG4gICAgICAgIHZhciB0ZXh0VHJhbnNmb3JtO1xuICAgICAgICB2YXIgdmFsdWU7XG5cbiAgICAgICAgaWYgKHN1YnN0cmluZyA9PSAnJSUnKSByZXR1cm4gJyUnO1xuXG4gICAgICAgIC8vIHBhcnNlIGZsYWdzXG4gICAgICAgIHZhciBsZWZ0SnVzdGlmeSA9IGZhbHNlLCBwb3NpdGl2ZVByZWZpeCA9ICcnLCB6ZXJvUGFkID0gZmFsc2UsIHByZWZpeEJhc2VYID0gZmFsc2UsIGN1c3RvbVBhZENoYXIgPSAnICc7XG4gICAgICAgIHZhciBmbGFnc2wgPSBmbGFncy5sZW5ndGg7XG4gICAgICAgIGZvciAodmFyIGogPSAwOyBmbGFncyAmJiBqIDwgZmxhZ3NsOyBqKyspIHN3aXRjaCAoZmxhZ3MuY2hhckF0KGopKSB7XG4gICAgICAgICAgICBjYXNlICcgJzogcG9zaXRpdmVQcmVmaXggPSAnICc7IGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAnKyc6IHBvc2l0aXZlUHJlZml4ID0gJysnOyBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJy0nOiBsZWZ0SnVzdGlmeSA9IHRydWU7IGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBcIidcIjogY3VzdG9tUGFkQ2hhciA9IGZsYWdzLmNoYXJBdChqKzEpOyBicmVhaztcbiAgICAgICAgICAgIGNhc2UgJzAnOiB6ZXJvUGFkID0gdHJ1ZTsgYnJlYWs7XG4gICAgICAgICAgICBjYXNlICcjJzogcHJlZml4QmFzZVggPSB0cnVlOyBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIHBhcmFtZXRlcnMgbWF5IGJlIG51bGwsIHVuZGVmaW5lZCwgZW1wdHktc3RyaW5nIG9yIHJlYWwgdmFsdWVkXG4gICAgICAgIC8vIHdlIHdhbnQgdG8gaWdub3JlIG51bGwsIHVuZGVmaW5lZCBhbmQgZW1wdHktc3RyaW5nIHZhbHVlc1xuICAgICAgICBpZiAoIW1pbldpZHRoKSB7XG4gICAgICAgICAgICBtaW5XaWR0aCA9IDA7XG4gICAgICAgIH0gZWxzZSBpZiAobWluV2lkdGggPT0gJyonKSB7XG4gICAgICAgICAgICBtaW5XaWR0aCA9ICthW2krK107XG4gICAgICAgIH0gZWxzZSBpZiAobWluV2lkdGguY2hhckF0KDApID09ICcqJykge1xuICAgICAgICAgICAgbWluV2lkdGggPSArYVttaW5XaWR0aC5zbGljZSgxLCAtMSldO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbWluV2lkdGggPSArbWluV2lkdGg7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBOb3RlOiB1bmRvY3VtZW50ZWQgcGVybCBmZWF0dXJlOlxuICAgICAgICBpZiAobWluV2lkdGggPCAwKSB7XG4gICAgICAgICAgICBtaW5XaWR0aCA9IC1taW5XaWR0aDtcbiAgICAgICAgICAgIGxlZnRKdXN0aWZ5ID0gdHJ1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghaXNGaW5pdGUobWluV2lkdGgpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ3NwcmludGY6IChtaW5pbXVtLSl3aWR0aCBtdXN0IGJlIGZpbml0ZScpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFwcmVjaXNpb24pIHtcbiAgICAgICAgICAgIHByZWNpc2lvbiA9ICdmRmVFJy5pbmRleE9mKHR5cGUpID4gLTEgPyA2IDogKHR5cGUgPT0gJ2QnKSA/IDAgOiB2b2lkKDApO1xuICAgICAgICB9IGVsc2UgaWYgKHByZWNpc2lvbiA9PSAnKicpIHtcbiAgICAgICAgICAgIHByZWNpc2lvbiA9ICthW2krK107XG4gICAgICAgIH0gZWxzZSBpZiAocHJlY2lzaW9uLmNoYXJBdCgwKSA9PSAnKicpIHtcbiAgICAgICAgICAgIHByZWNpc2lvbiA9ICthW3ByZWNpc2lvbi5zbGljZSgxLCAtMSldO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcHJlY2lzaW9uID0gK3ByZWNpc2lvbjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGdyYWIgdmFsdWUgdXNpbmcgdmFsdWVJbmRleCBpZiByZXF1aXJlZD9cbiAgICAgICAgdmFsdWUgPSB2YWx1ZUluZGV4ID8gYVt2YWx1ZUluZGV4LnNsaWNlKDAsIC0xKV0gOiBhW2krK107XG5cbiAgICAgICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgICAgICBjYXNlICdzJzogcmV0dXJuIGZvcm1hdFN0cmluZyhTdHJpbmcodmFsdWUpLCBsZWZ0SnVzdGlmeSwgbWluV2lkdGgsIHByZWNpc2lvbiwgemVyb1BhZCwgY3VzdG9tUGFkQ2hhcik7XG4gICAgICAgICAgICBjYXNlICdjJzogcmV0dXJuIGZvcm1hdFN0cmluZyhTdHJpbmcuZnJvbUNoYXJDb2RlKCt2YWx1ZSksIGxlZnRKdXN0aWZ5LCBtaW5XaWR0aCwgcHJlY2lzaW9uLCB6ZXJvUGFkKTtcbiAgICAgICAgICAgIGNhc2UgJ2InOiByZXR1cm4gZm9ybWF0QmFzZVgodmFsdWUsIDIsIHByZWZpeEJhc2VYLCBsZWZ0SnVzdGlmeSwgbWluV2lkdGgsIHByZWNpc2lvbiwgemVyb1BhZCk7XG4gICAgICAgICAgICBjYXNlICdvJzogcmV0dXJuIGZvcm1hdEJhc2VYKHZhbHVlLCA4LCBwcmVmaXhCYXNlWCwgbGVmdEp1c3RpZnksIG1pbldpZHRoLCBwcmVjaXNpb24sIHplcm9QYWQpO1xuICAgICAgICAgICAgY2FzZSAneCc6IHJldHVybiBmb3JtYXRCYXNlWCh2YWx1ZSwgMTYsIHByZWZpeEJhc2VYLCBsZWZ0SnVzdGlmeSwgbWluV2lkdGgsIHByZWNpc2lvbiwgemVyb1BhZCk7XG4gICAgICAgICAgICBjYXNlICdYJzogcmV0dXJuIGZvcm1hdEJhc2VYKHZhbHVlLCAxNiwgcHJlZml4QmFzZVgsIGxlZnRKdXN0aWZ5LCBtaW5XaWR0aCwgcHJlY2lzaW9uLCB6ZXJvUGFkKS50b1VwcGVyQ2FzZSgpO1xuICAgICAgICAgICAgY2FzZSAndSc6IHJldHVybiBmb3JtYXRCYXNlWCh2YWx1ZSwgMTAsIHByZWZpeEJhc2VYLCBsZWZ0SnVzdGlmeSwgbWluV2lkdGgsIHByZWNpc2lvbiwgemVyb1BhZCk7XG4gICAgICAgICAgICBjYXNlICdpJzpcbiAgICAgICAgICAgIGNhc2UgJ2QnOiB7XG4gICAgICAgICAgICAgICAgbnVtYmVyID0gcGFyc2VJbnQoK3ZhbHVlKTtcbiAgICAgICAgICAgICAgICBwcmVmaXggPSBudW1iZXIgPCAwID8gJy0nIDogcG9zaXRpdmVQcmVmaXg7XG4gICAgICAgICAgICAgICAgdmFsdWUgPSBwcmVmaXggKyBwYWQoU3RyaW5nKE1hdGguYWJzKG51bWJlcikpLCBwcmVjaXNpb24sICcwJywgZmFsc2UpO1xuICAgICAgICAgICAgICAgIHJldHVybiBqdXN0aWZ5KHZhbHVlLCBwcmVmaXgsIGxlZnRKdXN0aWZ5LCBtaW5XaWR0aCwgemVyb1BhZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXNlICdlJzpcbiAgICAgICAgICAgIGNhc2UgJ0UnOlxuICAgICAgICAgICAgY2FzZSAnZic6XG4gICAgICAgICAgICBjYXNlICdGJzpcbiAgICAgICAgICAgIGNhc2UgJ2cnOlxuICAgICAgICAgICAgY2FzZSAnRyc6IHtcbiAgICAgICAgICAgICAgICBudW1iZXIgPSArdmFsdWU7XG4gICAgICAgICAgICAgICAgcHJlZml4ID0gbnVtYmVyIDwgMCA/ICctJyA6IHBvc2l0aXZlUHJlZml4O1xuICAgICAgICAgICAgICAgIG1ldGhvZCA9IFsndG9FeHBvbmVudGlhbCcsICd0b0ZpeGVkJywgJ3RvUHJlY2lzaW9uJ11bJ2VmZycuaW5kZXhPZih0eXBlLnRvTG93ZXJDYXNlKCkpXTtcbiAgICAgICAgICAgICAgICB0ZXh0VHJhbnNmb3JtID0gWyd0b1N0cmluZycsICd0b1VwcGVyQ2FzZSddWydlRWZGZ0cnLmluZGV4T2YodHlwZSkgJSAyXTtcbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHByZWZpeCArIE1hdGguYWJzKG51bWJlcilbbWV0aG9kXShwcmVjaXNpb24pO1xuICAgICAgICAgICAgICAgIHJldHVybiBqdXN0aWZ5KHZhbHVlLCBwcmVmaXgsIGxlZnRKdXN0aWZ5LCBtaW5XaWR0aCwgemVyb1BhZClbdGV4dFRyYW5zZm9ybV0oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlZmF1bHQ6IHJldHVybiBzdWJzdHJpbmc7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgcmV0dXJuIGZvcm1hdC5yZXBsYWNlKHJlZ2V4LCBkb0Zvcm1hdCk7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbnZhciBzcGxpdFRhYmxlQnJlYWtQb2ludCA9IDk5MTtcbiQoZG9jdW1lbnQpLnJlYWR5KGZ1bmN0aW9uKCkge1xuICAgIFxuICAgIC8vICQoXCJ0YWJsZVwiKS5hZGRDbGFzcyhcInJlc3BvbnNpdmVcIik7XG4gICAgJChcInRhYmxlLnJlc3BvbnNpdmUgdGQgYnJcIikucmVtb3ZlKCk7IFxuICAgIHZhciBzd2l0Y2hlZCA9IGZhbHNlO1xuICAgIHZhciB1cGRhdGVUYWJsZXMgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKCgkKHdpbmRvdykud2lkdGgoKSA8IHNwbGl0VGFibGVCcmVha1BvaW50KSAmJiAhc3dpdGNoZWQpIHtcbiAgICAgICAgICAgIHN3aXRjaGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICQoXCJ0YWJsZS5yZXNwb25zaXZlXCIpLmVhY2goZnVuY3Rpb24oaSwgZWxlbWVudCkge1xuICAgICAgICAgICAgICAgIHNwbGl0VGFibGUoJChlbGVtZW50KSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9IGVsc2UgaWYgKHN3aXRjaGVkICYmICgkKHdpbmRvdykud2lkdGgoKSA+IHNwbGl0VGFibGVCcmVha1BvaW50KSkge1xuICAgICAgICAgICAgc3dpdGNoZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICQoXCJ0YWJsZS5yZXNwb25zaXZlXCIpLmVhY2goZnVuY3Rpb24oaSwgZWxlbWVudCkge1xuICAgICAgICAgICAgICAgIHVuc3BsaXRUYWJsZSgkKGVsZW1lbnQpKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IFxuICAgIH07XG4gICAgJCh3aW5kb3cpLmxvYWQodXBkYXRlVGFibGVzKTtcbiAgICAkKHdpbmRvdykuYmluZChcInJlc2l6ZVwiLCB1cGRhdGVUYWJsZXMpO1xuICAgIFxuICAgIGZ1bmN0aW9uIHNwbGl0VGFibGUob3JpZ2luYWwpIHtcbiAgICAgICAgb3JpZ2luYWwud3JhcChcIjxkaXYgY2xhc3M9J3RhYmxlLXdyYXBwZXInIC8+XCIpO1xuICAgICAgICBvcmlnaW5hbC5maW5kKFwidHI6bm90KDpmaXJzdC1jaGlsZClcIikuZWFjaChmdW5jdGlvbigpe1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBpZigkKHRoaXMpLmZpbmQoXCJ0ZFwiKS5sZW5ndGggPT09IDEpXG4gICAgICAgICAgICAgICAgJCh0aGlzKS5hcHBlbmQoJzx0ZCBjbGFzcz1cImR1bW15LXRkXCI+Jm5ic3A7PC90ZD4nKTtcbiAgICAgICAgfSlcbiAgICAgICAgdmFyIGNvcHkgPSBvcmlnaW5hbC5jbG9uZSgpO1xuICAgICAgICBjb3B5LmZpbmQoXCJ0ZDpub3QoOmZpcnN0LWNoaWxkKSwgdGg6bm90KDpmaXJzdC1jaGlsZClcIikuY3NzKFwiZGlzcGxheVwiLCBcIm5vbmVcIik7XG4gICAgICAgIGNvcHkucmVtb3ZlQ2xhc3MoXCJyZXNwb25zaXZlXCIpO1xuICAgICAgICBvcmlnaW5hbC5jbG9zZXN0KFwiLnRhYmxlLXdyYXBwZXJcIikuYXBwZW5kKGNvcHkpO1xuICAgICAgICBjb3B5LndyYXAoXCI8ZGl2IGNsYXNzPSdwaW5uZWQnIC8+XCIpO1xuICAgICAgICBvcmlnaW5hbC53cmFwKFwiPGRpdiBjbGFzcz0nc2Nyb2xsYWJsZScgLz5cIik7XG4gICAgfVxuICAgIFxuICAgIGZ1bmN0aW9uIHVuc3BsaXRUYWJsZShvcmlnaW5hbCkge1xuICAgICAgICBvcmlnaW5hbC5jbG9zZXN0KFwiLnRhYmxlLXdyYXBwZXJcIikuZmluZChcIi5waW5uZWRcIikucmVtb3ZlKCk7XG4gICAgICAgIG9yaWdpbmFsLmZpbmQoXCIuZHVtbXktdGRcIikucmVtb3ZlKCk7XG4gICAgICAgIG9yaWdpbmFsLnVud3JhcCgpO1xuICAgIH1cbn0pO1xuXG4kKFwiZG9jdW1lbnRcIikucmVhZHkoZnVuY3Rpb24oKSB7XG4gICAgJCh3aW5kb3cpLnJlc2l6ZShzY3JvbGxJZGVudGl0eSk7XG4gICAgJCh3aW5kb3cpLmxvYWQoc2Nyb2xsSWRlbnRpdHkpO1xuICAgIC8qZG9jdW1lbnQuYm9keS5hZGRFdmVudExpc3RlbmVyKCdET01Ob2RlSW5zZXJ0ZWQnLCBmdW5jdGlvbihldmVudCkge1xuICAgIGlmICgkKGV2ZW50LnJlbGF0ZWROb2RlKS5oYXNDbGFzcyhcInNjcm9sbGFibGVcIikpXG4gICAgc2Nyb2xsSWRlbnRpdHkoKTtcbiAgICB9LCBmYWxzZSk7Ki9cbiAgICBcbiAgICAkKFwiYm9keVwiKS5vbihcImNsaWNrXCIsIFwiZGl2Lmhhc19zY3JvbGxiYXJcIiwgZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBvYmogPSAkKHRoaXMpLnBhcmVudChcIi5zY3JvbGxhYmxlXCIpO1xuICAgICAgICB2YXIgc2Nyb2xsV2kgPSAoJChvYmopWzBdLnNjcm9sbFdpZHRoID49ICQob2JqKVswXS5jbGllbnRXaWR0aCk/ICgkKG9iailbMF0uY2xpZW50V2lkdGggKyAkKG9iailbMF0uc2Nyb2xsTGVmdCkgOiAkKG9iailbMF0uc2Nyb2xsV2lkdGg7XG4gICAgICAgICQob2JqKS5hbmltYXRlKHtzY3JvbGxMZWZ0OnNjcm9sbFdpfSwgNTAwKTtcbiAgICB9KVxufSk7XG5cbmZ1bmN0aW9uIHNjcm9sbElkZW50aXR5KCkge1xuICAgIGlmICgkKHdpbmRvdykud2lkdGgoKSA8IHNwbGl0VGFibGVCcmVha1BvaW50KSB7XG4gICAgICAgICQoXCJkaXYuc2Nyb2xsYWJsZVwiKS5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdmFyIGhhc0hvcml6b250YWxTY3JvbGxiYXIgPSB0aGlzLnNjcm9sbFdpZHRoID4gdGhpcy5jbGllbnRXaWR0aDtcbiAgICAgICAgICAgIGlmIChoYXNIb3Jpem9udGFsU2Nyb2xsYmFyICYmICQodGhpcykuZmluZChcIi5oYXNfc2Nyb2xsYmFyXCIpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgICAgICQodGhpcykuYXBwZW5kKCc8ZGl2IHRpdGxlPVwiSXQgaGFzIHNjcm9sbGFibGUgY29udGVudFwiIGNsYXNzPVwiaGFzX3Njcm9sbGJhclwiPiZyc2FxdW87PHN0eWxlPnRhYmxlLnJlc3BvbnNpdmU+dGJvZHk+dHI+dGQge3doaXRlLXNwYWNlOiBub3dyYXA7fSAuaGFzX3Njcm9sbGJhcntwb3NpdGlvbjphYnNvbHV0ZTtyaWdodDo1cHg7dG9wOjA7LypjYWxjKCgxMDAlIC0gNjNweCkgLyAyKTsqL2ZvbnQtc2l6ZToyZW07Y29sb3I6Z3JheTstd2Via2l0LWFuaW1hdGlvbjpwb3AtbGVmdCAxcyBpbmZpbml0ZTstbW96LWFuaW1hdGlvbjpwb3AtbGVmdCAxcyBpbmZpbml0ZTstby1hbmltYXRpb246cG9wLWxlZnQgMXMgaW5maW5pdGU7YW5pbWF0aW9uOnBvcC1sZWZ0IDFzIGluZmluaXRlfUAtd2Via2l0LWtleWZyYW1lcyBcInBvcC1sZWZ0XCJ7MCV7cmlnaHQ6LTJweDt9NTAle3JpZ2h0OjBweDt9MTAwJXtyaWdodDotMnB4O319QC1tb3ota2V5ZnJhbWVzIFwicG9wLWxlZnRcInswJXtyaWdodDotMnB4O301MCV7cmlnaHQ6MHB4O30xMDAle3JpZ2h0Oi0ycHg7fX1ALW8ta2V5ZnJhbWVzIHBvcC1sZWZ0ezAlIHsgcmlnaHQ6LTJweH01MCV7cmlnaHQ6MHB4fTEwMCV7cmlnaHQ6LTJweH1Aa2V5ZnJhbWVzIFwicG9wLWxlZnRcInswJXtyaWdodDotMnB4O301MCV7cmlnaHQ6MHB4O30xMDAle3JpZ2h0Oi0ycHg7fX08L3N0eWxlPjwvZGl2PicpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgICAkKFwiLmhhc19zY3JvbGxiYXJcIikucmVtb3ZlKFwiLmhhc19zY3JvbGxiYXJcIilcbiAgICB9XG59XG5cbiIsIi8qVGhlIE1JVCBMaWNlbnNlIChNSVQpXG5cbkNvcHlyaWdodCAoYykgMjAxNCBodHRwczovL2dpdGh1Yi5jb20va2F5YWxzaHJpL1xuXG5QZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5XG5vZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZSBcIlNvZnR3YXJlXCIpLCB0byBkZWFsXG5pbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzXG50byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsXG5jb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXNcbmZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbnM6XG5cblRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkIGluXG5hbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cblxuVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTUyBPUlxuSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFksXG5GSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEVcbkFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVJcbkxJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1IgT1RIRVJXSVNFLCBBUklTSU5HIEZST00sXG5PVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOXG5USEUgU09GVFdBUkUuKi9cblxuKGZ1bmN0aW9uKCQpe1xuICAgICQuZm4uZXh0ZW5kKHtcbiAgICAgICAgdGFibGVFeHBvcnQ6IGZ1bmN0aW9uKG9wdGlvbnMpIHtcbiAgICAgICAgICAgIHZhciBkZWZhdWx0cyA9IHtcbiAgICAgICAgICAgICAgICBzZXBhcmF0b3I6ICcsJyxcbiAgICAgICAgICAgICAgICBpZ25vcmVDb2x1bW46IFtdLFxuICAgICAgICAgICAgICAgIHRhYmxlTmFtZToneW91clRhYmxlTmFtZScsXG4gICAgICAgICAgICAgICAgdHlwZTonY3N2JyxcbiAgICAgICAgICAgICAgICBwZGZGb250U2l6ZToxNCxcbiAgICAgICAgICAgICAgICBwZGZMZWZ0TWFyZ2luOjIwLFxuICAgICAgICAgICAgICAgIGVzY2FwZTondHJ1ZScsXG4gICAgICAgICAgICAgICAgaHRtbENvbnRlbnQ6J2ZhbHNlJyxcbiAgICAgICAgICAgICAgICBjb25zb2xlTG9nOidmYWxzZScsXG4gICAgICAgICAgICAgICAgaWQ6XCJcIixcbiAgICAgICAgICAgICAgICBmaWxlTmFtZTpcImV4cG9ydFwiXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB2YXIgb3B0aW9ucyA9ICQuZXh0ZW5kKGRlZmF1bHRzLCBvcHRpb25zKTtcbiAgICAgICAgICAgIHZhciBlbCA9IHRoaXM7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlmKGRlZmF1bHRzLnR5cGUgPT0gJ2NzdicgfHwgZGVmYXVsdHMudHlwZSA9PSAndHh0Jyl7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgLy8gSGVhZGVyXG4gICAgICAgICAgICAgICAgdmFyIHRkRGF0YSA9XCJcIjtcbiAgICAgICAgICAgICAgICAkKGVsKS5maW5kKCd0aGVhZCcpLmZpbmQoJ3RyJykuZWFjaChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgdGREYXRhICs9IFwiXFxuXCI7XHRcdFx0XHRcdFxuICAgICAgICAgICAgICAgICAgICAkKHRoaXMpLmZpbHRlcignOnZpc2libGUnKS5maW5kKCd0aCcpLmVhY2goZnVuY3Rpb24oaW5kZXgsZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCQodGhpcykuY3NzKCdkaXNwbGF5JykgIT0gJ25vbmUnKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZihkZWZhdWx0cy5pZ25vcmVDb2x1bW4uaW5kZXhPZihpbmRleCkgPT0gLTEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZERhdGEgKz0gJ1wiJyArIHBhcnNlU3RyaW5nKCQodGhpcykpICsgJ1wiJyArIGRlZmF1bHRzLnNlcGFyYXRvcjtcdFx0XHRcdFx0XHRcdFx0XHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIHRkRGF0YSA9ICQudHJpbSh0ZERhdGEpO1xuICAgICAgICAgICAgICAgICAgICB0ZERhdGEgPSAkLnRyaW0odGREYXRhKS5zdWJzdHJpbmcoMCwgdGREYXRhLmxlbmd0aCAtMSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgLy8gUm93IHZzIENvbHVtblxuICAgICAgICAgICAgICAgICQoZWwpLmZpbmQoJ3Rib2R5JykuZmluZCgndHInKS5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICB0ZERhdGEgKz0gXCJcXG5cIjtcbiAgICAgICAgICAgICAgICAgICAgJCh0aGlzKS5maWx0ZXIoJzp2aXNpYmxlJykuZmluZCgndGQnKS5lYWNoKGZ1bmN0aW9uKGluZGV4LGRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICgkKHRoaXMpLmNzcygnZGlzcGxheScpICE9ICdub25lJyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYoZGVmYXVsdHMuaWdub3JlQ29sdW1uLmluZGV4T2YoaW5kZXgpID09IC0xKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGREYXRhICs9ICdcIicrIHBhcnNlU3RyaW5nKCQodGhpcykpICsgJ1wiJysgZGVmYXVsdHMuc2VwYXJhdG9yO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIC8vdGREYXRhID0gJC50cmltKHRkRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgIHRkRGF0YSA9ICQudHJpbSh0ZERhdGEpLnN1YnN0cmluZygwLCB0ZERhdGEubGVuZ3RoIC0xKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvL291dHB1dFxuICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmNvbnNvbGVMb2cgPT0gJ3RydWUnKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2codGREYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB2YXIgYmFzZTY0ZGF0YSA9IFwiYmFzZTY0LFwiICsgJC5iYXNlNjQuZW5jb2RlKHRkRGF0YSk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgdmFyIGZpbGVuYW1lPWRlZmF1bHRzLmZpbGVOYW1lK1wiLlwiK2RlZmF1bHRzLnR5cGU7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgaWYgKCB3aW5kb3cubmF2aWdhdG9yLm1zU2F2ZUJsb2IpIHtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICB2YXIgYmxvYiA9IG5ldyBCbG9iKFtkZWNvZGVVUklDb21wb25lbnQodGREYXRhKV0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0ZXh0LycrZGVmYXVsdHMudHlwZSsnO2NoYXJzZXQ9dXRmOCdcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAvLyBDcmFzaGVzIGluIElFIDEwLCBJRSAxMSBhbmQgTWljcm9zb2Z0IEVkZ2VcbiAgICAgICAgICAgICAgICAgICAgLy8gU2VlIE1TIEVkZ2UgSXNzdWUgIzEwMzk2MDMzXG4gICAgICAgICAgICAgICAgICAgIC8vIEhlbmNlLCB0aGUgZGVsaWJlcmF0ZSAnZmFsc2UnXG4gICAgICAgICAgICAgICAgICAgIC8vIFRoaXMgaXMgaGVyZSBqdXN0IGZvciBjb21wbGV0ZW5lc3NcbiAgICAgICAgICAgICAgICAgICAgLy8gUmVtb3ZlIHRoZSAnZmFsc2UnIGF0IHlvdXIgb3duIHJpc2tcbiAgICAgICAgICAgICAgICAgICAgd2luZG93Lm5hdmlnYXRvci5tc1NhdmVCbG9iKGJsb2IsIGZpbGVuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh3aW5kb3cuQmxvYiAmJiB3aW5kb3cuVVJMKSB7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgLy8gSFRNTDUgQmxvYiAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIHZhciBibG9iID0gbmV3IEJsb2IoW3RkRGF0YV0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0ZXh0LycrZGVmYXVsdHMudHlwZSsnO2NoYXJzZXQ9dXRmLTgnXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB2YXIgY3N2VXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgdmFyIGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBhLmhyZWYgPSBjc3ZVcmw7XG4gICAgICAgICAgICAgICAgICAgIC8vc2V0dGluZyB0aGUgZmlsZSBuYW1lXG4gICAgICAgICAgICAgICAgICAgIGEuZG93bmxvYWQgPSBmaWxlbmFtZTtcbiAgICAgICAgICAgICAgICAgICAgLy90cmlnZ2VyaW5nIHRoZSBmdW5jdGlvblxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChhKTtcbiAgICAgICAgICAgICAgICAgICAgYS5jbGljaygpO1xuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGEpO1xuICAgICAgICAgICAgICAgICAgICAvL2EuY2xpY2soKTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgLy8gRGF0YSBVUklcbiAgICAgICAgICAgICAgICAgICAgdmFyIGNzdkRhdGEgPSAnZGF0YTphcHBsaWNhdGlvbi8nK2RlZmF1bHRzLnR5cGUrJztjaGFyc2V0PXV0Zi04LCcgKyBlbmNvZGVVUklDb21wb25lbnQodGREYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICB2YXIgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIGEuaHJlZiA9IGNzdkRhdGE7XG4gICAgICAgICAgICAgICAgICAgIC8vc2V0dGluZyB0aGUgZmlsZSBuYW1lXG4gICAgICAgICAgICAgICAgICAgIGEuZG93bmxvYWQgPSBmaWxlbmFtZTtcbiAgICAgICAgICAgICAgICAgICAgLy90cmlnZ2VyaW5nIHRoZSBmdW5jdGlvblxuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xuICAgICAgICAgICAgICAgICAgICBhLmNsaWNrKCk7XG4gICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoYSk7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIC8vd2luZG93Lm9wZW4oJ2RhdGE6YXBwbGljYXRpb24vJytkZWZhdWx0cy50eXBlKyc7ZmlsZW5hbWU9ZXhwb3J0RGF0YTsnICsgYmFzZTY0ZGF0YSk7XG4gICAgICAgICAgICB9ZWxzZSBpZihkZWZhdWx0cy50eXBlID09ICdzcWwnKXtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvLyBIZWFkZXJcbiAgICAgICAgICAgICAgICB2YXIgdGREYXRhID1cIklOU0VSVCBJTlRPIGBcIitkZWZhdWx0cy50YWJsZU5hbWUrXCJgIChcIjtcbiAgICAgICAgICAgICAgICAkKGVsKS5maW5kKCd0aGVhZCcpLmZpbmQoJ3RyJykuZWFjaChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICQodGhpcykuZmlsdGVyKCc6dmlzaWJsZScpLmZpbmQoJ3RoJykuZWFjaChmdW5jdGlvbihpbmRleCxkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoJCh0aGlzKS5jc3MoJ2Rpc3BsYXknKSAhPSAnbm9uZScpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmlnbm9yZUNvbHVtbi5pbmRleE9mKGluZGV4KSA9PSAtMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRkRGF0YSArPSAnYCcgKyBwYXJzZVN0cmluZygkKHRoaXMpKSArICdgLCcgO1x0XHRcdFx0XHRcdFx0XHRcdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgdGREYXRhID0gJC50cmltKHRkRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgIHRkRGF0YSA9ICQudHJpbSh0ZERhdGEpLnN1YnN0cmluZygwLCB0ZERhdGEubGVuZ3RoIC0xKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0ZERhdGEgKz0gXCIpIFZBTFVFUyBcIjtcbiAgICAgICAgICAgICAgICAvLyBSb3cgdnMgQ29sdW1uXG4gICAgICAgICAgICAgICAgJChlbCkuZmluZCgndGJvZHknKS5maW5kKCd0cicpLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgIHRkRGF0YSArPSBcIihcIjtcbiAgICAgICAgICAgICAgICAgICAgJCh0aGlzKS5maWx0ZXIoJzp2aXNpYmxlJykuZmluZCgndGQnKS5lYWNoKGZ1bmN0aW9uKGluZGV4LGRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICgkKHRoaXMpLmNzcygnZGlzcGxheScpICE9ICdub25lJyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYoZGVmYXVsdHMuaWdub3JlQ29sdW1uLmluZGV4T2YoaW5kZXgpID09IC0xKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGREYXRhICs9ICdcIicrIHBhcnNlU3RyaW5nKCQodGhpcykpICsgJ1wiLCc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIHRkRGF0YSA9ICQudHJpbSh0ZERhdGEpLnN1YnN0cmluZygwLCB0ZERhdGEubGVuZ3RoIC0xKTtcbiAgICAgICAgICAgICAgICAgICAgdGREYXRhICs9IFwiKSxcIjtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB0ZERhdGEgPSAkLnRyaW0odGREYXRhKS5zdWJzdHJpbmcoMCwgdGREYXRhLmxlbmd0aCAtMSk7XG4gICAgICAgICAgICAgICAgdGREYXRhICs9IFwiO1wiO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIC8vb3V0cHV0XG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyh0ZERhdGEpO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmNvbnNvbGVMb2cgPT0gJ3RydWUnKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2codGREYXRhKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgdmFyIGJhc2U2NGRhdGEgPSBcImJhc2U2NCxcIiArICQuYmFzZTY0LmVuY29kZSh0ZERhdGEpO1xuICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuKCdkYXRhOmFwcGxpY2F0aW9uL3NxbDtmaWxlbmFtZT1leHBvcnREYXRhOycgKyBiYXNlNjRkYXRhKTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgIH1lbHNlIGlmKGRlZmF1bHRzLnR5cGUgPT0gJ2pzb24nKXtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB2YXIganNvbkhlYWRlckFycmF5ID0gW107XG4gICAgICAgICAgICAgICAgJChlbCkuZmluZCgndGhlYWQnKS5maW5kKCd0cicpLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciB0ZERhdGEgPVwiXCI7XHRcbiAgICAgICAgICAgICAgICAgICAgdmFyIGpzb25BcnJheVRkID0gW107XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAkKHRoaXMpLmZpbHRlcignOnZpc2libGUnKS5maW5kKCd0aCcpLmVhY2goZnVuY3Rpb24oaW5kZXgsZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCQodGhpcykuY3NzKCdkaXNwbGF5JykgIT0gJ25vbmUnKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZihkZWZhdWx0cy5pZ25vcmVDb2x1bW4uaW5kZXhPZihpbmRleCkgPT0gLTEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqc29uQXJyYXlUZC5wdXNoKHBhcnNlU3RyaW5nKCQodGhpcykpKTtcdFx0XHRcdFx0XHRcdFx0XHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pO1x0XHRcdFx0XHRcdFx0XHRcdFxuICAgICAgICAgICAgICAgICAgICBqc29uSGVhZGVyQXJyYXkucHVzaChqc29uQXJyYXlUZCk7XHRcdFx0XHRcdFx0XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHZhciBqc29uQXJyYXkgPSBbXTtcbiAgICAgICAgICAgICAgICAkKGVsKS5maW5kKCd0Ym9keScpLmZpbmQoJ3RyJykuZWFjaChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHRkRGF0YSA9XCJcIjtcdFxuICAgICAgICAgICAgICAgICAgICB2YXIganNvbkFycmF5VGQgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICQodGhpcykuZmlsdGVyKCc6dmlzaWJsZScpLmZpbmQoJ3RkJykuZWFjaChmdW5jdGlvbihpbmRleCxkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoJCh0aGlzKS5jc3MoJ2Rpc3BsYXknKSAhPSAnbm9uZScpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmlnbm9yZUNvbHVtbi5pbmRleE9mKGluZGV4KSA9PSAtMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGpzb25BcnJheVRkLnB1c2gocGFyc2VTdHJpbmcoJCh0aGlzKSkpO1x0XHRcdFx0XHRcdFx0XHRcdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XHRcdFx0XHRcdFx0XHRcdFx0XG4gICAgICAgICAgICAgICAgICAgIGpzb25BcnJheS5wdXNoKGpzb25BcnJheVRkKTtcdFx0XHRcdFx0XHRcdFx0XHRcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgdmFyIGpzb25FeHBvcnRBcnJheSA9W107XG4gICAgICAgICAgICAgICAganNvbkV4cG9ydEFycmF5LnB1c2goe2hlYWRlcjpqc29uSGVhZGVyQXJyYXksZGF0YTpqc29uQXJyYXl9KTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvL1JldHVybiBhcyBKU09OXG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShqc29uRXhwb3J0QXJyYXkpKTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvL1JldHVybiBhcyBBcnJheVxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coanNvbkV4cG9ydEFycmF5KTtcbiAgICAgICAgICAgICAgICBpZihkZWZhdWx0cy5jb25zb2xlTG9nID09ICd0cnVlJyl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KGpzb25FeHBvcnRBcnJheSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB2YXIgYmFzZTY0ZGF0YSA9IFwiYmFzZTY0LFwiICsgJC5iYXNlNjQuZW5jb2RlKEpTT04uc3RyaW5naWZ5KGpzb25FeHBvcnRBcnJheSkpO1xuICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuKCdkYXRhOmFwcGxpY2F0aW9uL2pzb247ZmlsZW5hbWU9ZXhwb3J0RGF0YTsnICsgYmFzZTY0ZGF0YSk7XG4gICAgICAgICAgICB9ZWxzZSBpZihkZWZhdWx0cy50eXBlID09ICd4bWwnKXtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB2YXIgeG1sID0gJzw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cInV0Zi04XCI/Pic7XG4gICAgICAgICAgICAgICAgeG1sICs9ICc8dGFibGVkYXRhPjxmaWVsZHM+JztcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvLyBIZWFkZXJcbiAgICAgICAgICAgICAgICAkKGVsKS5maW5kKCd0aGVhZCcpLmZpbmQoJ3RyJykuZWFjaChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgJCh0aGlzKS5maWx0ZXIoJzp2aXNpYmxlJykuZmluZCgndGgnKS5lYWNoKGZ1bmN0aW9uKGluZGV4LGRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICgkKHRoaXMpLmNzcygnZGlzcGxheScpICE9ICdub25lJyl7XHRcdFx0XHRcdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmlnbm9yZUNvbHVtbi5pbmRleE9mKGluZGV4KSA9PSAtMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHhtbCArPSBcIjxmaWVsZD5cIiArIHBhcnNlU3RyaW5nKCQodGhpcykpICsgXCI8L2ZpZWxkPlwiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XHRcdFx0XHRcdFx0XHRcdFx0XG4gICAgICAgICAgICAgICAgfSk7XHRcdFx0XHRcdFxuICAgICAgICAgICAgICAgIHhtbCArPSAnPC9maWVsZHM+PGRhdGE+JztcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvLyBSb3cgVnMgQ29sdW1uXG4gICAgICAgICAgICAgICAgdmFyIHJvd0NvdW50PTE7XG4gICAgICAgICAgICAgICAgJChlbCkuZmluZCgndGJvZHknKS5maW5kKCd0cicpLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgIHhtbCArPSAnPHJvdyBpZD1cIicrcm93Q291bnQrJ1wiPic7XG4gICAgICAgICAgICAgICAgICAgIHZhciBjb2xDb3VudD0wO1xuICAgICAgICAgICAgICAgICAgICAkKHRoaXMpLmZpbHRlcignOnZpc2libGUnKS5maW5kKCd0ZCcpLmVhY2goZnVuY3Rpb24oaW5kZXgsZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCQodGhpcykuY3NzKCdkaXNwbGF5JykgIT0gJ25vbmUnKXtcdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmlnbm9yZUNvbHVtbi5pbmRleE9mKGluZGV4KSA9PSAtMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHhtbCArPSBcIjxjb2x1bW4tXCIrY29sQ291bnQrXCI+XCIrcGFyc2VTdHJpbmcoJCh0aGlzKSkrXCI8L2NvbHVtbi1cIitjb2xDb3VudCtcIj5cIjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xDb3VudCsrO1xuICAgICAgICAgICAgICAgICAgICB9KTtcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcbiAgICAgICAgICAgICAgICAgICAgcm93Q291bnQrKztcbiAgICAgICAgICAgICAgICAgICAgeG1sICs9ICc8L3Jvdz4nO1xuICAgICAgICAgICAgICAgIH0pO1x0XHRcdFx0XHRcbiAgICAgICAgICAgICAgICB4bWwgKz0gJzwvZGF0YT48L3RhYmxlZGF0YT4nXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgaWYoZGVmYXVsdHMuY29uc29sZUxvZyA9PSAndHJ1ZScpe1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh4bWwpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB2YXIgYmFzZTY0ZGF0YSA9IFwiYmFzZTY0LFwiICsgJC5iYXNlNjQuZW5jb2RlKHhtbCk7XG4gICAgICAgICAgICAgICAgd2luZG93Lm9wZW4oJ2RhdGE6YXBwbGljYXRpb24veG1sO2ZpbGVuYW1lPWV4cG9ydERhdGE7JyArIGJhc2U2NGRhdGEpO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgfWVsc2UgaWYoZGVmYXVsdHMudHlwZSA9PSAnZXhjZWwnIHx8IGRlZmF1bHRzLnR5cGUgPT0gJ2RvYyd8fCBkZWZhdWx0cy50eXBlID09ICdwb3dlcnBvaW50JyAgKXtcbiAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKCQodGhpcykuaHRtbCgpKTtcbiAgICAgICAgICAgICAgICB2YXIgZXhjZWw9XCI8dGFibGU+XCI7XG4gICAgICAgICAgICAgICAgLy8gSGVhZGVyXG4gICAgICAgICAgICAgICAgJChlbCkuZmluZCgndGhlYWQnKS5maW5kKCd0cicpLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgIGV4Y2VsICs9IFwiPHRyPlwiO1xuICAgICAgICAgICAgICAgICAgICAkKHRoaXMpLmZpbHRlcignOnZpc2libGUnKS5maW5kKCd0aCcpLmVhY2goZnVuY3Rpb24oaW5kZXgsZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCQodGhpcykuY3NzKCdkaXNwbGF5JykgIT0gJ25vbmUnKXtcdFx0XHRcdFx0XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYoZGVmYXVsdHMuaWdub3JlQ29sdW1uLmluZGV4T2YoaW5kZXgpID09IC0xKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhjZWwgKz0gXCI8dGQ+XCIgKyBwYXJzZVN0cmluZygkKHRoaXMpKSsgXCI8L3RkPlwiO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XHRcbiAgICAgICAgICAgICAgICAgICAgZXhjZWwgKz0gJzwvdHI+JztcdFx0XHRcdFx0XHRcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgfSk7XHRcdFx0XHRcdFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIC8vIFJvdyBWcyBDb2x1bW5cbiAgICAgICAgICAgICAgICB2YXIgcm93Q291bnQ9MTtcbiAgICAgICAgICAgICAgICAkKGVsKS5maW5kKCd0Ym9keScpLmZpbmQoJ3RyJykuZWFjaChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgZXhjZWwgKz0gXCI8dHI+XCI7XG4gICAgICAgICAgICAgICAgICAgIHZhciBjb2xDb3VudD0wO1xuICAgICAgICAgICAgICAgICAgICAkKHRoaXMpLmZpbHRlcignOnZpc2libGUnKS5maW5kKCd0ZCcpLmVhY2goZnVuY3Rpb24oaW5kZXgsZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCQodGhpcykuY3NzKCdkaXNwbGF5JykgIT0gJ25vbmUnKXtcdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmlnbm9yZUNvbHVtbi5pbmRleE9mKGluZGV4KSA9PSAtMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4Y2VsICs9IFwiPHRkPlwiK3BhcnNlU3RyaW5nKCQodGhpcykpK1wiPC90ZD5cIjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xDb3VudCsrO1xuICAgICAgICAgICAgICAgICAgICB9KTtcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcbiAgICAgICAgICAgICAgICAgICAgcm93Q291bnQrKztcbiAgICAgICAgICAgICAgICAgICAgZXhjZWwgKz0gJzwvdHI+JztcbiAgICAgICAgICAgICAgICB9KTtcdFx0XHRcdFx0XG4gICAgICAgICAgICAgICAgZXhjZWwgKz0gJzwvdGFibGU+J1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmNvbnNvbGVMb2cgPT0gJ3RydWUnKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXhjZWwpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB2YXIgZXhjZWxGaWxlID0gXCI8aHRtbCB4bWxuczpvPSd1cm46c2NoZW1hcy1taWNyb3NvZnQtY29tOm9mZmljZTpvZmZpY2UnIHhtbG5zOng9J3VybjpzY2hlbWFzLW1pY3Jvc29mdC1jb206b2ZmaWNlOlwiK2RlZmF1bHRzLnR5cGUrXCInIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy9UUi9SRUMtaHRtbDQwJz5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8aGVhZD5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8IS0tW2lmIGd0ZSBtc28gOV0+XCI7XG4gICAgICAgICAgICAgICAgZXhjZWxGaWxlICs9IFwiPHhtbD5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8eDpFeGNlbFdvcmtib29rPlwiO1xuICAgICAgICAgICAgICAgIGV4Y2VsRmlsZSArPSBcIjx4OkV4Y2VsV29ya3NoZWV0cz5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8eDpFeGNlbFdvcmtzaGVldD5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8eDpOYW1lPlwiO1xuICAgICAgICAgICAgICAgIGV4Y2VsRmlsZSArPSBcInt3b3Jrc2hlZXR9XCI7XG4gICAgICAgICAgICAgICAgZXhjZWxGaWxlICs9IFwiPC94Ok5hbWU+XCI7XG4gICAgICAgICAgICAgICAgZXhjZWxGaWxlICs9IFwiPHg6V29ya3NoZWV0T3B0aW9ucz5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8eDpEaXNwbGF5R3JpZGxpbmVzLz5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8L3g6V29ya3NoZWV0T3B0aW9ucz5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8L3g6RXhjZWxXb3Jrc2hlZXQ+XCI7XG4gICAgICAgICAgICAgICAgZXhjZWxGaWxlICs9IFwiPC94OkV4Y2VsV29ya3NoZWV0cz5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8L3g6RXhjZWxXb3JrYm9vaz5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8L3htbD5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8IVtlbmRpZl0tLT5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8L2hlYWQ+XCI7XG4gICAgICAgICAgICAgICAgZXhjZWxGaWxlICs9IFwiPGJvZHk+XCI7XG4gICAgICAgICAgICAgICAgZXhjZWxGaWxlICs9IGV4Y2VsO1xuICAgICAgICAgICAgICAgIGV4Y2VsRmlsZSArPSBcIjwvYm9keT5cIjtcbiAgICAgICAgICAgICAgICBleGNlbEZpbGUgKz0gXCI8L2h0bWw+XCI7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgdmFyIGJhc2U2NGRhdGEgPSBcImJhc2U2NCxcIiArICQuYmFzZTY0LmVuY29kZShleGNlbEZpbGUpO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHZhciBjc3ZEYXRhID0gJ2RhdGE6YXBwbGljYXRpb24vdm5kLm1zLScgKyBkZWZhdWx0cy50eXBlICsgJztmaWxlbmFtZT1leHBvcnREYXRhLmRvYzsnICsgYmFzZTY0ZGF0YTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB2YXIgZmlsZU5hbWUgPSBkZWZhdWx0cy5maWxlTmFtZTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBpZiAoIHdpbmRvdy5uYXZpZ2F0b3IubXNTYXZlQmxvYikge1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgaWYoZGVmYXVsdHMudHlwZT09J2V4Y2VsJyl7XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lID0gZmlsZU5hbWUrXCIueGxzXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBpZihkZWZhdWx0cy50eXBlPT0nZG9jJyl7XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbGVOYW1lID0gZmlsZU5hbWUrXCIuZG9jXCI7XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgdmFyIGJsb2IgPSBuZXcgQmxvYihbZGVjb2RlVVJJQ29tcG9uZW50KGV4Y2VsRmlsZSldLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAgJ2RhdGE6YXBwbGljYXRpb24vdm5kLm1zLScgKyBkZWZhdWx0cy50eXBlKyc7Y2hhcnNldD11dGY4J1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIC8vIENyYXNoZXMgaW4gSUUgMTAsIElFIDExIGFuZCBNaWNyb3NvZnQgRWRnZVxuICAgICAgICAgICAgICAgICAgICAvLyBTZWUgTVMgRWRnZSBJc3N1ZSAjMTAzOTYwMzNcbiAgICAgICAgICAgICAgICAgICAgLy8gSGVuY2UsIHRoZSBkZWxpYmVyYXRlICdmYWxzZSdcbiAgICAgICAgICAgICAgICAgICAgLy8gVGhpcyBpcyBoZXJlIGp1c3QgZm9yIGNvbXBsZXRlbmVzc1xuICAgICAgICAgICAgICAgICAgICAvLyBSZW1vdmUgdGhlICdmYWxzZScgYXQgeW91ciBvd24gcmlza1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cubmF2aWdhdG9yLm1zU2F2ZUJsb2IoYmxvYiwgZmlsZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB9ZWxzZXsgXG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBpZihkZWZhdWx0cy50eXBlPT0nZXhjZWwnKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsZU5hbWUgPSBmaWxlTmFtZStcIi54bHNcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLnR5cGU9PSdkb2MnKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsZU5hbWUgPSBmaWxlTmFtZStcIi5kb2NcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgdmFyIGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIGEuaHJlZiA9IGNzdkRhdGE7XG4gICAgICAgICAgICAgICAgICAgIC8vc2V0dGluZyB0aGUgZmlsZSBuYW1lXG4gICAgICAgICAgICAgICAgICAgIGEuZG93bmxvYWQgPSBmaWxlTmFtZTtcbiAgICAgICAgICAgICAgICAgICAgLy90cmlnZ2VyaW5nIHRoZSBmdW5jdGlvblxuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xuICAgICAgICAgICAgICAgICAgICBhLmNsaWNrKCk7XG4gICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoYSk7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvL3dpbmRvdy5vcGVuKCdkYXRhOmFwcGxpY2F0aW9uL3ZuZC5tcy0nK2RlZmF1bHRzLnR5cGUrJztmaWxlbmFtZT1leHBvcnREYXRhLmRvYzsnICsgYmFzZTY0ZGF0YSk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICB9ZWxzZSBpZihkZWZhdWx0cy50eXBlID09ICdwbmcnKXtcbiAgICAgICAgICAgICAgICBodG1sMmNhbnZhcygkKGVsKSwge1xuICAgICAgICAgICAgICAgICAgICBvbnJlbmRlcmVkOiBmdW5jdGlvbihjYW52YXMpIHtcdFx0XHRcdFx0XHRcdFx0XHRcdFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGltZyA9IGNhbnZhcy50b0RhdGFVUkwoXCJpbWFnZS9wbmdcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cub3BlbihpbWcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1x0XHRcbiAgICAgICAgICAgIH1lbHNlIGlmKGRlZmF1bHRzLnR5cGUgPT0gJ3BkZicpe1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHZhciBkb2MgPSBuZXcganNQREYoJ3AnLCdwdCcsICdhNCcsIHRydWUpO1xuICAgICAgICAgICAgICAgIGRvYy5zZXRGb250U2l6ZShkZWZhdWx0cy5wZGZGb250U2l6ZSk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgLy8gSGVhZGVyXG4gICAgICAgICAgICAgICAgdmFyIHN0YXJ0Q29sUG9zaXRpb249ZGVmYXVsdHMucGRmTGVmdE1hcmdpbjtcbiAgICAgICAgICAgICAgICAkKGVsKS5maW5kKCd0aGVhZCcpLmZpbmQoJ3RyJykuZWFjaChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgJCh0aGlzKS5maWx0ZXIoJzp2aXNpYmxlJykuZmluZCgndGgnKS5lYWNoKGZ1bmN0aW9uKGluZGV4LGRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICgkKHRoaXMpLmNzcygnZGlzcGxheScpICE9ICdub25lJyl7XHRcdFx0XHRcdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmlnbm9yZUNvbHVtbi5pbmRleE9mKGluZGV4KSA9PSAtMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjb2xQb3NpdGlvbiA9IHN0YXJ0Q29sUG9zaXRpb24rIChpbmRleCAqIDUwKTtcdFx0XHRcdFx0XHRcdFx0XHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZG9jLnRleHQoY29sUG9zaXRpb24sMjAsIHBhcnNlU3RyaW5nKCQodGhpcykpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pO1x0XHRcdFx0XHRcdFx0XHRcdFxuICAgICAgICAgICAgICAgIH0pO1x0XHRcdFx0XHRcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvLyBSb3cgVnMgQ29sdW1uXG4gICAgICAgICAgICAgICAgdmFyIHN0YXJ0Um93UG9zaXRpb24gPSAyMDsgdmFyIHBhZ2UgPTE7dmFyIHJvd1Bvc2l0aW9uPTA7XG4gICAgICAgICAgICAgICAgJChlbCkuZmluZCgndGJvZHknKS5maW5kKCd0cicpLmVhY2goZnVuY3Rpb24oaW5kZXgsZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICByb3dDYWxjID0gaW5kZXgrMTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIGlmIChyb3dDYWxjICUgMjYgPT0gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBkb2MuYWRkUGFnZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcGFnZSsrO1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhcnRSb3dQb3NpdGlvbj1zdGFydFJvd1Bvc2l0aW9uKzEwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJvd1Bvc2l0aW9uPShzdGFydFJvd1Bvc2l0aW9uICsgKHJvd0NhbGMgKiAxMCkpIC0gKChwYWdlIC0xKSAqIDI4MCk7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAkKHRoaXMpLmZpbHRlcignOnZpc2libGUnKS5maW5kKCd0ZCcpLmVhY2goZnVuY3Rpb24oaW5kZXgsZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCQodGhpcykuY3NzKCdkaXNwbGF5JykgIT0gJ25vbmUnKXtcdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmlnbm9yZUNvbHVtbi5pbmRleE9mKGluZGV4KSA9PSAtMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjb2xQb3NpdGlvbiA9IHN0YXJ0Q29sUG9zaXRpb24rIChpbmRleCAqIDUwKTtcdFx0XHRcdFx0XHRcdFx0XHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZG9jLnRleHQoY29sUG9zaXRpb24scm93UG9zaXRpb24sIHBhcnNlU3RyaW5nKCQodGhpcykpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgfSk7XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIH0pO1x0XHRcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB2YXIgY3N2RGF0YSA9IGRvYy5vdXRwdXQoJ2RhdGF1cmlzdHJpbmcnKTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB2YXIgZmlsZU5hbWUgPSBkZWZhdWx0cy5maWxlTmFtZTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBpZihkZWZhdWx0cy50eXBlPT0ncGRmJyl7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBmaWxlTmFtZSA9IGZpbGVOYW1lK1wiLnBkZlwiO1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIGlmICggd2luZG93Lm5hdmlnYXRvci5tc1NhdmVCbG9iKSB7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIHZhciBibG9iID0gbmV3IEJsb2IoW10sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICBjc3ZEYXRhKyc7Y2hhcnNldD11dGY4J1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIC8vIENyYXNoZXMgaW4gSUUgMTAsIElFIDExIGFuZCBNaWNyb3NvZnQgRWRnZVxuICAgICAgICAgICAgICAgICAgICAvLyBTZWUgTVMgRWRnZSBJc3N1ZSAjMTAzOTYwMzNcbiAgICAgICAgICAgICAgICAgICAgLy8gSGVuY2UsIHRoZSBkZWxpYmVyYXRlICdmYWxzZSdcbiAgICAgICAgICAgICAgICAgICAgLy8gVGhpcyBpcyBoZXJlIGp1c3QgZm9yIGNvbXBsZXRlbmVzc1xuICAgICAgICAgICAgICAgICAgICAvLyBSZW1vdmUgdGhlICdmYWxzZScgYXQgeW91ciBvd24gcmlza1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cubmF2aWdhdG9yLm1zU2F2ZUJsb2IoYmxvYiwgZmlsZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICB2YXIgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIGEuaHJlZiA9IGNzdkRhdGE7XG4gICAgICAgICAgICAgICAgICAgIC8vc2V0dGluZyB0aGUgZmlsZSBuYW1lXG4gICAgICAgICAgICAgICAgICAgIGEuZG93bmxvYWQgPSBmaWxlTmFtZTtcbiAgICAgICAgICAgICAgICAgICAgLy90cmlnZ2VyaW5nIHRoZSBmdW5jdGlvblxuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xuICAgICAgICAgICAgICAgICAgICBhLmNsaWNrKCk7XG4gICAgICAgICAgICAgICAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoYSk7XG4gICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKGRvYyk7XG4gICAgICAgICAgICAgICAgLy8gT3V0cHV0IGFzIERhdGEgVVJJXG4gICAgICAgICAgICAgICAgLy9kb2Mub3V0cHV0KCdkYXRhdXJpJyk7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgZnVuY3Rpb24gcGFyc2VTdHJpbmcoZGF0YSl7XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgaWYoZGVmYXVsdHMuaHRtbENvbnRlbnQgPT0gJ3RydWUnKXtcbiAgICAgICAgICAgICAgICAgICAgY29udGVudF9kYXRhID0gZGF0YS5odG1sKCkudHJpbSgpO1xuICAgICAgICAgICAgICAgIH1lbHNle1xuICAgICAgICAgICAgICAgICAgICBjb250ZW50X2RhdGEgPSBkYXRhLnRleHQoKS50cmltKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIGlmKGRlZmF1bHRzLmVzY2FwZSA9PSAndHJ1ZScpe1xuICAgICAgICAgICAgICAgICAgICBjb250ZW50X2RhdGEgPSBlc2NhcGUoY29udGVudF9kYXRhKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRlbnRfZGF0YTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIFxuICAgICAgICB9XG4gICAgfSk7XG59KShqUXVlcnkpO1xuXG4iLCIgLy8gUHV0IHN0YXRlcyBpbnRvIGFycmF5XG4gdmFyIHN0YXRlX2FycmF5ID0gW107XG5cbiAkKGRvY3VtZW50KS5yZWFkeShmdW5jdGlvbigpIHtcbiAgICQoJy5yZWdpb24nKS5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICB2YXIgYSA9ICQodGhpcykudGV4dCgpO1xuICAgICBpZiAoJC5pbkFycmF5KGEsIHN0YXRlX2FycmF5KSA9PSAtMSkge1xuICAgICAgIHN0YXRlX2FycmF5LnB1c2goYSk7XG4gICAgIH1cbiAgIH0pO1xuICAgc3RhdGVfYXJyYXkuc29ydCgpO1xuIH0pO1xuXG4gLy8gUHV0IHN0YXRlcyBpbnRvIHNlbGVjdCBsaXN0XG4gJChkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oKSB7XG4gICB2YXIgb3B0aW9uID0gJyc7XG5cbiAgIGZvciAodmFyIGkgPSAwOyBpIDwgc3RhdGVfYXJyYXkubGVuZ3RoOyBpKyspIHtcbiAgICAgb3B0aW9uICs9ICc8b3B0aW9uIHZhbHVlPVwiJyArIHN0YXRlX2FycmF5W2ldICsgJ1wiPicgKyBzdGF0ZV9hcnJheVtpXSArICc8L29wdGlvbj4nO1xuICAgfVxuXG4gICAkKCcuc3RhdGVfc2VsZWN0JykuYXBwZW5kKG9wdGlvbik7XG5cbiB9KTtcblxuIC8vIENsZWFyIHNlbGVjdGlvblxuICQoJy5idG4tY2xlYXInKS5jbGljayhmdW5jdGlvbigpIHtcbiAgICQoJyNzb3J0aW5nX3RhYmxlIHRyJykuc2hvdygpO1xuIH0pO1xuXG4gLy8gRmlsdGVyIHRhYmxlIGJhc2VkIG9uIHVzZXIgaW5wdXRcbiAkKCcuc3RhdGVfc2VsZWN0JykuY2hhbmdlKGZ1bmN0aW9uKCkge1xuXG4gICAkKCcjc29ydGluZ190YWJsZSB0cicpLnNob3coKTtcblxuICAgdmFyIHN0YXRlX2NvZGUgPSAkKHRoaXMpLnZhbCgpO1xuXG4gICAkKCcucmVnaW9uJykuZWFjaChmdW5jdGlvbigpIHtcblxuICAgICBpZiAoJCh0aGlzKS50ZXh0KCkgIT0gc3RhdGVfY29kZSkge1xuICAgICAgICQodGhpcykuY2xvc2VzdChcInRyXCIpLmhpZGUoKTtcbiAgICAgfVxuXG4gICB9KTtcbiB9KTtcblxuICQoJ3RoJykuY2xpY2soZnVuY3Rpb24oKSB7ICBcbiAgIHZhciB0YWJsZSA9ICAkKHRoaXMpLnBhcmVudHMoJ3RhYmxlJykuZXEoMCk7XG4gICB2YXIgcm93cyA9IHRhYmxlLmZpbmQoJ3RyOmd0KDApJykudG9BcnJheSgpLnNvcnQoY29tcGFyZXIoJCh0aGlzKS5pbmRleCgpKSlcbiAgIHRoaXMuYXNjID0gIXRoaXMuYXNjOyAgIFxuICAgaWYgKCF0aGlzLmFzYykge1xuICAgICByb3dzID0gcm93cy5yZXZlcnNlKCk7XG4gICB9ICAgXG4gICBmb3IgKHZhciBpID0gMDsgaSA8IHJvd3MubGVuZ3RoOyBpKyspIHtcbiAgICAgdGFibGUuYXBwZW5kKHJvd3NbaV0pO1xuICAgfVxuIH0pXG5cbiBmdW5jdGlvbiBjb21wYXJlcihpbmRleCkgeyAgXG4gICByZXR1cm4gZnVuY3Rpb24oYSwgYikgeyAgICAgIFxuICAgICB2YXIgdmFsQSA9IGdldENlbGxWYWx1ZShhLCBpbmRleCksIHZhbEIgPSBnZXRDZWxsVmFsdWUoYiwgaW5kZXgpO1xuICAgICByZXR1cm4gJC5pc051bWVyaWModmFsQSkgJiYgJC5pc051bWVyaWModmFsQikgPyAgdmFsQSAtIHZhbEIgIDogdmFsQS5sb2NhbGVDb21wYXJlKHZhbEIpIDsgXG4gICB9XG4gfVxuXG4gZnVuY3Rpb24gZ2V0Q2VsbFZhbHVlKHJvdywgaW5kZXgpIHtcbiAgIHJldHVybiAkKHJvdykuY2hpbGRyZW4oJ3RkJykuZXEoaW5kZXgpLmh0bWwoKTtcbiB9XG4gXG4gLy8gR2V0IHVzZXIgaW5wdXQgdG8gc2VhcmNoIGZvciBzdHJpbmdcbiQoXCIuaW5wdXRcIikua2V5dXAoZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIGRhdGEgPSB0aGlzLnZhbHVlLnRvVXBwZXJDYXNlKCkuc3BsaXQoXCIgXCIpO1xuICAgICAgdmFyIGpvID0gJChcIiNzb3J0aW5nX3RhYmxlX2xpc3RcIikuZmluZChcInRyXCIpO1xuICAgICAgaWYgKHRoaXMudmFsdWUgPT0gXCJcIikge1xuICAgICAgICAgIGpvLnNob3coKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBqby5oaWRlKCk7XG5cbiAgICAgIGpvLmZpbHRlcihmdW5jdGlvbiAoaSwgdikge1xuICAgICAgICAgIHZhciAkdCA9ICQodGhpcyk7XG4gICAgICAgICAgZm9yICh2YXIgZCA9IDA7IGQgPCBkYXRhLmxlbmd0aDsgKytkKSB7XG4gICAgICAgICAgICAgIGlmICgkdC50ZXh0KCkudG9VcHBlckNhc2UoKS5pbmRleE9mKGRhdGFbZF0pID4gLTEpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH0pXG4gICAgICAuc2hvdygpO1xuICB9KS5mb2N1cyhmdW5jdGlvbiAoKSB7XG4gICAgICB0aGlzLnZhbHVlID0gXCJcIjtcbiAgICAgICQodGhpcykuY3NzKHtcbiAgICAgICAgICBcImNvbG9yXCI6IFwiYmxhY2tcIlxuICAgICAgfSk7XG4gICAgICAkKHRoaXMpLnVuYmluZCgnZm9jdXMnKTtcbiAgfSkuY3NzKHtcbiAgICAgIFwiY29sb3JcIjogXCIjQzBDMEMwXCJcbiAgfSk7IiwiLypTVEFSVDogVGFiIGNsaWNrIGV2ZW50IGhhbmRsZXIqL1xuICAgICQoZG9jdW1lbnQpLm9uKFwiY2xpY2tcIiwgXCJ0YWItbmF2IHVsIGxpXCIsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgJCh0aGlzKS5jbG9zZXN0KFwidGFiXCIpLmZpbmQoXCIubHBfX3RhYl9hY3RpdmVcIikucmVtb3ZlQ2xhc3MoXCJscF9fdGFiX2FjdGl2ZVwiKTtcbiAgICAgICAgJCh0aGlzKS5maW5kKFwiYVwiKS5hZGRDbGFzcyhcImxwX190YWJfYWN0aXZlXCIpO1xuICAgICAgICAkKHRoaXMpLmNsb3Nlc3QoXCJ0YWJcIikuZmluZChcInRhYi1jb250ZW50IHVsLmxwX190YWJfY29udGVudF9saXN0PmxpXCIpLmVxKCQodGhpcykuaW5kZXgoKSkuYWRkQ2xhc3MoXCJscF9fdGFiX2FjdGl2ZVwiKTtcbiAgICB9KTtcbiAgICAvKkVORDogVGFiIGNsaWNrIGV2ZW50IGhhbmRsZXIqL1xuXG52YXIgc2NyZWVuV2lkdGggPSA2MDA7XG4gICAgLypTVEFSVDogU2Nyb2xsYWJsZSB0YWJzIGNvbnRyb2xsZXIqL1xuaWYgKCQod2luZG93KS53aWR0aCgpID4gc2NyZWVuV2lkdGgpIHtcbiAgICB2YXIgaGlkV2lkdGg7XG4gICAgdmFyIHNjcm9sbEJhcldpZHRocyA9IDA7XG5cbiAgICB2YXIgd2lkdGhPZkxpc3QgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGl0ZW1zV2lkdGggPSAwO1xuICAgICAgICAkKCcubHBfX2xpc3QgbGknKS5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdmFyIGl0ZW1XaWR0aCA9ICQodGhpcykub3V0ZXJXaWR0aCgpO1xuICAgICAgICAgICAgaXRlbXNXaWR0aCArPSBpdGVtV2lkdGg7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gaXRlbXNXaWR0aDtcbiAgICB9O1xuICAgIHZhciBnZXRMZWZ0UG9zaSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gJCgnLmxwX19saXN0JykucG9zaXRpb24oKS5sZWZ0O1xuICAgIH07XG5cbiAgICB2YXIgd2lkdGhPZlJpZ2h0SGlkZGVuID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiAoKCQoJy5scF9fd3JhcHBlcicpLm91dGVyV2lkdGgoKSkgLSB3aWR0aE9mTGlzdCgpIC0gZ2V0TGVmdFBvc2koKSkgLSBzY3JvbGxCYXJXaWR0aHM7XG4gICAgfTtcbiAgICB2YXIgcmVBZGp1c3QgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKCgkKCcubHBfX3dyYXBwZXInKS5vdXRlcldpZHRoKCkpIDwgd2lkdGhPZkxpc3QoKSkge1xuICAgICAgICAgICAgJCgnLmxwX19zY3JvbGxlci1yaWdodCcpLnNob3coKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICQoJy5scF9fc2Nyb2xsZXItcmlnaHQnKS5oaWRlKCk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoZ2V0TGVmdFBvc2koKSA8IDApIHtcbiAgICAgICAgICAgICQoJy5scF9fc2Nyb2xsZXItbGVmdCcpLnNob3coKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICQoJy5pdGVtJykuYW5pbWF0ZSh7XG4gICAgICAgICAgICAgICAgbGVmdDogXCItPVwiICsgZ2V0TGVmdFBvc2koKSArIFwicHhcIlxuICAgICAgICAgICAgfSwgJ3Nsb3cnKTtcbiAgICAgICAgICAgICQoJy5scF9fc2Nyb2xsZXItbGVmdCcpLmhpZGUoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJlQWRqdXN0KCk7XG5cbiAgICAkKHdpbmRvdykub24oJ3Jlc2l6ZScsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgcmVBZGp1c3QoKTtcbiAgICB9KTtcblxuICAgICQoJy5scF9fc2Nyb2xsZXItcmlnaHQnKS5jbGljayhmdW5jdGlvbigpIHtcbiAgICAgICAgXG4gICAgICAgICQoJy5scF9fc2Nyb2xsZXItbGVmdCcpLmZhZGVJbignc2xvdycpO1xuXG4gICAgICAgIHZhciBzY3JvbGxXaWR0aCA9ICQoJy5scF9fd3JhcHBlcicpLm91dGVyV2lkdGgoKSAtIDIwMDtcblxuICAgICAgICBpZiAoc2Nyb2xsV2lkdGggPj0gTWF0aC5hYnMod2lkdGhPZlJpZ2h0SGlkZGVuKCkpKVxuICAgICAgICAgICAgc2Nyb2xsV2lkdGggPSBNYXRoLmFicyh3aWR0aE9mUmlnaHRIaWRkZW4oKSkgKyA3NTtcblxuXG4gICAgICAgIGlmICh3aWR0aE9mUmlnaHRIaWRkZW4oKSA8PSAwKSB7XG4gICAgICAgICAgICBzY3JvbGxXaWR0aCA9IC1NYXRoLmFicyhzY3JvbGxXaWR0aCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAkKCcubHBfX3Njcm9sbGVyLXJpZ2h0JykuZmFkZU91dCgnc2xvdycpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgICQoJy5scF9fbGlzdCcpLmFuaW1hdGUoe1xuICAgICAgICAgICAgbGVmdDogXCIrPVwiICsgc2Nyb2xsV2lkdGggKyBcInB4XCJcbiAgICAgICAgfSwgJ3Nsb3cnLCBmdW5jdGlvbigpIHt9KTtcblxuXG5cbiAgICB9KTtcblxuICAgICQoJy5scF9fc2Nyb2xsZXItbGVmdCcpLmNsaWNrKGZ1bmN0aW9uKCkge1xuICAgICAgICBcbiAgICAgICAgJCgnLmxwX19zY3JvbGxlci1yaWdodCcpLmZhZGVJbignc2xvdycpO1xuICAgICAgICB2YXIgc2Nyb2xsV2lkdGggPSAkKCcubHBfX3dyYXBwZXInKS5vdXRlcldpZHRoKCkgLSAxMDA7XG5cbiAgICAgICAgaWYgKE1hdGguYWJzKCQoXCIubHBfX2xpc3RcIikucG9zaXRpb24oKS5sZWZ0KSA+PSAoc2Nyb2xsV2lkdGgpKVxuICAgICAgICAgICAgc2Nyb2xsV2lkdGggPSAkKFwiLmxwX19saXN0XCIpLnBvc2l0aW9uKCkubGVmdFxuICAgICAgICBlbHNlXG4gICAgICAgICAgICBzY3JvbGxXaWR0aCA9ICQoXCIubHBfX2xpc3RcIikucG9zaXRpb24oKS5sZWZ0O1xuICAgICAgICBpZiAoJChcIi5scF9fbGlzdFwiKS5wb3NpdGlvbigpLmxlZnQgPj0gc2Nyb2xsV2lkdGgpXG4gICAgICAgICAgICAkKCcubHBfX3Njcm9sbGVyLWxlZnQnKS5mYWRlT3V0KCdzbG93Jyk7XG5cbiAgICAgICAgJCgnLmxwX19saXN0JykuYW5pbWF0ZSh7XG4gICAgICAgICAgICBsZWZ0OiBcIi09XCIgKyBzY3JvbGxXaWR0aCArIFwicHhcIlxuICAgICAgICB9LCAnc2xvdycsIGZ1bmN0aW9uKCkge1xuXG4gICAgICAgIH0pO1xuICAgIH0pO1xufVxuICAgIC8qRU5EOiBTY3JvbGxhYmxlIHRhYnMgY29udHJvbGxlciovIiwiXG4rZnVuY3Rpb24gKCQpIHtcbiAgJ3VzZSBzdHJpY3QnO1xuXG4gIGZ1bmN0aW9uIHRyYW5zaXRpb25FbmQoKSB7XG4gICAgdmFyIGVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbG9vcCcpXG5cbiAgICB2YXIgdHJhbnNFbmRFdmVudE5hbWVzID0ge1xuICAgICAgV2Via2l0VHJhbnNpdGlvbiA6ICd3ZWJraXRUcmFuc2l0aW9uRW5kJyxcbiAgICAgIE1velRyYW5zaXRpb24gICAgOiAndHJhbnNpdGlvbmVuZCcsXG4gICAgICBPVHJhbnNpdGlvbiAgICAgIDogJ29UcmFuc2l0aW9uRW5kIG90cmFuc2l0aW9uZW5kJyxcbiAgICAgIHRyYW5zaXRpb24gICAgICAgOiAndHJhbnNpdGlvbmVuZCdcbiAgICB9XG5cbiAgICBmb3IgKHZhciBuYW1lIGluIHRyYW5zRW5kRXZlbnROYW1lcykge1xuICAgICAgaWYgKGVsLnN0eWxlW25hbWVdICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIHsgZW5kOiB0cmFuc0VuZEV2ZW50TmFtZXNbbmFtZV0gfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBmYWxzZSAvLyBleHBsaWNpdCBmb3IgaWU4ICggIC5fLilcbiAgfVxuXG4gIC8vIGh0dHA6Ly9ibG9nLmFsZXhtYWNjYXcuY29tL2Nzcy10cmFuc2l0aW9uc1xuICAkLmZuLmVtdWxhdGVUcmFuc2l0aW9uRW5kID0gZnVuY3Rpb24gKGR1cmF0aW9uKSB7XG4gICAgdmFyIGNhbGxlZCA9IGZhbHNlXG4gICAgdmFyICRlbCA9IHRoaXNcbiAgICAkKHRoaXMpLm9uZSgnYnNUcmFuc2l0aW9uRW5kJywgZnVuY3Rpb24gKCkgeyBjYWxsZWQgPSB0cnVlIH0pXG4gICAgdmFyIGNhbGxiYWNrID0gZnVuY3Rpb24gKCkgeyBpZiAoIWNhbGxlZCkgJCgkZWwpLnRyaWdnZXIoJC5zdXBwb3J0LnRyYW5zaXRpb24uZW5kKSB9XG4gICAgc2V0VGltZW91dChjYWxsYmFjaywgZHVyYXRpb24pXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gICQoZnVuY3Rpb24gKCkge1xuICAgICQuc3VwcG9ydC50cmFuc2l0aW9uID0gdHJhbnNpdGlvbkVuZCgpXG5cbiAgICBpZiAoISQuc3VwcG9ydC50cmFuc2l0aW9uKSByZXR1cm5cblxuICAgICQuZXZlbnQuc3BlY2lhbC5ic1RyYW5zaXRpb25FbmQgPSB7XG4gICAgICBiaW5kVHlwZTogJC5zdXBwb3J0LnRyYW5zaXRpb24uZW5kLFxuICAgICAgZGVsZWdhdGVUeXBlOiAkLnN1cHBvcnQudHJhbnNpdGlvbi5lbmQsXG4gICAgICBoYW5kbGU6IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIGlmICgkKGUudGFyZ2V0KS5pcyh0aGlzKSkgcmV0dXJuIGUuaGFuZGxlT2JqLmhhbmRsZXIuYXBwbHkodGhpcywgYXJndW1lbnRzKVxuICAgICAgfVxuICAgIH1cbiAgfSlcblxufShqUXVlcnkpO1xuIiwiJChkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oKSB7IFxuICAgIFxuICAgICQoXCIubHBfX3Nob3J0aW5nX3RhYmxlXCIpLmVhY2goZnVuY3Rpb24oKXtcbiAgICAgICAgXG4gICAgICAgIHZhciBkb3duTG9hZExpbmtzID0gICQodGhpcykuZmluZCgnLmRvd25sb2FkX2dyb3VwX2J0bicpLmNoaWxkcmVuKCdhJyk7XG4gICAgICAgIGRvd25Mb2FkTGlua3MuZWFjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICB2YXIgYW5jaG9yUmVmID0gJCh0aGlzKTtcblxuXG5cblxuXG5cbiAgICAgICAgICAgIGFuY2hvclJlZi5vbignY2xpY2snLGZ1bmN0aW9uKGUpe1xuXG4gICAgICAgICAgICAgICAgdmFyIGhyZWZWYWwgPSAkKHRoaXMpLmF0dHIoJ2hyZWYnKTtcblxuXG5cbiAgICAgICAgICAgICAgICBpZihocmVmVmFsPT0nIycpe1xuXG4gICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICAgICAgICAgICAgICAgdmFyIHRhYmxlUmVmID0gJCh0aGlzKS5wYXJlbnQoKS5wYXJlbnQoKS5maW5kKCd0YWJsZScpLmZpcnN0KCk7XG5cbiAgICAgICAgICAgICAgICB2YXIgdGFibGVUeXBlID0gJCh0aGlzKS5kYXRhKCd0eXBlJyk7XG5cblxuICAgICAgICAgICAgICAgIHRhYmxlUmVmLnRhYmxlRXhwb3J0KHt0eXBlOnRhYmxlVHlwZSxlc2NhcGU6J2ZhbHNlJyxmaWxlTmFtZTonZXhwb3J0JyxpZDonY3N2J30pO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIFxuICAgICAgICBcbiAgICAgICAgXG4gICAgfSlcbn0pOyIsInZhciBzZWxlY3QgPSByZXF1aXJlKCcuLi91dGlscy9zZWxlY3QnKTtcbnZhciB3aGVuRE9NUmVhZHkgPSByZXF1aXJlKCcuLi91dGlscy93aGVuLWRvbS1yZWFkeScpO1xudmFyIEFjY29yZGlvbiA9IHJlcXVpcmUoJy4uL2NvbXBvbmVudHMvYWNjb3JkaW9uJyk7XG5cbndoZW5ET01SZWFkeShmdW5jdGlvbiBpbml0QWNjb3JkaW9ucyAoKSB7XG5cbiAgdmFyIGFjY29yZGlvbnMgPSBzZWxlY3QoJy51c2EtYWNjb3JkaW9uLCAubG9vcC1hY2NvcmRpb24tY29udGVudCcpO1xuICBhY2NvcmRpb25zLmZvckVhY2goZnVuY3Rpb24gKGVsKSB7XG4gICAgbmV3IEFjY29yZGlvbihlbCk7XG4gIH0pO1xufSk7XG4iLCJ2YXIgd2hlbkRPTVJlYWR5ID0gcmVxdWlyZSgnLi4vdXRpbHMvd2hlbi1kb20tcmVhZHknKTtcbnZhciBuYXZJbml0ID0gcmVxdWlyZSgnLi4vY29tcG9uZW50cy9uYXZpZ2F0aW9uJyk7XG5cbndoZW5ET01SZWFkeShuYXZJbml0KTtcbiIsIid1c2Ugc3RyaWN0JztcblxuXG5yZXF1aXJlKCcuL2NvbXBvbmVudHMvdGFibGVFeHBvcnQuanMnKTtcbnJlcXVpcmUoJy4vY29tcG9uZW50cy9qcXVlcnkuYmFzZTY0Jyk7XG5yZXF1aXJlKCcuL2NvbXBvbmVudHMvaHRtbDJjYW52YXMuanMnKTtcbnJlcXVpcmUoJy4vY29tcG9uZW50cy9zcHJpbnRmLmpzJyk7XG5yZXF1aXJlKCcuL2NvbXBvbmVudHMvanNwZGYuanMnKTtcbnJlcXVpcmUoJy4vY29tcG9uZW50cy9iYXNlNjQuanMnKTtcbnJlcXVpcmUoJy4vY29tcG9uZW50cy93YmdfdGFibGVfZXhwb3J0LmpzJyk7XG5yZXF1aXJlKCcuL2luaXRpYWxpemVycy9hY2NvcmRpb25zJyk7XG5yZXF1aXJlKCcuL2luaXRpYWxpemVycy9uYXZpZ2F0aW9uJyk7XG5yZXF1aXJlKCcuL2NvbXBvbmVudHMvdHJhbnNpdGlvbicpO1xucmVxdWlyZSgnLi9jb21wb25lbnRzL2J1dHRvbicpO1xucmVxdWlyZSgnLi9jb21wb25lbnRzL2NvbGxhcHNlJyk7XG5yZXF1aXJlKCcuL2NvbXBvbmVudHMvZHJvcGRvd24nKTtcbnJlcXVpcmUoJy4vY29tcG9uZW50cy90YWJsZV9zb3J0aW5nJyk7XG5yZXF1aXJlKCcuL2NvbXBvbmVudHMvdGFibGUnKTtcbnJlcXVpcmUoJy4vY29tcG9uZW50cy90YWJzJyk7IFxucmVxdWlyZSgnLi9jb21wb25lbnRzL211bHRpbWVkaWEnKTtcbnJlcXVpcmUoJy4vY29tcG9uZW50cy9jYXJkJyk7XG5cblxuIiwiLyoqXG4gKiBBdHRhY2hlcyBhIGdpdmVuIGxpc3RlbmVyIGZ1bmN0aW9uIHRvIGEgZ2l2ZW4gZWxlbWVudCB3aGljaCBpc1xuICogdHJpZ2dlcmVkIGJ5IGEgc3BlY2lmaWVkIGxpc3Qgb2YgZXZlbnQgdHlwZXMuXG4gKiBAcGFyYW0ge0hUTUxFbGVtZW50fSBlbGVtZW50IC0gdGhlIGVsZW1lbnQgdG8gd2hpY2ggdGhlIGxpc3RlbmVyIHdpbGwgYmUgYXR0YWNoZWRcbiAqIEBwYXJhbSB7U3RyaW5nfSBldmVudFR5cGVzIC0gc3BhY2Utc2VwYXJhdGVkIGxpc3Qgb2YgZXZlbnQgdHlwZXMgd2hpY2ggd2lsbCB0cmlnZ2VyIHRoZSBsaXN0ZW5lclxuICogQHBhcmFtIHtGdW5jdGlvbn0gbGlzdGVuZXIgLSB0aGUgZnVuY3Rpb24gdG8gYmUgZXhlY3V0ZWRcbiAqIEByZXR1cm5zIHtPYmplY3R9IC0gY29udGFpbmluZyBhIDx0dD50cmlnZ2VyKCk8L3R0PiBtZXRob2QgZm9yIGV4ZWN1dGluZyB0aGUgbGlzdGVuZXIsIGFuZCBhbiA8dHQ+b2ZmKCk8L3R0PiBtZXRob2QgZm9yIGRldGFjaGluZyBpdFxuICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGRpc3BhdGNoIChlbGVtZW50LCBldmVudFR5cGVzLCBsaXN0ZW5lciwgb3B0aW9ucykge1xuICB2YXIgZXZlbnRUeXBlQXJyYXkgPSBldmVudFR5cGVzLnNwbGl0KC9cXHMrLyk7XG5cbiAgdmFyIGF0dGFjaCA9IGZ1bmN0aW9uIChlLCB0LCBkKSB7XG4gICAgaWYgKGUuYXR0YWNoRXZlbnQpIHtcbiAgICAgIGUuYXR0YWNoRXZlbnQoJ29uJyArIHQsIGQsIG9wdGlvbnMpO1xuICAgIH1cbiAgICBpZiAoZS5hZGRFdmVudExpc3RlbmVyKSB7XG4gICAgICBlLmFkZEV2ZW50TGlzdGVuZXIodCwgZCwgb3B0aW9ucyk7XG4gICAgfVxuICB9O1xuXG4gIHZhciB0cmlnZ2VyID0gZnVuY3Rpb24gKGUsIHQpIHtcbiAgICB2YXIgZmFrZUV2ZW50O1xuICAgIGlmICgnY3JlYXRlRXZlbnQnIGluIGRvY3VtZW50KSB7XG4gICAgICAvLyBtb2Rlcm4gYnJvd3NlcnMsIElFOStcbiAgICAgIGZha2VFdmVudCA9IGRvY3VtZW50LmNyZWF0ZUV2ZW50KCdIVE1MRXZlbnRzJyk7XG4gICAgICBmYWtlRXZlbnQuaW5pdEV2ZW50KHQsIGZhbHNlLCB0cnVlKTtcbiAgICAgIGUuZGlzcGF0Y2hFdmVudChmYWtlRXZlbnQpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBJRSA4XG4gICAgICBmYWtlRXZlbnQgPSBkb2N1bWVudC5jcmVhdGVFdmVudE9iamVjdCgpO1xuICAgICAgZmFrZUV2ZW50LmV2ZW50VHlwZSA9IHQ7XG4gICAgICBlLmZpcmVFdmVudCgnb24nK2UuZXZlbnRUeXBlLCBmYWtlRXZlbnQpO1xuICAgIH1cbiAgfTtcblxuICB2YXIgZGV0YWNoID0gZnVuY3Rpb24gKGUsIHQsIGQpIHtcbiAgICBpZiAoZS5kZXRhY2hFdmVudCkge1xuICAgICAgZS5kZXRhY2hFdmVudCgnb24nICsgdCwgZCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIGlmIChlLnJlbW92ZUV2ZW50TGlzdGVuZXIpIHtcbiAgICAgIGUucmVtb3ZlRXZlbnRMaXN0ZW5lcih0LCBkLCBvcHRpb25zKTtcbiAgICB9XG4gIH07XG5cbiAgZXZlbnRUeXBlQXJyYXkuZm9yRWFjaChmdW5jdGlvbiAoZXZlbnRUeXBlKSB7XG4gICAgYXR0YWNoLmNhbGwobnVsbCwgZWxlbWVudCwgZXZlbnRUeXBlLCBsaXN0ZW5lcik7XG4gIH0pO1xuXG4gIHJldHVybiB7XG4gICAgdHJpZ2dlcjogZnVuY3Rpb24gKCkge1xuICAgICAgdHJpZ2dlci5jYWxsKG51bGwsIGVsZW1lbnQsIGV2ZW50VHlwZUFycmF5WyAwIF0pO1xuICAgIH0sXG4gICAgb2ZmOiBmdW5jdGlvbiAoKSB7XG4gICAgICBldmVudFR5cGVBcnJheS5mb3JFYWNoKGZ1bmN0aW9uIChldmVudFR5cGUpIHtcbiAgICAgICAgZGV0YWNoLmNhbGwobnVsbCwgZWxlbWVudCwgZXZlbnRUeXBlLCBsaXN0ZW5lcik7XG4gICAgICB9KTtcbiAgICB9LFxuICB9O1xufTtcbiIsIi8qKlxuICogQG5hbWUgc2VsZWN0XG4gKiBAZGVzYyBzZWxlY3RzIGVsZW1lbnRzIGZyb20gdGhlIERPTSBieSBjbGFzcyBzZWxlY3RvciBvciBJRCBzZWxlY3Rvci5cbiAqIEBwYXJhbSB7c3RyaW5nfSBzZWxlY3RvciAtIFRoZSBzZWxlY3RvciB0byB0cmF2ZXJzZSB0aGUgRE9NIHdpdGguXG4gKiBAcGFyYW0ge0hUTUxFbGVtZW50fSBjb250ZXh0IC0gVGhlIGNvbnRleHQgdG8gdHJhdmVyc2UgdGhlIERPTSBpbi5cbiAqIEByZXR1cm4ge0FycmF5LkhUTUxFbGVtZW50fSAtIEFuIGFycmF5IG9mIERPTSBub2RlcyBvciBhbiBlbXB0eSBhcnJheS5cbiAqL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBzZWxlY3QgKHNlbGVjdG9yLCBjb250ZXh0KSB7XG5cbiAgaWYgKHR5cGVvZiBzZWxlY3RvciAhPT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gW107XG4gIH1cblxuICBpZiAoKGNvbnRleHQgPT09IHVuZGVmaW5lZCkgfHwgIWlzRWxlbWVudChjb250ZXh0KSkge1xuICAgIGNvbnRleHQgPSB3aW5kb3cuZG9jdW1lbnQ7XG4gIH1cblxuICB2YXIgc2VsZWN0aW9uID0gY29udGV4dC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKTtcblxuICByZXR1cm4gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoc2VsZWN0aW9uKTtcblxufTtcblxuZnVuY3Rpb24gaXNFbGVtZW50ICh2YWx1ZSkge1xuICByZXR1cm4gISF2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlLm5vZGVUeXBlID09PSAxO1xufSIsIi8qXG4gKiBAbmFtZSBET01Mb2FkZWRcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGNiIC0gVGhlIGNhbGxiYWNrIGZ1bmN0aW9uIHRvIHJ1biB3aGVuIHRoZSBET00gaGFzIGxvYWRlZC5cbiAqL1xubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBET01Mb2FkZWQgKGNiKSB7XG4gIC8vIGluIGNhc2UgdGhlIGRvY3VtZW50IGlzIGFscmVhZHkgcmVuZGVyZWRcbiAgaWYgKCdsb2FkaW5nJyAhPT0gZG9jdW1lbnQucmVhZHlTdGF0ZSkge1xuICAgIGlmIChpc0Z1bmN0aW9uKGNiKSkge1xuICAgICAgY2IoKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcikgeyAvLyBtb2Rlcm4gYnJvd3NlcnNcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdET01Db250ZW50TG9hZGVkJywgY2IpO1xuICB9IGVsc2UgeyAvLyBJRSA8PSA4XG4gICAgZG9jdW1lbnQuYXR0YWNoRXZlbnQoJ29ucmVhZHlzdGF0ZWNoYW5nZScsIGZ1bmN0aW9uICgpe1xuICAgICAgaWYgKCdjb21wbGV0ZScgPT09IGRvY3VtZW50LnJlYWR5U3RhdGUpIHtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24oY2IpKSB7XG4gICAgICAgICAgY2IoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICB9XG59O1xuXG5mdW5jdGlvbiBpc0Z1bmN0aW9uIChhcmcpIHtcbiAgcmV0dXJuICh0eXBlb2YgYXJnID09PSAnZnVuY3Rpb24nKTtcbn0iXX0=
